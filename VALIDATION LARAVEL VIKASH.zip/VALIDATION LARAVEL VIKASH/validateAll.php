<?php

//No require import Validation


	public function register(Request $request)
    {
        $request->validate([
            'name' => 'string|required|min:2',
            'email' => 'string|email|required|max:100|unique:users',
            'password' =>'string|required|confirmed|min:6'
        ]);

        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->save();

        return back()->with('success','Your Registration has been successfull.');
    }


    public function login(Request $request)
    {
        $request->validate([
            'email' => 'string|required|email',
            'password' => 'string|required'
        ]);

        $userCredential = $request->only('email','password');
        if(Auth::attempt($userCredential)){

            $route = $this->redirectDash();
            return redirect($route);
        }
        else{
            return back()->with('error','Username & Password is incorrect');
        }
    }


     public function validationAllTypes(Request $request)
    {
        $request->validate([
        	'name' => 'string|required|min:2', 
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            
        	'email' => 'string|required|email',
            'email' => 'string|email|required|max:100|unique:users',
            'email' => "required|string|email|max:255|unique:users,email",
            'email' => 'required|email|unique:users,id,'.$request->user_id,

          
            'password' => 'string|required'
            'password' => 'required|string|min:6',
            'confirm_password' => 'required|same:password',
            
            'password' =>'string|required|confirmed|min:6'

            'old_password' => 'required',
            'new_password' => 'required|confirmed',

            
            'mobile' => "required|mobile_valid|unique:users,mobile",
            'mobile_1' => "sometimes|mobile_valid",
            'mobile' => "required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10|unique:users,mobile",
            'mobile' => "required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10|unique:users,mobile,".$request->user_id,


            'industry_id' => 'required',
           
            'bio' => 'sometimes|max:500',

            'avtar'         => 'sometimes|image|max:2048',
            'image'         => 'required|image|mimes:jpeg,jpg,png',
            'floor_plan'    => 'image|mimes:jpeg,jpg,png',

            'document' =>'mimes:doc,pdf,docx,xlx,xls,csv,txt',
            'site_procedures' =>'required|mimes:pdf',

            //Slider Store
            'title' => 'required|unique:sliders|max:255',
            'image' => 'required|mimes:jpeg,jpg,png'

            
            //In some scenarios, you want to apply certain validation if a particular field is present then this Laravel validation rule plays important role.
            'sometimes'

            
           
        ]);