<?php
use App\Http\Controllers\Frontend\FrontendController;
use App\Http\Controllers\Frontend\DashboardController;
use App\Http\Controllers\Frontend\MynotificationsController;
use App\Http\Controllers\Frontend\AvailabilitySlotsController;
use App\Http\Controllers\Frontend\BookAppointmentsController;
use App\Http\Controllers\Frontend\PagesController;
use App\Http\Controllers\Frontend\UserController;
use App\Http\Controllers\Auth\SocialLoginController;


/*
 * Frontend Controllers
 * All route names are prefixed with 'frontend.'.
 */
Route::get('/getCountry', [UserController::class,'getCountry']);
Route::post('api/fetch-states', [UserController::class, 'fetchState']);
Route::post('api/fetch-cities', [UserController::class, 'fetchCity']);

Route::get('/', [HomeController::class, 'index'])->name('index');

Route::get('aboutus',[FrontendController::class, 'getAboutus'])->name('aboutus');
Route::get('services',[DashboardController::class, 'getServices'])->name('services');
Route::get('nursing-list',[DashboardController::class, 'getNursingList'])->name('nursing-list');
Route::get('nursing-detail/{id}',[DashboardController::class, 'getNursingDetail'])->name('nursing-detail');
Route::get('availableSlotes',[DashboardController::class, 'availableSlotes'])->name('availableSlotes');

/* Route for insert Country, State, City CSV Files */
Route::get('getCountries', [FrontendController::class, 'getCountries']);
Route::get('getStates', [FrontendController::class, 'getStates']);
Route::get('getCities', [FrontendController::class, 'getCities']);


/* Contact page route */
Route::get('/contact', [PagesController::class,'index'])->name('contact');
Route::post('contact/send',[PagesController::class,'send'])->name('contact.send');

/* Blogs page route */
Route::get('/blog', [PagesController::class,'getBlog'])->name('blog');
Route::get('/blog-detail/{id}', [PagesController::class,'BlogDetail'])->name('blog-detail');
Route::post('/blog/comment/{id}',[PagesController::class,'blogComments'])->name('blog.comment');

/* Pages for API  */
Route::get('/privacy-policy', [PagesController::class,'getPrivacyPage'])->name('privacy-policy');
Route::get('/terms-and-conditions', [PagesController::class,'getTermsPage'])->name('terms-and-conditions');

Route::group(['middleware' => ['auth']], function () {
Route::group(['namespace' => 'User', 'as' => 'users.'], function () {

// User Dashboard Specific
Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/subscription-plans',[DashboardController::class, 'getPlans'])->name('subscription-plans');
Route::post('/add-subscription-plans',[DashboardController::class, 'SelectSubscPlan'])->name('add-subscription-plans');

/* Time Availability Slots Route */
Route::get('timeavailability-slots', [AvailabilitySlotsController::class, 'getAvailabilitySlots'])->name('timeavailability-slots');
Route::get('timeavailability-slots/create', [AvailabilitySlotsController::class, 'create'])->name('timeavailability-slots/create');
Route::post('timeavailability-slots/store', [AvailabilitySlotsController::class, 'store'])->name('timeavailability-slots.store');
Route::get('timeavailability-slots/{id}/edit', [AvailabilitySlotsController::class, 'edit'])->name('timeavailability-slots.edit');
Route::post('timeavailability-slots/update/{id}', [AvailabilitySlotsController::class, 'Update'])->name('timeavailability-slots.update');
Route::post('timeavailability-slots/delete/{id}', [AvailabilitySlotsController::class, 'SlotsDelete'])->name('timeavailability-slots.delete');
Route::match(['get','post'],'timeavailability-slots/update-status',[AvailabilitySlotsController::class, 'updateStatus'])->name('timeavailability-slots.update-status');

/* Confirm Booking */
Route::post('booking', [BookAppointmentsController::class, 'GetBooking'])->name('booking');

/* Appointment Route for Nursing */
Route::get('/appointments',[BookAppointmentsController::class, 'getAppointments'])->name('appointments');
Route::post('booking/{id}/confirm', [BookAppointmentsController::class, 'getConfirm'])->name('confirm');
Route::post('booking/{id}/reject', [BookAppointmentsController::class, 'getReject'])->name('reject');
Route::get('booking/{id}/pending', [BookAppointmentsController::class, 'getPending'])->name('pending');
Route::get('booking/{id}/complete', [BookAppointmentsController::class, 'getComplete'])->name('complete');

/* Get Appointment Route for Careseeker */
Route::get('/my-appointment',[BookAppointmentsController::class, 'MyAppointments'])->name('my-appointment');
Route::post('booking/{id}/cancel', [BookAppointmentsController::class, 'MakeCancel'])->name('cancel');

// My NotificationsController
Route::get('notifications', [MynotificationsController::class, 'getnotification'])->name('notifications');
Route::get('markAsRead', [MynotificationsController::class, 'deleteAllNote'])->name('markAsRead');
Route::get('showNote/{id}', [MynotificationsController::class, 'showMyNote'])->name('showNote');
Route::get('deletenote', [MynotificationsController::class, 'deleteAllNote'])->name('deletenote');

/* Add,Remove, Get Favorite to Doctor */
Route::get('add-to-favorites/{id}', [DashboardController::class, 'getAddFavorites'])->name('add.favorite');
Route::get('remove-to-favorites/{id}', [DashboardController::class, 'getRemoveFavorites'])->name('remove.favorite');
Route::get('favorites', [DashboardController::class, 'getFavorites'])->name('favorites');

/* Add feedback Route */
Route::post('add-feedback',[DashboardController::class, 'addFeedback'])->name('add-feedback');
Route::get('feedbacks', [DashboardController::class, 'getFeedback'])->name('feedbacks');

/* Careseeker Transaction/Payment History */
Route::get('/transaction-history',[BookAppointmentsController::class, 'TransactionHistory'])->name('transaction-history');
    });
});

Route::get('/{page_slug}',[FrontendController::class, 'getPages'])->name('');

/* Become Nursing Route */
Route::post('become-nursing',[DashboardController::class, 'BecomeNursing'])->name('become-nursing');

Route::get('razorpay', [RazorpayController::class, 'razorpay'])->name('razorpay');
Route::post('razorpaypayment', [RazorpayController::class, 'payment'])->name('payment');


Route::get('social-auth/{provider}/callback',[SocialLoginController::class,'handleProviderCallback']);
Route::get('social-auth/{provider}',[SocialLoginController::class,'redirectToProvider'])->name('social.redirect');