<?php
use App\Http\Controllers\Backend\SubscriptionPlansController;
use App\Http\Controllers\Backend\NursingSlotsController;
use App\Http\Controllers\Backend\CancellationFeesController;
use App\Http\Controllers\Backend\PaymentController;
use App\Http\Controllers\Backend\PdfController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Autho Routes
require __DIR__ . '/auth.php';
require __DIR__ . '/frontend/home.php';

// Language Switch
Route::get('language/{language}', 'LanguageController@switch')->name('language.switch');

/*
* Frontend Routes  */
Route::group(['namespace' => 'Frontend', 'as' => 'frontend.'], function () {
    Route::get('/', 'FrontendController@index')->name('index');
    Route::get('demo-index', 'FrontendController@index2')->name('demo-index');
    Route::get('home', 'FrontendController@index')->name('home');
    Route::get('privacy', 'FrontendController@privacy')->name('privacy');
    Route::get('terms', 'FrontendController@terms')->name('terms');

    Route::group(['middleware' => ['auth']], function () {
        /*
         Users Routes 
        */
        $module_name = 'users';
        $controller_name = 'UserController';
        Route::get('profile/{id}', ['as' => "$module_name.profile", 'uses' => "$controller_name@profile"]);
        Route::get('profile/{id}/edit', ['as' => "$module_name.profileEdit", 'uses' => "$controller_name@profileEdit"]);
        Route::patch('profile/{id}/edit', ['as' => "$module_name.profileUpdate", 'uses' => "$controller_name@profileUpdate"]);
        Route::get("$module_name/emailConfirmationResend/{id}", ['as' => "$module_name.emailConfirmationResend", 'uses' => "$controller_name@emailConfirmationResend"]);
        Route::get('profile/changePassword/{username}', ['as' => "$module_name.changePassword", 'uses' => "$controller_name@changePassword"]);
        Route::patch('profile/changePassword/{username}', ['as' => "$module_name.changePasswordUpdate", 'uses' => "$controller_name@changePasswordUpdate"]);
        Route::delete('users/userProviderDestroy', ['as' => 'users.userProviderDestroy', 'uses' => 'UserController@userProviderDestroy']);
    });
});

/* Backend Routes */
Route::group(['namespace' => 'Backend', 'prefix' => 'admin', 'as' => 'backend.', 'middleware' => ['auth', 'can:view_backend']], function () {

    /*
     * Backend Dashboard
     * Namespaces indicate folder structure.
     */
    Route::get('/', 'BackendController@index')->name('home');
    Route::get('dashboard', 'BackendController@index')->name('dashboard');

    /*
     *
     *  Settings Routes
     *
     * ---------------------------------------------------------------------
     */
    Route::group(['middleware' => ['permission:edit_settings']], function () {
        $module_name = 'settings';
        $controller_name = 'SettingController';
        Route::get("$module_name", "$controller_name@index")->name("$module_name");
        Route::post("$module_name", "$controller_name@store")->name("$module_name.store");
    });

    /*
    *
    *  Notification Routes
    *
    * ---------------------------------------------------------------------
    */
    $module_name = 'notifications';
    $controller_name = 'NotificationsController';
    Route::get("$module_name", ['as' => "$module_name.index", 'uses' => "$controller_name@index"]);
    Route::get("$module_name/markAllAsRead", ['as' => "$module_name.markAllAsRead", 'uses' => "$controller_name@markAllAsRead"]);
    Route::delete("$module_name/deleteAll", ['as' => "$module_name.deleteAll", 'uses' => "$controller_name@deleteAll"]);
    Route::get("$module_name/{id}", ['as' => "$module_name.show", 'uses' => "$controller_name@show"]);

    /*
    *
    *  Backup Routes
    *
    * ---------------------------------------------------------------------
    */
    $module_name = 'backups';
    $controller_name = 'BackupController';
    Route::get("$module_name", ['as' => "$module_name.index", 'uses' => "$controller_name@index"]);
    Route::get("$module_name/create", ['as' => "$module_name.create", 'uses' => "$controller_name@create"]);
    Route::get("$module_name/download/{file_name}", ['as' => "$module_name.download", 'uses' => "$controller_name@download"]);
    Route::get("$module_name/delete/{file_name}", ['as' => "$module_name.delete", 'uses' => "$controller_name@delete"]);

    /*
    *
    *  Roles Routes
    *
    * ---------------------------------------------------------------------
    */
    $module_name = 'roles';
    $controller_name = 'RolesController';
    Route::resource("$module_name", "$controller_name");

    /*
    *
    *  Users Routes
    *
    * ---------------------------------------------------------------------
    */
    $module_name = 'users';
    $controller_name = 'UserController';
    Route::get("$module_name/profile/{id}", ['as' => "$module_name.profile", 'uses' => "$controller_name@profile"]);
    Route::get("$module_name/profile/{id}/edit", ['as' => "$module_name.profileEdit", 'uses' => "$controller_name@profileEdit"]);
    Route::patch("$module_name/profile/{id}/edit", ['as' => "$module_name.profileUpdate", 'uses' => "$controller_name@profileUpdate"]);
    Route::get("$module_name/emailConfirmationResend/{id}", ['as' => "$module_name.emailConfirmationResend", 'uses' => "$controller_name@emailConfirmationResend"]);
    Route::delete("$module_name/userProviderDestroy", ['as' => "$module_name.userProviderDestroy", 'uses' => "$controller_name@userProviderDestroy"]);
    Route::get("$module_name/profile/changeProfilePassword/{id}", ['as' => "$module_name.changeProfilePassword", 'uses' => "$controller_name@changeProfilePassword"]);
    Route::patch("$module_name/profile/changeProfilePassword/{id}", ['as' => "$module_name.changeProfilePasswordUpdate", 'uses' => "$controller_name@changeProfilePasswordUpdate"]);
    Route::get("$module_name/changePassword/{id}", ['as' => "$module_name.changePassword", 'uses' => "$controller_name@changePassword"]);
    Route::patch("$module_name/changePassword/{id}", ['as' => "$module_name.changePasswordUpdate", 'uses' => "$controller_name@changePasswordUpdate"]);
    Route::get("$module_name/trashed", ['as' => "$module_name.trashed", 'uses' => "$controller_name@trashed"]);
    Route::patch("$module_name/trashed/{id}", ['as' => "$module_name.restore", 'uses' => "$controller_name@restore"]);
    Route::patch("$module_name/forceDelete/{id}", ['as' => "$module_name.forceDelete", 'uses' => "$controller_name@forceDelete"]);

    Route::get("$module_name/index_data", ['as' => "$module_name.index_data", 'uses' => "$controller_name@index_data"]);
    Route::get("$module_name/index_list", ['as' => "$module_name.index_list", 'uses' => "$controller_name@index_list"]);
    Route::resource("$module_name", "$controller_name");
    Route::patch("$module_name/{id}/block", ['as' => "$module_name.block", 'uses' => "$controller_name@block", 'middleware' => ['permission:block_users']]);
    Route::patch("$module_name/{id}/unblock", ['as' => "$module_name.unblock", 'uses' => "$controller_name@unblock", 'middleware' => ['permission:block_users']]);

     /* Subscription Plans Route */

    Route::get('subscriptionplans', 'SubscriptionPlansController@index')->name('subscriptionplans');
    Route::get('subscriptionplans/create', 'SubscriptionPlansController@create')->name('subscriptionplans.create');
    Route::post('subscriptionplans/store', 'SubscriptionPlansController@Store')->name('subscriptionplans.store');
    Route::get('subscriptionplans/{id}/edit','SubscriptionPlansController@edit')->name('subscriptionplans.edit');
    Route::post('subscriptionplans/update/{id}', 'SubscriptionPlansController@Update')->name('subscriptionplans.update');
    Route::post('subscriptionplans/delete/{id}', 'SubscriptionPlansController@planDelete')->name('subscriptionplans.delete');

    /* Services Route */

    Route::get('services', 'ServicesController@index')->name('services');
    Route::get('services/create', 'ServicesController@create')->name('services.create');
    Route::post('services/store', 'ServicesController@Store')->name('services.store');
    Route::get('services/{id}/edit', 'ServicesController@edit')->name('services.edit');
    Route::post('services/update/{id}', 'ServicesController@Update')->name('services.update');
    Route::post('services/delete/{id}', 'ServicesController@servicesDelete')->name('services.delete');
    Route::post('services/update-status','ServicesController@updateStatus')->name('services.update-status');
    Route::post('services/is_featured','ServicesController@ServiceFeatured')->name('services.is_featured');

    /*view all Appointments by admin*/
    Route::get('appointments', 'BackendController@allAppointments')->name('appointments');

    /* rejection accept & cancel by admin */
    Route::post('booking/{id}/reject','BackendController@ConfirmReject')->name('reject');
    Route::post('booking/{id}/pending','BackendController@ConfirmPending')->name('pending');

    /* Reschedule Appointment by admin */
    Route::post('booking/{id}/reschedule','BackendController@RescheduleAppoinment')->name('reschedule');


    /* appointment Service fee by admin to Nursing staff*/
    Route::get('service-fee', 'BackendController@index')->name('service-fee');
    Route::get('service-fee/add', 'BackendController@add')->name('service-fee.add');
    Route::post('service-fee/store', 'BackendController@store')->name('service-fee.store');
    Route::get('service-fee/edit/{id}', 'BackendController@edit')->name('service-fee.edit');
    Route::post('service-fee/update/{id}', 'BackendController@update')->name('service-fee.update');
    Route::post('service-fee/delete/{id}', 'BackendController@CancelFeeDelete')->name('service-fee.delete');
    Route::post('service-fee/update-status','BackendController@updateStatus')->name('service-fee.update-status');

    /* appointment cancellation fee by admin */
    Route::get('cancellation-fee', 'CancellationFeesController@index')->name('cancellation-fee');
    Route::get('cancellation-fee/create', 'CancellationFeesController@create')->name('cancellation-fee.create');
    Route::post('cancellation-fee/store', 'CancellationFeesController@store')->name('cancellation-fee.store');
    Route::get('cancellation-fee/edit/{id}', 'CancellationFeesController@edit')->name('cancellation-fee.edit');
    Route::post('cancellation-fee/update/{id}', 'CancellationFeesController@update')->name('cancellation-fee.update');
    Route::post('cancellation-fee/delete/{id}', 'CancellationFeesController@CancelFeeDelete')->name('cancellation-fee.delete');
    Route::post('cancellation-fee/update-status','CancellationFeesController@updateStatus')->name('cancellation-fee.update-status');


    /*Banners Route */
    Route::get('banners', 'BannersController@index')->name('banners');
    Route::get('banners/create', 'BannersController@create')->name('banners.create');
    Route::post('banners/store', 'BannersController@Store')->name('banners.store');
    Route::get('banners/{id}/edit', 'BannersController@edit')->name('banners.edit');
    Route::post('banners/update/{id}', 'BannersController@Update')->name('banners.update');
    Route::post('banners/delete/{id}', 'BannersController@bannersDelete')->name('banners.delete');
    Route::post('banners/update-status','BannersController@updateStatus')->name('banners.update-status');

     /*PDF Upload Route */
    Route::get('pdf-show', 'PdfController@index')->name('pdf');
    Route::get('pdf/create', 'PdfController@create')->name('pdf.create');
    Route::post('pdf/store', 'PdfController@Store')->name('pdf.store');
    Route::get('pdf/{id}/edit', 'PdfController@edit')->name('pdf.edit');
    Route::post('pdf/update/{id}', 'PdfController@Update')->name('pdf.update');
    Route::post('pdf/delete/{id}', 'PdfController@bannersDelete')->name('pdf.delete');
    Route::post('pdf/update-status','PdfController@updateStatus')->name('pdf.update-status');

    /*Booking Slots Route */
    Route::get('slots', 'BookSlotsController@index')->name('slots');
    Route::get('slots/create', 'BookSlotsController@create')->name('slots.create');
    Route::post('slots/store', 'BookSlotsController@Store')->name('slots.store');
    Route::get('slots/{id}/edit', 'BookSlotsController@edit')->name('slots.edit');
    Route::post('slots/update/{id}', 'BookSlotsController@Update')->name('slots.update');
    Route::post('slots/delete/{id}', 'BookSlotsController@slotsDelete')->name('slots.delete');
    Route::post('slots/update-status','BookSlotsController@updateStatus')->name('slots.update-status');

    /*Nursing Available Slots Route */
    Route::get('nursingslots', 'NursingSlotsController@index')->name('nursingslots');
    Route::get('slotsdetail/{id}', 'NursingSlotsController@getNursingSlots')->name('slotsdetail');
    //Route::get('slotsdetail', [NursingSlotsController::class, 'getNursingSlots'])->name('slotsdetail');
   
    /*Blogs Route */
    Route::get('blogs', 'BlogsController@index')->name('blogs');
    Route::get('blogs/create', 'BlogsController@create')->name('blogs.create');
    Route::post('blogs/store', 'BlogsController@Store')->name('blogs.store');
    Route::get('blogs/{id}/edit', 'BlogsController@edit')->name('blogs.edit');
    Route::post('blogs/update/{id}', 'BlogsController@Update')->name('blogs.update');
    Route::post('blogs/delete/{id}', 'BlogsController@blogsDelete')->name('blogs.delete');
    Route::post('blogs/update-status','BlogsController@updateStatus')->name('blogs.update-status');

    /* get blog comments & update status */
    Route::get('blog-comment', 'BlogsController@BlogComment')->name('blog-comment');
    Route::post('blogs/update-approved','BlogsController@updateApproved')->name('blogs.update-approved');

    /* Pages Route */
    Route::get('pages', 'PagesController@index')->name('pages');
    Route::get('pages/create', 'PagesController@create')->name('pages.create');
    Route::post('pages/store', 'PagesController@Store')->name('pages.store');
    Route::get('pages/{id}/edit', 'PagesController@edit')->name('pages.edit');
    Route::post('pages/update/{id}', 'PagesController@Update')->name('pages.update');
    Route::post('pages/delete/{id}', 'PagesController@pagesDelete')->name('pages.delete');
    Route::post('pages/update-status','PagesController@updateStatus')->name('pages.update-status');

    /* Faqs Route */    
    Route::get('faqs', 'FaqsController@index')->name('faqs');
    Route::get('faqs/create', 'FaqsController@create')->name('faqs.create');
    Route::post('faqs/store', 'FaqsController@Store')->name('faqs.store');
    Route::get('faqs/{id}/edit', 'FaqsController@edit')->name('faqs.edit');
    Route::post('faqs/update/{id}', 'FaqsController@Update')->name('faqs.update');
    Route::post('faqs/delete/{id}', 'FaqsController@faqsDelete')->name('faqs.delete');
    Route::post('faqs/update-status','FaqsController@updateStatus')->name('faqs.update-status');

    /* Testimonials Route */
    Route::get('testimonials', 'TestimonialsController@index')->name('testimonials');
    Route::get('testimonials/create', 'TestimonialsController@create')->name('testimonials.create');
    Route::post('testimonials/store', 'TestimonialsController@Store')->name('testimonials.store');
    Route::get('testimonials/{id}/edit', 'TestimonialsController@edit')->name('testimonials.edit');
    Route::post('testimonials/update/{id}', 'TestimonialsController@Update')->name('testimonials.update');
    Route::post('testimonials/delete/{id}', 'TestimonialsController@testimonialsDelete')->name('testimonials.delete');
    Route::post('testimonials/update-status','TestimonialsController@updateStatus')->name('testimonials.update-status');

    /*payment Routes */
    Route::get('payment', 'PaymentController@index')->name('payment');
    Route::get('payment/create', 'PaymentController@create')->name('payment.create');
    Route::post('payment/store', 'PaymentController@Store')->name('payment.store');
    Route::get('payment/{id}/edit', 'PaymentController@edit')->name('payment.edit');
    Route::post('payment/update/{id}', 'PaymentController@Update')->name('payment.update');
    Route::post('payment/delete/{id}', 'PaymentController@bannersDelete')->name('payment.delete');
    Route::post('payment/update-status','PaymentController@updateStatus')->name('payment.update-status');

    /*view all Become Nursing Request by admin*/
    Route::get('become-nursing', 'BackendController@allRequests')->name('become-nursing');

    /*view all Feedbacks by admin*/
    Route::get('user-feedbacks', 'BackendController@allFeedbacks')->name('user-feedbacks');
});
