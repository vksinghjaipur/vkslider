<?php

namespace App\Notifications;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\HtmlString;
class NewBooking extends Notification
{
    use Queueable;
    public static $toMailCallback;
    public function __construct()
    {
        //
    }

    public function via($notifiable)
    {
        return ['database'];
    }

    
    public function toDatabase($notifiable)
    {
        $user = $notifiable;
        $title = $user->title;
        $text = $user->text;

        $url_backend = route('backend.users.profile', $user->id);
        $url_frontend = route('frontend.users.profile', $user->id);

        return [
            'title'         => $title,
            'module'        => 'User',
            'type'          => 'created', // created, published, viewed,
            'icon'          => 'fas fa-user',
            'text'          => $text,
            'url_backend'   => $url_backend,
            'url_frontend'  => $url_frontend,
        ];
    }


    // public function toMail($notifiable)
    // {
    //     $user = $notifiable;
    //     $title = $user->title;
    //     $text = $user->text;
    //     $data = $user->data;
    //     return (new MailMessage())
    //                 ->subject($title)
    //                 ->line($text)
    //                 ->line(new HtmlString($data))
    //                 ->action('Vist Application', url('/'))
    //                 ->line('We are really happy that you started to use ' . app_name() . '!');
    // }
}
