<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\DayData;
class WeekData extends Model
{
    use HasFactory;
    protected $table = 'week_data';

    public function getDayData()
    {
    	return $this->hasMany('App\Models\DayData','day_value');
    }
}
