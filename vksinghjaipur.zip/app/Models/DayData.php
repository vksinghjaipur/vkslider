<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DayData extends Model
{
    use HasFactory;
    protected $table = 'week_days_value';


     protected $fillable = [
        'day_value',
        'time_slot'
    ];
}
