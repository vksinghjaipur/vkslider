<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\AvailabilityTimes;


class AvailabilitySlot extends Model
{
    use HasFactory;
    protected $table = 'calendar_day_sections';


    public function getSlots()
    {
        return $this->hasMany('App\Models\AvailabilityTimes','calendar_day_section_id','id')->orderBy('slot_time','ASC');
    }
}
