<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Models\Traits\ModelAttributes;
use Illuminate\Database\Eloquent\SoftDeletes;
class ServiceFee extends Model
{
	protected $table = 'service_fees';
    //
}
