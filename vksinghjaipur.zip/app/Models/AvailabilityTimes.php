<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\AvailabilitySlot;

class AvailabilityTimes extends Model
{
    use HasFactory;
    protected $table = 'calendar_day_section_times';


   
}
