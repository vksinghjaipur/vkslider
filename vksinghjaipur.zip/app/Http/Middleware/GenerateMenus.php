<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Str;

class GenerateMenus
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure                 $next
     *
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        \Menu::make('admin_sidebar', function ($menu) {
            // Dashboard
            $menu->add('<i class="cil-speedometer c-sidebar-nav-icon"></i> Dashboard', [
                'route' => 'backend.dashboard',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 1,
                'activematches' => 'admin/dashboard*',
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Notifications
            $menu->add('<i class="c-sidebar-nav-icon fas fa-bell"></i> Notifications', [
                'route' => 'backend.notifications.index',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 80,
                'activematches' => 'admin/notifications*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Separator: Access Management
            $menu->add('Management', [
                'class' => 'c-sidebar-nav-title',
            ])
            ->data([
                'order'         => 81,
                'permission'    => ['edit_settings', 'view_backups', 'view_users', 'view_roles', 'view_logs'],
            ]);


            // Banner Management
            $menu->add('<i class="c-sidebar-nav-icon fas fa-image"></i> Banner Management', [
                'route' => 'backend.banners',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 102,
                'activematches' => 'admin/banners*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);


             // PDF Management
            $menu->add('<i class="c-sidebar-nav-icon fas fa-image"></i> PDF Management', [
                'route' => 'backend.pdf',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 102,
                'activematches' => 'admin/pdf*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);



            // Slots Management Dropdown
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon fas fa-wrench"></i> Slots Management', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 103,
                'activematches' => 'admin/slots*',
                'permission'    => [],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // Available Slots Menu 1
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-calendar"></i>All Slots Table ', [
                'route' => 'backend.slots',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 121,
                'activematches' => 'admin/slots*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Available Nursing Available Slots Menu 2
            $accessControl->add('<i class="c-sidebar-nav-icon cil-people"></i> Nursing Available Slots', [
                'route' => 'backend.nursingslots',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 122,
                'activematches' => 'admin/nursingslots*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Appointments Management
            $menu->add('<i class="c-sidebar-nav-icon fa fa-address-card"></i> Appointment Management', [
                'route' => 'backend.appointments',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 104,
                'activematches' => 'admin/appointments*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Services
            $menu->add('<i class="c-sidebar-nav-icon fas fa-wrench"></i> Services Management', [
                'route' => 'backend.services',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 105,
                'activematches' => 'admin/services*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            
            // Fee (cancellation & Commission) Management Dropdown
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon fas fa-wrench"></i> Fee Management', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 106,
                'activematches' => 'admin/cancellation-fee*',
                'permission'    => [],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // Cancellation Fee Menu 1
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-calendar"></i>Cancellation Fee', [
                'route' => 'backend.cancellation-fee',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 127,
                'activematches' => 'admin/cancellation-fee*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Commission Fee Menu 2
            $accessControl->add('<i class="c-sidebar-nav-icon cil-people"></i> Commission Fee', [
                'route' => 'backend.service-fee.add',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 128,
                'activematches' => 'admin/service-fee/add*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);
            


            // Payment Management Dropdown
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon fas fa-wrench"></i> Payment Management', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 107,
                'activematches' => 'admin/payment*',
                'permission'    => [],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // Available Slots Menu 1
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-calendar"></i>Appointments Payment ', [
                'route' => 'backend.payment',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 123,
                'activematches' => 'admin/payment*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);


            // Blogs Management Dropdown
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon fas fa-blog"></i> Health Blog Management', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 108,
                'activematches' => 'admin/blogs*',
                'permission'    => [],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // All Blogs
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-blog"></i>Health Blogs ', [
                'route' => 'backend.blogs',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 125,
                'activematches' => 'admin/blogs*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Blogs Comment
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-comment"></i> Blogs Comment', [
                'route' => 'backend.blog-comment',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 126,
                'activematches' => 'admin/blog-comment*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

        /************************* Messages Dropdown ***********************/    
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon fas fa-blog"></i> Enquiry Management', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 109,
                'activematches' => 'admin/become-nursing*',
                'permission'    => [],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // All Become Nursing requests
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-blog"></i>Become Nursing Request ', [
                'route' => 'backend.become-nursing',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 125,
                'activematches' => 'admin/become-nursing*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // All User related Feedbacks
            $accessControl->add('<i class="c-sidebar-nav-icon fa fa-comment"></i> User Feedbacks', [
                'route' => 'backend.user-feedbacks',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 126,
                'activematches' => 'admin/user-feedbacks*',
                'permission'    => [],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

        /************************* End Dropdown ****************************/    

            // Faqs
            $menu->add('<i class="c-sidebar-nav-icon fa fa-quote-left"></i> Faqs Management', [
                'route' => 'backend.faqs',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 109,
                'activematches' => 'admin/faqs*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);
            

            // Pages
            $menu->add('<i class="c-sidebar-nav-icon fas fa-file"></i> Pages Management', [
                'route' => 'backend.pages',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 110,
                'activematches' => 'admin/pages*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);


            // Testimonials
            $menu->add('<i class="c-sidebar-nav-icon fa fa-quote-left"></i> Testimonials Management', [
                'route' => 'backend.testimonials',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 111,
                'activematches' => 'admin/testimonials*',
                'permission'    =>[],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Settings
            $menu->add('<i class="c-sidebar-nav-icon fas fa-cogs"></i> Settings', [
                'route' => 'backend.settings',
                'class' => 'c-sidebar-nav-item',
            ])
            ->data([
                'order'         => 112,
                'activematches' => 'admin/settings*',
                'permission'    => ['edit_settings'],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            
            // Access Control Dropdown
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon cil-shield-alt"></i> Access Control', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 82,
                'activematches' => [
                    'admin/users*',
                    'admin/roles*',
                ],
                'permission'    => ['view_users', 'view_roles'],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // Submenu: Users
            $accessControl->add('<i class="c-sidebar-nav-icon cil-people"></i> Users', [
                'route' => 'backend.users.index',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 106,
                'activematches' => 'admin/users*',
                'permission'    => ['view_users'],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Submenu: Roles
            $accessControl->add('<i class="c-sidebar-nav-icon cil-people"></i> Roles', [
                'route' => 'backend.roles.index',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 107,
                'activematches' => 'admin/roles*',
                'permission'    => ['view_roles'],
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Log Viewer
            // Log Viewer Dropdown
            $accessControl = $menu->add('<i class="c-sidebar-nav-icon cil-list-rich"></i> Log Viewer', [
                'class' => 'c-sidebar-nav-dropdown',
            ])
            ->data([
                'order'         => 130,
                'activematches' => [
                    'log-viewer*',
                ],
                'permission'    => ['view_logs'],
            ]);
            $accessControl->link->attr([
                'class' => 'c-sidebar-nav-dropdown-toggle',
                'href'  => '#',
            ]);

            // Submenu: Log Viewer Dashboard
            $accessControl->add('<i class="c-sidebar-nav-icon cil-list"></i> Dashboard', [
                'route' => 'log-viewer::dashboard',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 131,
                'activematches' => 'admin/log-viewer',
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Submenu: Log Viewer Logs by Days
            $accessControl->add('<i class="c-sidebar-nav-icon cil-list-numbered"></i> Logs by Days', [
                'route' => 'log-viewer::logs.list',
                'class' => 'nav-item',
            ])
            ->data([
                'order'         => 110,
                'activematches' => 'admin/log-viewer/logs*',
            ])
            ->link->attr([
                'class' => 'c-sidebar-nav-link',
            ]);

            // Access Permission Check
            $menu->filter(function ($item) {
                if ($item->data('permission')) {
                    if (auth()->check()) {
                        if (auth()->user()->hasRole('super admin')) {
                            return true;
                        } elseif (auth()->user()->hasAnyPermission($item->data('permission'))) {
                            return true;
                        }
                    }

                    return false;
                } else {
                    return true;
                }
            });

            // Set Active Menu
            $menu->filter(function ($item) {
                if ($item->activematches) {
                    $matches = is_array($item->activematches) ? $item->activematches : [$item->activematches];

                    foreach ($matches as $pattern) {
                        if (Str::is($pattern, \Request::path())) {
                            $item->activate();
                            $item->active();
                            if ($item->hasParent()) {
                                $item->parent()->activate();
                                $item->parent()->active();
                            }
                            // dd($pattern);
                        }
                    }
                }

                return true;
            });
        })->sortBy('order');

        return $next($request);
    }
}
