<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests;
    use DispatchesJobs;
    use ValidatesRequests;


    function postpushnotification($device_id,$title,$message,$noti_type=null,$urlToken=null)
    {
        if(!empty($device_id))
        {
          $fields = array(
             'to' => $device_id,
              'data' =>array('title' => $title, 'message' => $message,'urlToken' => $urlToken,'sound'=>'default','type'=>$noti_type),
            'notification'=>array('title'=>$title,'body'=>$message,'sound'=>'default')
            );

            $response = $this->sendPushNotification($fields);
            return true;
        }
    }


    function sendPushNotification($fields = array(), $usertype=Null)
    {
         //echo '<pre>';print_r($fields); //exit;
          $API_ACCESS_KEY = 'AAAAx3goT64:APA91bEEdFWxjbHy8TusSW4vZ-0ZxjqLxUsULKSUHcxod_reuvJyOOmf-NsiFG0oN49ljgDxxbVggRsaGR8yf2asAY6VpZkjEE8VuXJZY2Q3Ry6G92iYLcjj8xdMNnqKaUC_j3q0OGBN';

          $headers = array
          (
            'Authorization: key=' . $API_ACCESS_KEY,
            'Content-Type: application/json'
          );

          $ch = curl_init();
          curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
          curl_setopt( $ch,CURLOPT_POST, true );
          curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
          // Execute post
          $result = curl_exec($ch);
          //print_r($result);//die;
          sleep(5);
          if ($result === FALSE) {
              die('Curl failed: ' . curl_error($ch));
          }
          // Close connection
          curl_close($ch);
          return $result;    
    }
}
