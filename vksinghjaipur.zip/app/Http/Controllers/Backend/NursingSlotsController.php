<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\User;
use App\Models\Service;
use App\Models\BookSlot;
use App\Models\AvailabilitySlot;
use App\Models\AvailabilityTimes;
use App\Models\WeekData;
use App\Models\DayData;
use App\Models\Blog;
use App\Models\SubscriptionPlan;
use Illuminate\Support\Facades\Hash;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class NursingSlotsController extends Controller
{
    public function index(Request $request)
    {
        $nursingslist = DB::table('users')->where('user_type',2)
        ->join('userprofiles','userprofiles.user_id','=','users.id')->get();
        return view('backend.nursingslots.index', compact('nursingslist'));
    }


    public function getNursingSlots(Request $request)
    { 
        $getmyid=$request->id;
        $slots = AvailabilitySlot::with('getSlots')
        ->where('calendar_day_sections.doctor_id',$getmyid)
        ->get();

        /* Get All Created Slots */
        $result=WeekData::with('getDayData')->get();
        DB::table('week_data')
        ->leftjoin('week_days_value','week_days_value.day_value','=','week_data.id')
        ->get();
        //echo '<pre>';print_r($slots);exit();
        return view('backend.nursingslots.slotsdetail',compact('slots','result','getmyid'));
    }
}
