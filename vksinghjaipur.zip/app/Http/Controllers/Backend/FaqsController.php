<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\Setting;
use App\Models\Service;
use App\Models\Faq;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class FaqsController extends Controller
{
    public function index(Request $request)
    {
        $faqs = DB::table('faqs')->get();
        return view('backend.faqs.index', compact('faqs'));
    }

    public function create()
    {
        return View('backend.faqs.create');
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
        $question = $request->question;
        $answer = $request->answer;
        $display_order = $request->display_order;
        $status = $request->status ?? 1;
        $values = array('question' => $question, 'answer'=> $answer, 'display_order' => $display_order, 'status' => $status);
        DB::table('faqs')->insert($values);
       
       return new RedirectResponse(route('backend.faqs'), ['message' => __('The faqs successfully created.')]);
    }

    public function edit($id=null)
    {
        $faqs= DB::table('faqs')->where('id',$id)->first();
        return view('backend.faqs.edit', compact('faqs'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $faqstype= array();
        $faqstype['question']=$request->question;
        $faqstype['answer']=$request->answer;
        $faqstype['display_order']=$request->display_order;

        DB::table('faqs')->where('id',$id)->update($faqstype);
        return new RedirectResponse(route('backend.faqs'), ['message' => __('The Faqs successfully updated.')]);
    }

    public function faqsDelete($id=null)
    {
        DB::table('faqs')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.faqs'), ['message' => __('The Faqs successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Faq::where('id',$data['id'])->update(['status'=>$data['status']]);
    }

}
