<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\Service;
use App\Models\Blog;
use App\Models\Role;
use App\Models\SubscriptionPlan;
use Auth, DB;
use Response;
use Redirect;
use Illuminate\Support\Str;
use Log;

class SubscriptionPlansController extends Controller
{
    public function index(Request $request)
    {
        $subscription_plans = DB::table('subscription_plans')
        ->join('users','users.id','=','subscription_plans.created_by')
        ->join('roles','roles.id','=','subscription_plans.role_id')
        ->select('subscription_plans.*','users.username','roles.name')
        ->get();
        //echo "<pre>";print_r($subscription_plans); die();
        return view('backend.subscriptionplans.index', compact('subscription_plans'));
    }

    public function create()
    {
        $getrole=Role::where('id', '!=', 1)->where('id', '!=', 5)->get();
        $services_data=Service::where('status',1)->get();
        return View('backend.subscriptionplans.create',compact('getrole','services_data'));
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
        if($request -> ismethod('post')){
           $data = $request->all();
           $plandata = new SubscriptionPlan;
            //echo "<pre>";print_r($data);die;
            $plandata->plan_title = $data['plan_title'];
            $plandata->plan_description = $data['plan_description'];
            $plandata->plan_price = $data['plan_price'];
            $plandata->plan_duration = $data['plan_duration'];
            $plandata->role_id=implode(',',$data['role_id']);
            $plandata->service_id = implode(',',$data['service_id']);
            $plandata->status = $data['status'] ?? 0;
            $plandata->created_by = auth()->user()->id;

          request()->validate([
            'plan_title' => 'required|string',
           ]);
               $plandata->save();   
               return new RedirectResponse(route('backend.subscriptionplans'), ['flash_success' => __('The subscription plans data successfully created.')]);
            }
    }

    public function edit($id=null)
    {   
        $getrole=Role::where('id', '!=', 1)->where('id', '!=', 5)->get();
        $services_data=Service::where('status',1)->get();
        $subscription_plans= DB::table('subscription_plans')->where('id',$id)->first();
        return view('backend.subscriptionplans.edit', compact('subscription_plans','getrole','services_data'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $plantype= array();
        $plantype['plan_title']=$request->plan_title;
        $plantype['plan_description']=$request->plan_description;
        $plantype['plan_price']=$request->plan_price;
        $plantype['plan_duration']=$request->plan_duration;
        //$plantype['role_id']=$request->role_id;
        //$plantype['service_id']=$request->service_id;
        $plantype['role_id']=implode(',',$request['role_id']);
        $plantype['service_id'] = implode(',',$request['service_id']);
        $plantype['updated_by']=auth()->user()->id;
        $plantype['status']=$request->status;
        
        DB::table('subscription_plans')->where('id',$id)->update($plantype);

        return new RedirectResponse(route('backend.subscriptionplans'), ['flash_success' => __('The subscription plans data successfully updated.')]);
    }

    public function planDelete($id=null)
    {
        DB::table('subscription_plans')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.subscriptionplans'), ['flash_success' => __('The subscription plans successfully deleted.')]);
    }

}
