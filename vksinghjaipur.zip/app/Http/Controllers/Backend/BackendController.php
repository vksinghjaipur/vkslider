<?php

namespace App\Http\Controllers\Backend;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use App\Http\Controllers\Controller;
use App\Models\BookAppointment;
use App\Models\User;
use App\Models\BecomeNursing;
use App\Models\CancellationFee;
use App\Models\ServiceFee;
use App\Models\UserFeedback;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Models\Role;
use App\Notifications\NewBooking;
use DB;

class BackendController extends Controller
{
    public function index()
    {
        return view('backend.index');
    }

    /* show all appointments */
    public function allAppointments()
    {
        $appointments = DB::table('booking_appointments')
        ->leftjoin('users AS A', 'A.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'booking_appointments.doctor_id')
        ->select('booking_appointments.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar','booking_appointment_payments.txn_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->orderBY('booking_appointments.id', 'desc')
        ->get();
        //echo '<pre>';print_r($appointments);die();
        return view('backend.appointments.index',compact('appointments'));
    }

    /* Confirm to Rejection appointment by admin */
    public function ConfirmReject(Request $request,$id = NULL)
    {
       // echo"<pre>";print_r($request->id); die();
        $booking_info=DB::table('booking_appointments')->where('booking_appointments.id', $request->id)
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->first();
        $day_time =explode('-', $booking_info->booking_time);
        $dd=date('Y-m-d',strtotime($booking_info->booking_date));
        $pmexp= explode("PM", $day_time[0]);
        if(isset($pmexp) && empty($pmexp[0]))
        {
            $pmexp= explode("AM", $day_time[0]);
        }
        $ddd= $dd.' '.$pmexp[0]; 
        $mybooking_date = date('Y-m-d H:i',strtotime($ddd));
        $mybookingcancel=date('Y-m-d H:i', strtotime($booking_info->cancellation_request_time));
        $date1 = strtotime($mybookingcancel);
        $date2 =strtotime($mybooking_date);
  
        $diff = abs($date2 - $date1);
        $years = floor($diff / (365*60*60*24));
        $months = floor(($diff - $years * 365*60*60*24)
                                 / (30*60*60*24));
        $days = floor(($diff - $years * 365*60*60*24 -
               $months*30*60*60*24)/ (60*60*24));
                $hours = intval(($diff - $years * 365*60*60*24
         - $months*30*60*60*24 - $days*60*60*24)
                                     / (60*60));

        // showing cancellation fee from cancellation table         
        $cancelation_fee= DB::table('cancellation_fees')->where('user_type',$booking_info->user_type)->get();
        //echo "<pre>"; print_r($hours); die();        

        if($date1 < $date2)
        {
            foreach ($cancelation_fee as $key => $value) {
               if($value->time >= $hours)
                {
                    $amount=$booking_info->total_amount;
                    $charge=$value->cancellation_fee;
                    $diduct_amount= ($amount/100) * $charge;
                    //echo "<pre>"; print_r($diduct_amount); die(); 
                }
            }
        DB::table('booking_appointments')->where('booking_appointments.id', $request->id)
        ->update(['booking_appointments.status' => 'Reject', 'booking_appointments.cancellation_charge' => isset($value->cancellation_fee)? $value->cancellation_fee:'', 'booking_appointments.cancellation_amount' => isset($diduct_amount)? $diduct_amount:'' ]);

        /* Send cancelation confirmation to careseeker */
        $userinfo=DB::table('booking_appointments')->where('booking_appointments.id', $id)
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->join('services','services.id','=','booking_appointments.service_id')
        ->join('users','users.id','=','booking_appointments.doctor_id')
        ->select('booking_appointments.*','booking_appointment_payments.txn_id','booking_appointment_payments.booking_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status','services.service_name','users.name')
        ->first();
        //echo "<pre>"; print_r($userinfo); die();
        $user=User::where('id',$userinfo->user_id)->first();
        $user->title="Your Appointment successfully canceled!";
        $user->text='Hello your appointment request canceled successfully!';

        /* Email send to careseeker for confirm rejection */
        $message="Dear careseeker, your appointment #".$userinfo->booking_id." rejection request confirmed by admin.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
            'appointment_id' =>   $userinfo->booking_id,
            'careseeker_name'=>   $userinfo->patient_name,
            'doctor_name'   =>    $userinfo->name,
            'service_name'   =>   $userinfo->service_name,
            'appointment_date' => $userinfo->booking_date,
            'appointment_day' =>  $userinfo->booking_day,
            'appointment_time' => $userinfo->booking_time,
            'total_amount'    =>  $userinfo->total_amount,
            'message'         =>  $userinfo->message
            ]; 
        //echo "<pre>"; print_r($messageData); die();     
        //return view('emails.booking-confirm', compact('messageData'));  
        Mail::send('emails.accept-rejection', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Your Appointment successfully canceled!');
        });        
        $user->notify(new NewBooking($user->confirmation_code));

        /* Send cancelation confirmation to nursing professional */
        $user=User::where('id',$userinfo->doctor_id)->first();
        $user->title="User Appointment successfully canceled by admin!";
        $user->text='Hello your new appointment request canceled successfully!';

        /* Email send to nursing staff for confirm rejection */
        $message="Dear Nursing, your appointment #".$userinfo->booking_id." rejection request confirmed by admin.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
            'appointment_id'  =>  $userinfo->booking_id,
            'careseeker_name' =>  $userinfo->patient_name,
            'doctor_name'     =>  $userinfo->name,
            'service_name'    =>  $userinfo->service_name,
            'appointment_date' => $userinfo->booking_date,
            'appointment_day' =>  $userinfo->booking_day,
            'appointment_time' => $userinfo->booking_time,
            'total_amount'    =>  $userinfo->total_amount,
            'message'         =>  $userinfo->message
            ];      
        //return view('emails.booking-confirm', compact('messageData'));  
        //echo "<pre>"; print_r($messageData); die();      
        Mail::send('emails.accept-rejection', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Your Appointment successfully canceled!');
        });        
        $user->notify(new NewBooking($user->confirmation_code));
        }
        else
            {
                return redirect()->back()->with('warning','Appointment not will be Cancel.');
            }
        return redirect()->back()->with('error','Appointment cancelation request accepted successfully.');
    }

    /* Reject to Rejection appointment by admin */
    public function ConfirmPending(Request $request,$id = NULL)
    {
        //echo"<pre>";print_r($request->id); die();
        DB::table('booking_appointments')->where('booking_appointments.id', $request->id)->update(['booking_appointments.status' => 'Pending', 'booking_appointments.user_type' => NULL, 'booking_appointments.cancellation_request_time' => NULL, 'booking_appointments.cancel_reason' => NULL]);

        /* Send Rejection cancelation to careseeker */
        $userinfo=DB::table('booking_appointments')->where('booking_appointments.id', $id)
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->join('services','services.id','=','booking_appointments.service_id')
        ->first();
        $user=User::where('id',$userinfo->user_id)->first();
        $user->title="Your Appointment canceled Rejected!";
        $user->text='Hello User your appointment canceled request Rejected by admin!';

        /* Email send to careseeker for cancel rejection */
        $message="Dear careseeker, your appointment #".$userinfo->booking_id." rejection request canceled by admin.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
            'appointment_id' =>   $userinfo->booking_id,
            'careseeker_name'=>   $userinfo->patient_name,
            'doctor_name'   =>    Auth::user()->name,
            'service_name'   =>   $userinfo->service_name,
            'appointment_date' => $userinfo->booking_date,
            'appointment_day' =>  $userinfo->booking_day,
            'appointment_time' => $userinfo->booking_time,
            'total_amount'    =>  $userinfo->total_amount,
            'message'         =>  $userinfo->message
            ];      
        //return view('emails.booking-confirm', compact('messageData'));  
        //print_r($messageData);die();       
        Mail::send('emails.cancel-rejection', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Your Appointment rejection request canceled!');
        });    
        $user->notify(new NewBooking($user->confirmation_code));

        /* Send Rejection cancelation to nursing professional */
        $user=User::where('id',$userinfo->doctor_id)->first();
        $user->title="User Appointment canceled request suspend!";
        $user->text='Hello your new appointment request canceled request rejected by admin!';

        /* Email send to nursing staff for cancel rejection */
        $message="Dear careseeker, your appointment #".$userinfo->booking_id." rejection request canceled by admin.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
            'appointment_id' =>   $userinfo->booking_id,
            'careseeker_name'=>   $userinfo->patient_name,
            'doctor_name'   =>    Auth::user()->name,
            'service_name'   =>   $userinfo->service_name,
            'appointment_date' => $userinfo->booking_date,
            'appointment_day' =>  $userinfo->booking_day,
            'appointment_time' => $userinfo->booking_time,
            'total_amount'    =>  $userinfo->total_amount,
            'message'         =>  $userinfo->message
            ];      
        //return view('emails.booking-confirm', compact('messageData'));  
        //print_r($messageData);die();       
        Mail::send('emails.cancel-rejection', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Appointment cancelation request Rejected');
        });     
        $user->notify(new NewBooking($user->confirmation_code));
        return redirect()->back()->with('message','Appointment cancelation request Rejected.');
    }

    /* Reschedule appointment by admin */
    public function RescheduleAppoinment(Request $request, $id=null)
    {
        //echo "<pre>";print_r($request->id); die();
        $bookdata= array();
        $bookdata['booking_date']=$request->booking_date;
        $bookdata['booking_time']=$request->booking_time;
        DB::table('booking_appointments')->where('id', $request->id)
        ->update($bookdata);
        return redirect()->back()->with('message','Appointment reschedule successfully done.');   
    }

    /* Service Fee by admin to nursing staff */
    public function add()
    {
        $data = ServiceFee::first();
        return view('backend.service-fee.create', compact('data'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'service_fee' => 'required|numeric',
            'fee_type' => 'required|in:Fixed,Percentage',
        ]);
        if(isset($request->fee_type) && !empty($request->fee_type) && $request->fee_type=='Percentage')
        {
            if(($request->service_fee > 100) || ($request->service_fee < 1))
            {
                 return redirect()->back()->withFlashDanger(trans('Please enter valid Percentage between 1 to 100'));
            }
        }
        $data=ServiceFee::first();
        if(empty($data)) {
            $data = new ServiceFee();
        }
        $data->service_fee = $request->service_fee;
        $data->fee_type = isset($request->fee_type) && $request->fee_type =='Fixed' ? 'Fixed': 'Percentage';
        $data->save();
        return redirect()->back()->with('message','Service charge updated successfully.');
    }  

    /************ All Requests of Become Nursing ***********/

    public function allRequests()
    {
        $become_requests = DB::table('become_nursings')->get();
        //echo '<pre>';print_r($become_requests);die();
        return view('backend.become-nursing.index',compact('become_requests'))->with('no', 1);
    }

    /************ All Users feedbacks ***********/
    public function allFeedbacks()
    {
        $user_feedbacks = DB::table('user_feedbacks')
        ->leftjoin('users AS A', 'A.id', '=', 'user_feedbacks.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'user_feedbacks.doctor_id')
        ->select('user_feedbacks.*','A.name as user_id','B.name as doctor_id')
        ->get();
        return view('backend.user-feedbacks.index',compact('user_feedbacks'))->with('no', 1);
    }
}
