<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use App\Models\BookAppointment;
use App\Models\User;
use App\Models\CancellationFee;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Models\Role;
use App\Notifications\NewBooking;
use DB;

class CancellationFeesController extends Controller
{
    public function index(Request $request)
    {
    	$getrole=Role::where('id', '!=', 1)->get();
        $data = DB::table('cancellation_fees')
        ->join('roles','roles.id','=','cancellation_fees.user_type')
        ->select('cancellation_fees.*','roles.name')
        ->get();
       // echo "<pre>";print_r($blogs); die();
        return view('backend.cancellation-fee.index', compact('data','getrole'));
    }

    public function create()
    {
    	$getrole=Role::where('id', '!=', 1)->get();
        return View('backend.cancellation-fee.create',compact('getrole'));
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
    	if($request -> ismethod('post')){
		   $data = $request->all();
		   $canceldata = new CancellationFee;
			//echo "<pre>";print_r($data);die;
			$canceldata->user_type = $data['user_type'];
			$canceldata->time = $data['time'];
			$canceldata->cancellation_fee = $data['cancellation_fee'];
			$canceldata->fee_type = $data['fee_type'];
      		$canceldata->status = $data['status'] ?? 1;

         request()->validate([
            'time'  =>  'required|numeric',
            'cancellation_fee' => 'required|numeric',
            'fee_type' => 'required|in:Fixed,Percentage',
        ]);

        if(isset($request->fee_type) && !empty($request->fee_type) && $request->fee_type=='Percentage')
        {
            if(($request->cancellation_fee > 100) || ($request->cancellation_fee < 1))
            {
                 return redirect()->back()->with('error','Please enter valid Percentage between 1 to 100');
            }
        } 

			$canceldata->save();	
			return new RedirectResponse(route('backend.cancellation-fee'), ['message' => __('The Fee data successfully created.')]);
		    }
    }

    public function edit($id=null)
    {
    	$getrole=Role::where('id', '!=', 1)->get();
        $data= DB::table('cancellation_fees')->where('id',$id)->first();
        return view('backend.cancellation-fee.edit', compact('data','getrole'));
    }

    public function update(Request $request ,$id=null)
    {
    //echo '<pre>'; print_r($request->all());exit;
        $canceltype= array();
        $canceltype['time']=$request->time;
        $canceltype['cancellation_fee']=$request->cancellation_fee;
        $canceltype['fee_type']=$request->fee_type;

        if(isset($request->fee_type) && !empty($request->fee_type) && $request->fee_type=='Percentage')
        {
            if(($request->cancellation_fee > 100) || ($request->cancellation_fee < 1))
            {
                 return redirect()->back()->with('error','Please enter valid Percentage between 1 to 100');
            }
        } 

        DB::table('cancellation_fees')->where('id',$id)->update($canceltype);

        return new RedirectResponse(route('backend.cancellation-fee'), ['info' => __('The Fee data successfully updated.')]);
    }

    public function CancelFeeDelete($id=null)
    {
        DB::table('cancellation_fees')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.cancellation-fee'), ['message' => __('The Fee data successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        CancellationFee::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Cancelation Fee off successfully updated','status'=>0]);
        }
            return response()->json(['success' => 'Cancelation Fee on successfully updated','status'=>1]);
    }
}
