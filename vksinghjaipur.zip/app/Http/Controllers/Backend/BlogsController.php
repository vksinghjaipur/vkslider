<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\Service;
use App\Models\Blog;
use App\Models\Comment;
use Auth, DB;
use Illuminate\Support\Str;
use Log;
class BlogsController extends Controller
{
    public function index(Request $request)
    {
        $blogs = DB::table('blogs')
        ->join('users','users.id','=','blogs.created_by')
        ->select('blogs.*','users.username')
        ->get();
       // echo "<pre>";print_r($blogs); die();
        return view('backend.blogs.index', compact('blogs'));
    }

    public function create()
    {
        return View('backend.blogs.create');
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
        $name = $request->name;
        $publish_datetime = Carbon::parse($request->publish_datetime);
        $featured_image = $request->featured_image;
        $content = $request->content;
        $meta_title = $request->meta_title;
        $cannonical_link = $request->cannonical_link;
        $slug = Str::slug($request->name);
        $meta_description = $request->meta_description;
        $meta_keywords = $request->meta_keywords;
        $status = $request->status;
        $created_by = auth()->user()->id;
        $created_at = date("Y/m/d");
        $values = array('name' => $name, 'publish_datetime' => $publish_datetime,'featured_image' => $featured_image, 'content' => $content, 'meta_title' => $meta_title, 'cannonical_link' => $cannonical_link, 'slug' => $slug, 'meta_description' => $meta_description, 'meta_keywords' => $meta_keywords, 'created_by' => $created_by, 'created_at' => $created_at, 'status' => $status);
        
        if (isset($values['featured_image']) && ! empty($values['featured_image'])) {
            $avatar = $values['featured_image'];
            $fileName = time().$avatar->getClientOriginalName();
            $destinationPath = public_path('/img/blog-image/');
            $avatar->move($destinationPath, $fileName);
            $values = array_merge($values, ['featured_image' => $fileName]);
        }

        DB::table('blogs')->insert($values);
       
       return new RedirectResponse(route('backend.blogs'), ['message' => __('The blogs data successfully created.')]);
    }

    public function edit($id=null)
    {
        $blogs= DB::table('blogs')->where('id',$id)->first();
        return view('backend.blogs.edit', compact('blogs'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $blogtype= array();
        $blogtype['name']=$request->name;
        $blogtype['publish_datetime']=$request->publish_datetime;
        $blogtype['featured_image']=$request->featured_image;
        $blogtype['content']=$request->content;
        $blogtype['meta_title']=$request->meta_title;
        $blogtype['cannonical_link']=$request->cannonical_link;
        $blogtype['slug']=Str::slug($request->name);
        $blogtype['meta_description']=$request->meta_description;
        $blogtype['meta_keywords']=$request->meta_keywords;
        $blogtype['updated_by']=auth()->user()->id;

       
        if(!empty($blogtype['featured_image'])){
        $blogtype['featured_image']=$blogtype['featured_image'];
        $avatar = $blogtype['featured_image'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/blog-image/');
        $avatar->move($destinationPath, $fileName);
        $blogtype = array_merge($blogtype, ['featured_image' => $fileName]);
        
        }else{
            unset($blogtype['featured_image']);
        } 
        DB::table('blogs')->where('id',$id)->update($blogtype);

        return new RedirectResponse(route('backend.blogs'), ['info' => __('The blog data successfully updated.')]);
    }

    public function blogsDelete($id=null)
    {
        DB::table('blogs')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.blogs'), ['message' => __('The blog successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Blog::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Blogs off successfully updated','status'=>0]);
        }
            return response()->json(['success' => 'Blogs on successfully updated','status'=>1]);
    }


    /* get blog comments */
     public function BlogComment(Request $request)
    {
        $blog_comment = DB::table('comments')
        ->join('users','users.id','=','comments.user_id')
        ->join('blogs','blogs.id','=','comments.blog_id')
        ->select('comments.*','users.username','blogs.name')
        ->get();
       // echo "<pre>";print_r($blog_comment); die();
        return view('backend.blogs.blog-comment', compact('blog_comment'));
    }

    /* Update status of Blog Comments */
    public function updateApproved(Request $request,$id=null)
    {
        $data = $request->all();
        Comment::where('id',$data['id'])->update(['approved'=>$data['approved']]);
        if($data['approved']==0)
        {
            return response()->json(['error' => 'Blog Comment off successfully updated','approved'=>0]);
        }
            return response()->json(['success' => 'Blog Comment on successfully updated','approved'=>1]);
    }
}
