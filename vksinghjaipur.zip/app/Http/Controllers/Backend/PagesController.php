<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\Service;
use App\Models\Blog;
use App\Models\Page;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class PagesController extends Controller
{
    public function index(Request $request)
    {
        $pages = DB::table('pages')
        ->join('users','users.id','=','pages.created_by')
        ->select('pages.*','users.username')
        ->get();
       // echo "<pre>";print_r($blogs); die();
        return view('backend.pages.index', compact('pages'));
    }

     public function create()
    {
        return View('backend.pages.create');
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
    	if($request -> ismethod('post')){
  			   $data = $request->all();
  			   $pagedata = new Page;
    			//echo "<pre>";print_r($data);die;
    			$pagedata->title = $data['title'];
    			$pagedata->page_slug = Str::slug($request->title);
    			$pagedata->description = $data['description'];
    			$pagedata->cannonical_link = $data['cannonical_link'];
    			$pagedata->seo_title = $data['seo_title'];
    			$pagedata->seo_keyword = $data['seo_keyword'];
    			$pagedata->seo_description = $data['seo_description'];
          		$pagedata->status = $data['status'] ?? 0;
          		$pagedata->created_by = auth()->user()->id;

          request()->validate([
            'title' => 'required|string',
           ]);
			   $pagedata->save();	
			   return new RedirectResponse(route('backend.pages'), ['message' => __('The page data successfully created.')]);
		    }
    }

    public function edit($id=null)
    {
        $pages= DB::table('pages')->where('id',$id)->first();
        return view('backend.pages.edit', compact('pages'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $pagetype= array();
        $pagetype['title']=$request->title;
        $pagetype['page_slug']=Str::slug($request->title);
        $pagetype['description']=$request->description;
        $pagetype['cannonical_link']=$request->cannonical_link;
        $pagetype['seo_title']=$request->seo_title;
        $pagetype['seo_keyword']=$request->seo_keyword;
        $pagetype['seo_description']=$request->seo_description;
        $pagetype['updated_by']=auth()->user()->id;
        
        DB::table('pages')->where('id',$id)->update($pagetype);

        return new RedirectResponse(route('backend.pages'), ['message' => __('The Page data successfully updated.')]);
    }

    public function pagesDelete($id=null)
    {
        DB::table('pages')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.pages'), ['message' => __('The Page successfully deleted.')]);
    }
    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Page::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Slots off successfully updated','status'=>0]);
        }
            return response()->json(['success' => 'Slots on successfully updated','status'=>1]);
    }

}
