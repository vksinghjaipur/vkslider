<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use App\Models\BookAppointment;
use App\Models\User;
use App\Models\CancellationFee;
use App\Models\ServiceFee;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Models\Role;
use App\Notifications\NewBooking;
use DB;
class PaymentController extends Controller
{
    public function index(Request $request)
    {
        $payment=DB::table('booking_appointment_payments')->orderBy('id','asc')->get();
        return view('backend.payment.index', compact('payment'));
    }
}
