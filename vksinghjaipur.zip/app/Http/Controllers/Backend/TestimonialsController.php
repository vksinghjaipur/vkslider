<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\Service;
use App\Models\Testimonial;
use App\Models\Blog;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class TestimonialsController extends Controller
{
    public function index(Request $request)
    {
        $testimonials = DB::table('testimonials')
        ->join('users','users.id','=','testimonials.created_by')
        ->select('testimonials.*','users.username')
        ->get();
       // echo "<pre>";print_r($testimonials); die();
        return view('backend.testimonials.index', compact('testimonials'));
    }

    public function create()
    {
        return View('backend.testimonials.create');
    }


    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
    	if($request -> ismethod('post')){
  			   $data = $request->all();
  			   $testidata = new Testimonial;
    			//echo "<pre>";print_r($data);die;
    			$testidata->title = $data['title'];
    			$testidata->description = $data['description'];
                $testidata->star_value = $data['star_value'];
    			$testidata->user_name = $data['user_name'];
    			$testidata->user_image = $data['user_image'];
          		$testidata->status = $data['status'] ?? 0;
          		$testidata->created_by = auth()->user()->id;

	          	if (isset($testidata['user_image']) && ! empty($testidata['user_image'])) {
            	$avatar = $testidata['user_image'];
            	$fileName = time().$avatar->getClientOriginalName();
            	$destinationPath = public_path('/img/testimonials-image/');
            	$avatar->move($destinationPath, $fileName);
            	$testidata->user_image =  $fileName;
        		}

          request()->validate([
            'title' => 'required|string',
           ]);
			   $testidata->save();	
			   return new RedirectResponse(route('backend.testimonials'), ['message' => __('The page data successfully created.')]);
		    }
    }

    public function edit($id=null)
    {
        $testimonials= DB::table('testimonials')->where('id',$id)->first();
        return view('backend.testimonials.edit', compact('testimonials'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $testitype= array();
        $testitype['title']=$request->title;
        $testitype['description']=$request->description;
        $testitype['star_value']=$request->star_value;
        $testitype['user_name']=$request->user_name;
        $testitype['user_image']=$request->user_image;
        $testitype['updated_by']=auth()->user()->id;
       
        if(!empty($testitype['user_image'])){
        $testitype['user_image']=$testitype['user_image'];
        $avatar = $testitype['user_image'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/testimonials-image/');
        $avatar->move($destinationPath, $fileName);
        $testitype = array_merge($testitype, ['user_image' => $fileName]);
        
        }else{
            unset($testitype['user_image']);
        } 
        DB::table('testimonials')->where('id',$id)->update($testitype);

        return new RedirectResponse(route('backend.testimonials'), ['message' => __('The testimonials data successfully updated.')]);
    }

    public function testimonialsDelete($id=null)
    {
        DB::table('testimonials')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.testimonials'), ['message' => __('The testimonials plans successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Testimonial::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'testimonials off successfully updated','status'=>0]);
        }
            return response()->json(['success' => 'testimonials on successfully updated','status'=>1]);
    }
}
