<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\Service;
use App\Models\BookSlot;
use App\Models\WeekData;
use App\Models\DayData;
use App\Models\Blog;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class BookSlotsController extends Controller
{
    public function index(Request $request)
    {
        $slots = DB::table('week_data')
        ->join('week_days_value','week_days_value.day_value','=','week_data.id')
        //->get();
        ->paginate(22);
        //echo "<pre>";print_r($slots); die();
        return view('backend.slots.index', compact('slots'));
    }

    public function create()
    {
        return View('backend.slots.create');
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
        $day_name = $request->day_name;
        $day_section = $request->day_section;
        $time_slot = $request->time_slot;
        $status = $request->status;
        $created_at = date("Y/m/d");

       $checkdata= DB::table('week_data')->where('day_name',$request->day_name)->where('day_section',$request->day_section)->first();
       $lastid=isset($checkdata->id)?$checkdata->id:'';
        if(empty($checkdata))
        {
            $values = array('day_name' => $day_name,'day_section' => $day_section, 'created_at' => $created_at, 'status' => $status);
            $lastid=DB::table('week_data')->insertGetId($values);
        }
        
            $insert= array('day_value'=>$lastid,'time_slot'=>$time_slot); 
            DB::table('week_days_value')->insert($insert);

        
       
       return new RedirectResponse(route('backend.slots'), ['message' => __('Slots successfully created.')]);
    }

    public function edit($id=null)
    {
        //number
        $slots = DB::table('week_data')
        ->join('week_days_value','week_days_value.day_value','=','week_data.id')
        ->where('week_days_value.id',$id)
        ->first();
        
       //echo '<pre>';print_r($slots);die();
        return view('backend.slots.edit', compact('slots'));


    }

    public function update(Request $request ,$id=null)
    {
        $day_name = $request->day_name;
        $day_section = $request->day_section;
        $time_slot = $request->time_slot;
        DB::table('week_days_value')->where('id',$id)->update(['time_slot'=>$request->slot_time]);

        return new RedirectResponse(route('backend.slots'), ['flash_success' => __('The Slots data successfully updated.')]);
    }

    public function slotsDelete($id=null)
    {
        DB::table('week_days_value')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.slots'), ['message' => __('The Slots successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        DayData::where('id',$data['id'])->update(['status'=>$data['status']]);
    }
}
