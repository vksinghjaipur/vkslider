<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\Setting;
use App\Models\Service;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class ServicesController extends Controller
{
    public function index(Request $request)
    {
        $services = DB::table('services')->get();
        return view('backend.services.index', compact('services'));
    }

    public function create()
    {
        return View('backend.services.create');
    }

    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;
        $service_name = $request->service_name;
        $price = $request->price;
        $service_icon = $request->service_icon;
        $service_image = $request->service_image;
        $description = $request->description;
        $display_order = $request->display_order;
        $status = $request->status;
        $is_featured = $request->is_featured ?? 0;
        $values = array('service_name' => $service_name, 'price' => $price, 'service_icon' => $service_icon, 'service_image' => $service_image, 'description'=> $description, 'display_order' => $display_order, 'status' => $status, 'is_featured' => $is_featured);
        
        if (isset($values['service_icon']) && ! empty($values['service_icon'])) {
            $avatar = $values['service_icon'];
            $fileName = time().$avatar->getClientOriginalName();
            $destinationPath = public_path('/img/service-icon/');
            $avatar->move($destinationPath, $fileName);
            $values = array_merge($values, ['service_icon' => $fileName]);
        }

        if (isset($values['service_image']) && ! empty($values['service_image'])) {
            $avatar = $values['service_image'];
            $fileName = time().$avatar->getClientOriginalName();
            $destinationPath = public_path('/img/service-icon/');
            $avatar->move($destinationPath, $fileName);
            $values = array_merge($values, ['service_image' => $fileName]);
        }
        DB::table('services')->insert($values);
       
       return new RedirectResponse(route('backend.services'), ['message' => __('The Service successfully created.')]);
    }

    public function edit($id=null)
    {
        $services= DB::table('services')->where('id',$id)->first();
        return view('backend.services.edit', compact('services'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $servicetype= array();
        $servicetype['service_name']=$request->service_name;
        $servicetype['price']=$request->price;
        $servicetype['description']=$request->description;
        $servicetype['display_order']=$request->display_order;
        $servicetype['service_icon']=$request->service_icon;
        $servicetype['service_image']=$request->service_image;
        // $servicetype['status']=$request->status;
        // $servicetype['is_featured']=$request->is_featured;

       
        if(!empty($servicetype['service_icon'])){
        $servicetype['service_icon']=$servicetype['service_icon'];
        $avatar = $servicetype['service_icon'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/service-icon/');
        $avatar->move($destinationPath, $fileName);
        $servicetype = array_merge($servicetype, ['service_icon' => $fileName]);
        
        }else{
            unset($servicetype['service_icon']);
        } 

        if(!empty($servicetype['service_image'])){
        $servicetype['service_image']=$servicetype['service_image'];
        $avatar = $servicetype['service_image'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/service-icon/');
        $avatar->move($destinationPath, $fileName);
        $servicetype = array_merge($servicetype, ['service_image' => $fileName]);
        
        }else{
            unset($servicetype['service_image']);
        } 
        DB::table('services')->where('id',$id)->update($servicetype);

        return new RedirectResponse(route('backend.services'), ['message' => __('The Service successfully updated.')]);
    }

    public function servicesDelete($id=null)
    {
        DB::table('services')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.services'), ['message' => __('The Services successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Service::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Status off updated successfully','status'=>0]);
        }
            return response()->json(['success' => 'Slots on successfully updated','status'=>1]);
    }

    public function ServiceFeatured(Request $request,$id=null)
    {
        $data = $request->all();
        Service::where('id',$data['id'])->update(['is_featured'=>$data['is_featured']]);
        if($data['is_featured']==0)
        {
            return response()->json(['error' => 'Service is_featured off successfully','is_featured'=>0]);
        }
            return response()->json(['success' => 'Service is_featured on successfully','is_featured'=>1]);
    }
}
