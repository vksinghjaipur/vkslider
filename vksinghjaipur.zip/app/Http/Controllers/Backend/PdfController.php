<?php
namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Responses\RedirectResponse;
use Carbon\Carbon;
use App\Models\Setting;
use App\Models\Service;
use App\Models\BookSlot;
use App\Models\WeekData;
use App\Models\DayData;
use App\Models\Blog;
use App\Models\Pdf;
use Auth, DB;
use Illuminate\Support\Str;
use Log;

class PdfController extends Controller
{
    public function index(Request $request)
    {
        $pdf = DB::table('pdfs')->get();
        return view('backend.pdf.index', compact('pdf'));
    }

    public function create()
    {
        return View('backend.pdf.create');
    }

    public function store(Request $request)
    {  
        $request->validate([
        'file' => 'required|mimes:csv,txt,xlx,xls,pdf|max:2048'
        ]);
        $fileModel = new Pdf;
        if($request->file()) {
            $fileName = time().'_'.$request->file->getClientOriginalName();
            $filePath = $request->file('file')->storeAs('uploads', $fileName, 'public');
            $fileModel->name = time().'_'.$request->file->getClientOriginalName();
            $fileModel->file_path = '/storage/' . $filePath;
            $fileModel->save();
            return back()
            ->with('success','File has been uploaded.')
            ->with('file', $fileName);
        }

        //return new RedirectResponse(route('backend.banners'), ['message' => __('The Banner successfully created.')]);
   }
       
      
    

    public function edit($id=null)
    {
        $banners= DB::table('banners')->where('id',$id)->first();
        return view('backend.banners.edit', compact('banners'));
    }

    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $bannertype= array();
        $bannertype['banner_title']=$request->banner_title;
        $bannertype['banner_content']=$request->banner_content;
        $bannertype['banner_image']=$request->banner_image;
        $bannertype['display_order']=$request->display_order;

        if(!empty($bannertype['banner_image'])){
        $bannertype['banner_image']=$bannertype['banner_image'];
        $avatar = $bannertype['banner_image'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/banners/');
        $avatar->move($destinationPath, $fileName);
        $bannertype = array_merge($bannertype, ['banner_image' => $fileName]);
        
        }else{
            unset($bannertype['banner_image']);
        } 
        DB::table('banners')->where('id',$id)->update($bannertype);

        return new RedirectResponse(route('backend.banners'), ['message' => __('The Banner successfully updated.')]);
    }

    public function bannersDelete($id=null)
    {
        DB::table('banners')->where('id',$id)->delete();
        return new RedirectResponse(route('backend.banners'), ['message' => __('The Banner successfully deleted.')]);
    }

    public function updateStatus(Request $request,$id=null)
    {
        $data = $request->all();
        Banner::where('id',$data['id'])->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Banner off updated successfully','status'=>0]);
        }
            return response()->json(['success' => 'Banner on successfully updated','status'=>1]);
    }
}
