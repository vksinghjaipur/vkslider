<?php
namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Service;
use App\Models\BookSlot;
use App\Models\SubscriptionPlan;
use App\Models\AvailabilitySlot;
use App\Models\AvailabilityTimes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Role;
use DB;
use App\Models\WeekData;
use App\Models\DayData;

class AvailabilitySlotsController extends Controller
{
    public function getAvailabilitySlots(Request $request)
    {   
        /* Get All Slots */
        $slots = AvailabilitySlot::with('getSlots')
        ->where('calendar_day_sections.doctor_id',auth::user()->id)->get();

        /* Get All Created Slots */
        $result=WeekData::with('getDayData')->get();
        DB::table('week_data')
        ->leftjoin('week_days_value','week_days_value.day_value','=','week_data.id')
        ->get();
        //echo '<pre>';print_r($slots);exit();
        return view('frontend.nursing.timeavailability-slots.index',compact('slots','result'));
    }

    public function create(Request $request)
    {
        return View('frontend.nursing.timeavailability-slots.create');
    }

    public function store(Request $request)
    {  
      // echo '<pre>'; print_r($request->all());exit;
        $data = $request->all();
        $slotsdata = new AvailabilitySlot;
        DB::table('calendar_day_sections')
        ->Join('calendar_day_section_times','calendar_day_section_times.calendar_day_section_id','=','calendar_day_sections.id')
        ->where('calendar_day_sections.doctor_id',auth()->user()->id)->delete();
        DB::table('calendar_day_section_times')->where('doctor_id',auth()->user()->id)->delete();  

        foreach($request->title as $key=>$timeslot)
        {
            foreach($timeslot as $ps=> $time)
            {
                foreach($time as $kk=> $times)
                {   
                    $stlot = explode('-', $times);
                    $status=0;
                    if(isset($request->status[$key][0]) && !empty($request->status[$key][0]))
                    {
                       $status=1;
                    }
                   // print_r($key);
                  // exit;
             
                     $day= array('title'=>$ps,'doctor_id'=>auth()->user()->id,'day_code'=>$key,'duration'=>$request->duration,'start_time'=>$stlot[0],'end_time'=>$stlot[1],'status'=>$status);
                         $lastid= DB::table('calendar_day_sections')->insertGetId($day);
                    foreach($request->slot_time as $tkey=>$mytime)
                    {
                        if($key==$tkey)
                        {
                            foreach($mytime as $s=> $slot)
                            {
                               //echo '<pre>';  print_r($ps);exit;
                                if($ps==$s)
                                {
                                // echo 'gane';
                                 // print_r($slot);
                                    foreach($slot as $ss=>$addslot)
                                    {                                        
                                        // print_r($addslot);//exit;
                                       $insert= array('calendar_day_section_id'=>$lastid,'doctor_id'=>auth()->user()->id,'slot_time'=>$addslot); 
                                        DB::table('calendar_day_section_times')->insert($insert);
                                    }
                                }
                            }
                        }
                    }
                }
              ///  exit;
            }
             // exit;
        }
        // exit;
               
            
        return new RedirectResponse(route('users.timeavailability-slots'), ['message' => __('The slots successfully created.')]);
    }


    public function edit($id=null)
    {
        // $slots= AvailabilitySlot::with('getSlots')
        //  ->where('calendar_day_sections.id',$id)
        //  ->first();
        $slots=DB::table('calendar_day_sections')->where('calendar_day_sections.id',$id)
        ->leftjoin('calendar_day_section_times','calendar_day_section_times.calendar_day_section_id','=','calendar_day_sections.id')
        ->select('calendar_day_sections.*','calendar_day_section_times.slot_time')
        ->first();
       //echo '<pre>';print_r($slots);exit;
        return view('frontend.nursing.timeavailability-slots.edit',compact('slots'));
    }


    public function updateStatus(Request $request)
    {
        $data = $request->all();
        //print_r($data);exit();
        AvailabilitySlot::where('day_code',$data['day_code'])
        ->where('doctor_id',auth::user()->id)
        ->update(['status'=>$data['status']]);
        if($data['status']==0)
        {
            return response()->json(['error' => 'Slots off successfully updated','status'=>0]);
        }
            return response()->json(['success' => 'Slots on successfully updated','status'=>1]);
    }
}
