<?php
namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use Razorpay\Api\Api;
use Session;
use Exception;
use App\Models\User;
use App\Models\Service;
use App\Models\BookSlot;
use App\Models\SubscriptionPlan;
use App\Models\AvailabilitySlot;
use App\Models\AvailabilityTimes;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Models\Role;
use App\Notifications\NewBooking;
use DB;
date_default_timezone_set('Asia/Kolkata');
class BookAppointmentsController extends Controller
{
	public function GetBooking(Request $request)
    {   
       //echo"<pre>"; print_r($request->all()); die();

        //Razorpay Gateway urls
        $input = $request->all();   
        // $api = new Api(env('RAZOR_KEY'), env('RAZOR_SECRET'));
        // $payment = $api->payment->fetch($input['razorpay_payment_id']);

        if(count($input)  && !empty($input['razorpay_payment_id'])) {
            try {
                $response = $api->payment->fetch($input['razorpay_payment_id'])->capture(array('amount'=>$payment['amount'])); 
  
            } catch (Exception $e) {
                echo 'failed';
                exit;
                // return redirect()->back()->with('failed', $e->getMessage());
            }
        }
     //   echo"<pre>"; print_r($response); die();

        $mydate =explode(',', $request->booking_date);
        $mergedate= $mydate[1].''.$mydate[2];
        $check_date=date('Y-m-d', strtotime($mergedate));
        //echo "<pre>"; print_r($mydate); exit; 
        $con=array('user_id' => Auth::User()->id, 'doctor_id' => $request->doctor_id, 'service_id' => $request->service_id, 'booking_day' => isset($mydate[0])?$mydate[0]:"", 'booking_date' => isset($check_date)?$check_date:"",'booking_time'=>$request->booking_time, 'message' => $request->message, 'patient_name' => $request->patient_name, 'email' => $request->email, 'contact_num' => $request->contact_num, 'house_num' => $request->house_num, 'address' => $request->address, 'landmark' => $request->landmark, 'lat' => $request->lat, 'lng' => $request->lng);
        $lastid=DB::table('booking_appointments')->insertGetId($con);

      	// $insert=array('txn_id'=>$payment->id,'booking_id'=>$lastid,'total_amount'=>$request->total_amount,'currency'=>$payment->currency,'payment_method'=>'Razorpay','payment_status'=>1); 
        // DB::table('booking_appointment_payments')->insert($insert);

        // send booking notification to nursing professional //
        $user=User::where('id',$request->doctor_id)->first();
        $user->title="You have new appointment Request!";
        $user->text='Hello' .' '.$user->name.' '.'you have new appointment request!';
        
        /* Email sending function to nursing professional*/
        $message="Dear Nursing, You have new appointment #".$request['booking_id']." request from careceeker.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
                'appointment_id' =>   $lastid,
                'careseeker_name'=>   $request->patient_name,
                'service_name'   =>   $request->service_id,
                'appointment_date' => $mergedate,
                'appointment_day' =>  $mydate[0],
                'appointment_time' => $request->booking_time,
                'total_amount'    =>  $request->total_amount,
                'message'         =>  $request->message
                ];      
        //return view('emails.booking-confirm', compact('messageData'));  
         //print_r($messageData);die();       
        Mail::send('emails.booking-nursing', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Careseeker appointment request');
        });        
        $user->notify(new NewBooking($user->confirmation_code));


        /* Send Booking Notification to admin */
        $user=User::where('user_type',1)->first();
        //printf($user);die();
        $user->title="New appointment booked!";
        $user->text='New booking request!';

        /* Email sending function to admin */
        $message = "New appointment CAREBEE#".$lastid." booked.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
            'appointment_id' =>   $lastid,
            'doctor_name'    =>   $user->name,
            'careseeker_name'=>   $request->patient_name,
            'service_name'   =>   $request->service_id,
            'appointment_date' => $mergedate,
            'appointment_day' =>  $mydate[0],
            'appointment_time' => $request->booking_time,
            'total_amount'    =>  $request->total_amount,
            'message'         =>  $request->message
            ];      
        //return view('emails.booking-confirm', compact('messageData'));  
         //print_r($messageData);die();       
        Mail::send('emails.booking-admin', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('New appointment request on Carebee');
        });        
        $user->notify(new NewBooking($user->confirmation_code));


        /* Send Booking Notification to careseeker */
        $user=User::where('id',Auth::User()->id)->first();
        //print_r($user);die();
        $user->title="Your Appointment booked successfully!";
        $user->text='Hello' .' '.auth::user()->name.' '.'your appointment request accepted successfully!';
        
        /* Email sending function to careseeker */
        $message ="Dear Careseeker, Your appointment #CAREBEE".$lastid." request sent to selected Nursing.";           
        $email = $user['email']; /* getting user email */
        $messageData=[
                'appointment_id' =>   $lastid,
                'doctor_name'   =>    $user->name,
                'doctor_address'   => $user->address,
                'service_name'   =>   $request->service_id,
                'appointment_date' => $mergedate,
                'appointment_day' =>  $mydate[0],
                'appointment_time' => $request->booking_time,
                'total_amount'    =>  $request->total_amount
                ]; 
        //print_r($messageData);die();
        //return view('emails.booking-careseeker', compact('messageData'));  

        Mail::send('emails.booking-careseeker',['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Appointment requested Successfully');
            
        });
        $user->notify(new NewBooking($user->confirmation_code));

        $deviceId=DB::table('users')->where('id',$request->doctor_id)->first(); 
        //echo "<pre>"; print_r($deviceId); die();
        $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

        $noti_type='booking';
        $title='Appointment booked';
        $message='Your have new appointment booking Request';      
            
        $this->postpushnotification($device_id,$title,$message,$noti_type);

        echo 'success';
        //return redirect()->to('dashboard')->with('message','Your appointment submited successfully !');
    }

    /* get all Appointment by nursing professional */
    public function getAppointments(Request $request)
    {
    	$booking_data=DB::table('booking_appointments')
    	->leftjoin('users AS A', 'A.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS D', 'D.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS E', 'E.id', '=', 'booking_appointments.user_id')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=', 'booking_appointments.id')
        ->join('services','services.id','=', 'booking_appointments.service_id')
        ->where('booking_appointments.doctor_id', Auth::User()->id)
        ->select('booking_appointments.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar','D.email as email','E.mobile as mobile','services.service_name','services.price','booking_appointment_payments.txn_id','booking_appointment_payments.total_amount','booking_appointment_payments.currency','booking_appointment_payments.payment_method')
        ->orderBy('booking_appointments.booking_date', 'desc')
    	->get();
    	//echo "<pre>";print_r($booking_data); die();
        return view('frontend.nursing.appointments',compact('booking_data'));
    }

    /* Confirm Appointment by Nursing Professional */
    public function getConfirm(Request $request,$id = NULL)
    {
        //print_r($id); die();
        DB::table('booking_appointments')->where('id', $id)->update(['status' => 'Confirm']);

        // get appointment confirmation notification //
        $userinfo=DB::table('booking_appointments')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->join('services','services.id','=','booking_appointments.service_id')
        ->where('booking_appointments.id', $id)
        ->select('booking_appointments.*','booking_appointment_payments.txn_id','booking_appointment_payments.booking_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status','services.service_name')
        ->first();
        //echo"<pre>"; print_r($userinfo);die();
        $user=User::where('id',$userinfo->user_id)->first();
        $user->title="Your Appointment Confirmed!";
        $user->text='Hello' .' '.$user->name.' '.'Appointment confirmed by Nursing!';

        /* Email sending function to Careseeker after confirm appointment by Nursing Professional*/
        $message="Dear Careseeker your appoinment #".$request['booking_id']." Confirmed by Nursing.";           
        $email = $user['email']; /* getting user email */
        //printf($email);die();
        $messageData=[
                'appointment_id' =>   $userinfo->id,
                'doctor_name'    =>   Auth::User()->name,
                'service_name'   =>   $userinfo->service_name,
                'appointment_date' => $userinfo->booking_date,
                'appointment_day' =>  $userinfo->booking_day,
                'appointment_time' => $userinfo->booking_time,
                'total_amount'    =>  $userinfo->total_amount,
                'message'         =>  $userinfo->message
                ];      
        //return view('emails.booking-confirm', compact('messageData'));  
        //echo"<pre>"; print_r($messageData);die();       
        Mail::send('emails.booking-confirmed', ['messageData1'=> $messageData], function($message) use($email)
        {
            $message ->to($email)->subject('Appointment Confirmed Successfully');
        });        
        $user->notify(new NewBooking($user->confirmation_code));

        $deviceId=DB::table('users')->where('id',$userinfo->user_id)->first(); 
        //echo "<pre>"; print_r($deviceId); die();
        $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

        $noti_type='';
        $title='Appointment accepted';
        $message='Your appointment accepted successfully';      
            
        $this->postpushnotification($device_id,$title,$message,$noti_type);

        return redirect()->back()->with('message','Appointment Confirmed successfully! ');
    }

	/* Cancel/Reject Appointment by Nursing Professional */    
	public function getReject(Request $request,$id = NULL)
    {
        $reason= $request->cancel_reason;
        $todaydate = date('Y-m-d H:i:s');
        DB::table('booking_appointments')->where('id', $id)->update(['status' => 'Reject Request','user_type' => 2, 'cancellation_request_time' => $todaydate, 'cancel_reason' => $reason]);

        // get appointment cancel notification //
        $userinfo=DB::table('booking_appointments')->where('id', $id)->first();
        $user=User::where('id',$userinfo->user_id)->first();
        $user->title="Your Appointment Cancel Request to Admin !";
        $user->text='Hello' .' '.$user->name.' '.'you appointment cancele request sent to admin by Nursing staff, Cancelation will confirm by admin.!';
        $user->notify(new NewBooking($user->confirmation_code));

        // Send cancel Notification to admin //
        $user=User::where('user_type',1)->first();
        $user->title="Appointment cancel request!";
        $user->text='You received appointment cancel request by nursing staff, appointment will cancel after your confirmation.!';
        $user->notify(new NewBooking($user->confirmation_code));

        $deviceId=DB::table('users')->where('id',$userinfo->user_id)->first(); 
        //echo "<pre>"; print_r($deviceId); die();
        $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

        $noti_type='';
        $title='Appointment cancelation request';
        $message='Your appointment cancellation request submited';

        return redirect()->back()->with('warning','Appointment Cancelation request sent to the admin !');
    }

    /* Chnage status Complete Appointment by Nursing Professional */
    public function getComplete(Request $request,$id = NULL)
    {
        $booking_info=DB::table('booking_appointments')->where('booking_appointments.id', $id)
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->first();
        // showing Commission fee from Commission table         
        $service_amount= DB::table('service_fees')->get();
        $todaydate = date('Y-m-d H:i:s');
        $mydates =explode(' ', $todaydate);
        $mergedate= $mydates[0].''.$mydates[1];

        //print_r($service_amount); die();

        if($booking_info->status =='Confirm')
            { 
                $amount=$booking_info->total_amount;
                $commission=$service_amount[0]->service_fee;
                $earning_amount= ($amount/100) * $commission;
               // echo "<pre>"; print_r($earning_amount); die();
                DB::table('booking_appointments')->where('id', $id)->update(['booking_status' => 'Complete', 'booking_appointments.commission_charge' => isset($service_amount[0]->service_fee)?$service_amount[0]->service_fee:'', 'booking_appointments.commission_amount' => isset($earning_amount)?$earning_amount:'']);

                // get appointment confirmation notification //
                $userinfo=DB::table('booking_appointments')
                ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
                ->join('services','services.id','=','booking_appointments.service_id')
                ->where('booking_appointments.id', $id)
                ->select('booking_appointments.*','booking_appointment_payments.txn_id','booking_appointment_payments.booking_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status','services.service_name')
                ->first();
                //echo"<pre>"; print_r($userinfo);die();
                $user=User::where('id',$userinfo->user_id)->first();
                $user->title="Your Appointment Completed Successfully!";
                $user->text='Hello' .' '.$user->name.' '.'Appointment Completed successfully!';

                /* Email sending function to Careseeker after confirm appointment by Nursing Professional*/
                $message="Dear Careseeker your appoinment #".$request['booking_id']." completed successfully.";           
                $email = $user['email']; /* getting user email */
                //printf($email);die();
                $messageData=[
                        'appointment_id' =>   $userinfo->id,
                        'doctor_name'    =>   Auth::User()->name,
                        'service_name'   =>   $userinfo->service_name,
                        'appointment_date' => $userinfo->booking_date,
                        'appointment_day' =>  $userinfo->booking_day,
                        'appointment_time' => $userinfo->booking_time,
                        'total_amount'    =>  $userinfo->total_amount,
                        'message'         =>  $userinfo->message
                        ];      
                //return view('emails.booking-confirm', compact('messageData'));  
                //echo"<pre>"; print_r($messageData);die();       
                Mail::send('emails.booking-complete', ['messageData1'=> $messageData], function($message) use($email)
                {
                    $message ->to($email)->subject('Appointment Completed Successfully');
                });        
                $user->notify(new NewBooking($user->confirmation_code));

                $deviceId=DB::table('users')->where('id',$userinfo->user_id)->first(); 
                //echo "<pre>"; print_r($deviceId); die();
                $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

                $noti_type='';
                $title='Appointment completed';
                $message='Your appointment completed successfully.';

                return redirect()->back()->with('message','Appointment Completed successfully! ');
            }
    }

    /* Pending Appointment by Nursing Professional */ 
    public function getPending($id = NULL)
    {
        DB::table('booking_appointments')->where('id', $id)->update(['status' => 'Pending']);
        return redirect()->back()->with('success','Re-open Appointment');
    }

    /* get all booking by careseeker */
    public function MyAppointments(Request $request)
    {
        $booking_appoin = DB::table('booking_appointments')
        ->leftjoin('users AS A', 'A.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'booking_appointments.doctor_id')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=', 'booking_appointments.id')
        ->join('services','services.id','=', 'booking_appointments.service_id')
        ->where('booking_appointments.user_id', Auth::User()->id)
        ->select('booking_appointments.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar','services.service_name','services.price','booking_appointment_payments.txn_id','booking_appointment_payments.total_amount','booking_appointment_payments.currency','booking_appointment_payments.payment_method')
        ->orderBy('booking_appointments.booking_date', 'desc')
        ->paginate(5);
        //echo "<pre>";print_r($booking_appoin);die();
        return view('frontend.users.my-appointment',compact('booking_appoin'));
    }

    /* Cancel Appointment by Careseeker */ 
    public function MakeCancel(Request $request,$id = NULL)
    {
        //echo "<pre>";print_r($request->all()); die();
        $reason= $request->cancel_reason;
        DB::table('booking_appointments')->where('id', $id)->update(['status' => 'Reject Request','user_type' => 3, 'cancellation_request_time' => date("Y-m-d H:i:s"), 'cancel_reason' => $reason]);

        // Send cancel Notification to admin by careseeker //
        $user=User::where('user_type',1)->first();
        $user->title="Appointment cancel request by Care Seeker!";
        $user->text='Appointment cancel request sent to the admin, admin will action soon on your request!';
        $user->notify(new NewBooking($user->confirmation_code));
        return redirect()->back()->with('message','appointment Cancelation request sent to admin!');
    }


    /* Transaction History Show for Careseeker & Nursing staff */
    public function TransactionHistory(Request $request)
    {
        /* get Transaction data for Careseeker */
        $transactionData=DB::table('booking_appointments')
        ->leftjoin('users', 'users.id', '=', 'booking_appointments.user_id')
        ->leftjoin('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->where('booking_appointments.user_id', Auth::User()->id)
        ->select('booking_appointments.*','users.name','booking_appointment_payments.txn_id','booking_appointment_payments.booking_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status')
        ->get();
        //echo "<pre>";print_r($transactionData); die();


        /* get Transaction data for Nursing Staff */
        $NursingTransaction=DB::table('booking_appointments')
        ->leftjoin('users', 'users.id', '=', 'booking_appointments.user_id')
        ->leftjoin('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->where('booking_appointments.doctor_id', Auth::User()->id)
        ->select('booking_appointments.*','users.name','booking_appointment_payments.txn_id','booking_appointment_payments.booking_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.commission','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status')
        ->get();
        return view('frontend.pages.transaction-history',compact('transactionData','NursingTransaction'))->with('no', 1);
    } 
}
