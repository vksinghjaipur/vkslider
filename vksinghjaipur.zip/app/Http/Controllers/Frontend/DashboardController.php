<?php
namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\User;
use App\Models\SubscriptionPlan;
use App\Models\UserSubscriptionPlan;
use App\Models\Service;
use App\Models\BookSlot;
use App\Models\BecomeNursing;
use App\Models\Faq;
use App\Models\AvailabilitySlot;
use App\Models\AvailabilityTimes;
use App\Models\UserFeedback;
use Exception;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Crypt;
use Log;
use DB;

class DashboardController extends Controller
{
    public function index()
    {
        $role = Auth::user()->roles()->get();
        /* Nursing Professional Dashboard from here */
        if ($role[0]['id'] == 2) /* Doctor Role ID == 2 */ {
        
        /* Feedback Average & Count */    
        $feedbackNursing = DB::table('user_feedbacks')
        ->leftjoin('users AS A', 'A.id', '=', 'user_feedbacks.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'user_feedbacks.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'user_feedbacks.user_id')
        ->where('user_feedbacks.doctor_id', Auth::User()->id)
        ->select('user_feedbacks.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar')
        ->get();

        /* Show Total & today Revenew */ 
        $revenewNursing = DB::table('booking_appointments')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->where('booking_appointments.doctor_id', Auth::User()->id)
        ->get();

        /* show list of bookings */
        $booking_data=DB::table('booking_appointments')
        ->leftjoin('users AS A', 'A.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS D', 'D.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS E', 'E.id', '=', 'booking_appointments.user_id')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=', 'booking_appointments.id')
        ->join('services','services.id','=', 'booking_appointments.service_id')
        ->where('booking_appointments.doctor_id', Auth::User()->id)
        ->select('booking_appointments.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar','D.email as email','E.mobile as mobile','services.service_name','services.price','booking_appointment_payments.txn_id','booking_appointment_payments.total_amount','booking_appointment_payments.currency','booking_appointment_payments.payment_method')
        ->orderBy('booking_appointments.booking_date', 'desc')
        ->get()->take(4);

        /* Show total booking */
        $totalbooking=DB::table('booking_appointments')->where('doctor_id',auth::user()->id)->count();

        $todaydate = date('Y-m-d');
        $todaybooking=DB::table('booking_appointments')->where('doctor_id',auth::user()->id)->where('booking_date',$todaydate)->count();

        /* get which day active */
        $daysNursing=DB::table('calendar_day_sections')->whereRaw("(doctor_id = '".auth::user()->id."')")->where('status',1)->get();

        //$emailexist = DB::table('users')->whereRaw("(email = '".$email."' AND deleted_at IS null )")->first();

        return view('frontend.nursing.dashboard',compact('feedbackNursing','revenewNursing','booking_data','totalbooking','todaybooking','daysNursing'))->with('no', 1);
        }

        /* Care Seeker/Patient Dashboard */
        else {
         
        /* show favorite data */
        $favoriteData = DB::table('users')
        ->join('favorites', 'favorites.doctor_id', '=', 'users.id')
        ->join('userprofiles', 'userprofiles.user_id', '=', 'users.id')
        ->where('favorites.user_id', Auth::User()->id)
        ->select('users.*', 'userprofiles.*')
        ->get();

        /* Feedback Count */    
        $total_feedback = DB::table('user_feedbacks')
        ->leftjoin('users AS A', 'A.id', '=', 'user_feedbacks.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'user_feedbacks.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'user_feedbacks.user_id')
        ->where('user_feedbacks.user_id', Auth::User()->id)
        ->select('user_feedbacks.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar')
        ->get();

        /* Show total booking */
        $totalbooking=DB::table('booking_appointments')->where('user_id',auth::user()->id)->count();

        $todaydate = date('Y-m-d');
        $todaybooking=DB::table('booking_appointments')->where('user_id',auth::user()->id)->where('booking_date',$todaydate)->count();
        return view('frontend.users.dashboard',compact('favoriteData','total_feedback','totalbooking','todaybooking'));
        }
    }

    
    /* get Services list & Faqs */
    public function getServices(Request $request)
    {
        $get_services=Service::where('status',1)->get();
        $get_faqs=Faq::where('status',1)
        ->orderBy('id','ASC')
        ->get();
        return view('frontend.pages.services',compact('get_services','get_faqs'));
    }


    /* get Nursing list */
    public function getNursingList(Request $request)
    {   
        $query=User::where('user_type',2)
        ->leftjoin('userprofiles','userprofiles.user_id','=','users.id')
        ->join('services','services.id','=','users.service_id')
        ->where('users.confirmed',1)
        ->where('users.status',1) // B'coz admin can block to doctor then status will '2'.so need check status = 1
        ->whereNotNull('users.email')->whereNotNull('users.mobile')->whereNotNull('users.service_id')->whereNotNull('users.date_of_birth')->whereNotNull('userprofiles.specializations')->whereNotNull('userprofiles.experience')->whereNotNull('userprofiles.license_number')->whereNotNull('userprofiles.bank_details')->whereNotNull('userprofiles.ifsc_code')
        ->select('users.*','userprofiles.user_id','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin','services.service_name');

        if(isset($_REQUEST['name'])&& !empty($_REQUEST['name']))
        {
            $query->where('users.name','like', '%' . $_REQUEST['name'] . '%');
        }

        if(isset($_REQUEST['service_id'])&& !empty($_REQUEST['service_id']))
        {
            $query->where('services.service_name',$_REQUEST['service_id']);
        }
        $getDocList=$query->paginate(12);

       // echo'<pre>';print_r($getDocList);exit;

        /* get favorite data for each user*/
        $favoritData = array();
        if(isset(Auth::User()->id)){
            $favoritData = DB::table('favorites')->where('user_id', Auth::User()->id)->pluck('doctor_id')->toArray();
        }
        return view('frontend.pages.nursing-list',compact('getDocList','favoritData'));
    }

    /* get Nursing detail */
    public function getNursingDetail(Request $request, $id=null)
    {
        $id = base64_decode($id);
        $doctor_id=$id;
        $DocDetail=User::where('users.id',$id)
        // ->join('userprofiles','userprofiles.user_id','=','users.id')
        // ->join('services','services.id','=','users.service_id')
        ->first();
       // echo "<pre>";print_r($DocDetail); die();
        
        /* Get All reviews according user */
        $show_feedbacks=UserFeedback::where('user_feedbacks.doctor_id', $id)
        ->join('users','users.id','=','user_feedbacks.user_id')
        ->where('user_feedbacks.status',1)
        ->get();
        //echo "<pre>";print_r($show_feedbacks); die();
        return view('frontend.pages.nursing-detail',compact('DocDetail','doctor_id','show_feedbacks'));
    }

    /* get nursing available slots */
    public function availableSlotes(Request $request)
    {
        if($request->day=='Sun')
        {
            $day='sun';
        }
        elseif($request->day=='Mon')
        {
            $day='mon';
        }
        elseif($request->day=='Tue')
        {
            $day='tue';
        }
        elseif($request->day=='Wed')
        {
            $day='wed';
        }
        elseif($request->day=='Thu')
        {
            $day='thu';
        }
        elseif($request->day=='Fri')
        {
            $day='fri';
        }
        elseif($request->day=='Sat')
        {
            $day='sat';
        }
        $mydate =explode(',', $request->date);
        $mergedate= $mydate[1].''.$mydate[2];
        $check_date=date('Y-m-d', strtotime($mergedate));
        $bookingslot= DB::table('booking_appointments')->where('doctor_id',$request->id)->where('booking_date',$check_date)->pluck('booking_time')->toArray();
       // print_r($bookingslot);exit;

        $slots=AvailabilitySlot::with('getSlots')
        ->where('calendar_day_sections.doctor_id', $request->id)
        ->where('day_code',$day)
        ->where('calendar_day_sections.status',1)
        ->orderBy('title','DESC')
        ->get();
       // echo '<pre>'; print_r($slots);exit;
        $html='';
        if(count($slots)>0)
        {
            foreach ($slots as $key => $slotday)
            {
                if($slotday->title=='mor'){
                $html.='<label class="slot-detail">'.'Morning'.' Section('.($slotday->start_time).' - '.($slotday->end_time).')</label><ul>';
                }
                if($slotday->title=='aft'){
                 $html.='<label class="slot-detail">'.'Afternoon'.' Section('.($slotday->start_time).' - '.($slotday->end_time).')</label><ul>';
                }
                if($slotday->title=='eve'){
                 $html.='<label class="slot-detail">'.'Evening'.' Section('.($slotday->start_time).' - '.($slotday->end_time).')</label><ul>';
                };
                
                foreach ($slotday->getSlots as $d => $time)
                {   
                    if(in_array($time->slot_time, $bookingslot))
                    {
                         $html.='<li class="bookingTimetget alreadybooking" data-time="'.$time->slot_time.'"><input type="radio" name="slotno" disabled><span style="background-color:red;color:white;">'.$time->slot_time.'</span></li>';
                    }
                    else
                    {
                         $html.='<li class="bookingTimetget" data-time="'.$time->slot_time.'"><input type="radio" name="slotno"><span>'.$time->slot_time.'</span></li>';
                    }
                }
                    $html.='</ul>';
            }
        }
        echo $html;
    }

    /* User feedback for Nursing */
    public function addFeedback(Request $request)
    {
        //echo"<pre>";print_r($request->all()); die();
        $data = DB::table('booking_appointments')->where('user_id', auth::user()->id)
        ->where('doctor_id',$request->doctor_id)->first();
       // print_r($data);die();
        if(!empty($data))
        {
            if($request -> ismethod('post'))
            {
                $data = $request->all();
                $addfeedback = new UserFeedback;
                $addfeedback->doctor_id = $data['doctor_id'];
                $addfeedback->ratings = $data['ratings'];
                $addfeedback->user_id = auth()->user()->id;
                $addfeedback->feedback = $data['feedback'];
                $addfeedback->status = $data['status'] ?? 1;
                $addfeedback->save();
            }
        }
        else
        {
        return redirect()->back()->with('info','You have not used this service, you can not leave feedback !');
        }  
        return redirect()->back()->with('message','Your feedback updated successfully !');
        
    } 

    /* get feedback */
    public function getFeedback(Request $request)
    {
        /* get feedback data for Careseeker */
        $feedbackData = DB::table('user_feedbacks')
        ->leftjoin('users AS A', 'A.id', '=', 'user_feedbacks.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'user_feedbacks.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'user_feedbacks.doctor_id')
        ->where('user_feedbacks.user_id', Auth::User()->id)
        ->select('user_feedbacks.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar')
        ->get();

        /* get feedback data for Nursing */
        $feedbackNursing = DB::table('user_feedbacks')
        ->leftjoin('users AS A', 'A.id', '=', 'user_feedbacks.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'user_feedbacks.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'user_feedbacks.user_id')
        ->where('user_feedbacks.doctor_id', Auth::User()->id)
        ->select('user_feedbacks.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar')
        ->get();
        return view('frontend.users.feedbacks',compact('feedbackData','feedbackNursing'));
    }    

    /* Add Favorites by Careseeker */
    public function getAddFavorites($id=NULL)
    {
        $data = DB::table('favorites')->where('user_id', Auth::User()->id)
        ->where('doctor_id',  $id)->first();
        if(empty($data))
        {
            DB::table('favorites')->insert(['user_id' => Auth::User()->id, 'doctor_id' => $id]);
        }
        return redirect()->back()->with('message','Nursing profile added in your favorite list.');
    }

    /* Remove Favorites by Careseeker */
    public function getRemoveFavorites($id=NULL)
    {
        $data = DB::table('favorites')->where('user_id', Auth::User()->id)
        ->where('doctor_id', $id)->first();
        if(!empty($data)){
            DB::table('favorites')->where('id', $data->id)->delete();
        }
        return redirect()->back()->with('warning','Nursing profile removed from your favorite list.');
    }    

    /* getFavorites by Careseeker */

    public function getFavorites(Request $request)
    {
        $favoriteData = DB::table('users')
        ->join('favorites', 'favorites.doctor_id', '=', 'users.id')
        ->join('userprofiles', 'userprofiles.user_id', '=', 'users.id')
        ->where('favorites.user_id', Auth::User()->id)
        ->select('users.*', 'userprofiles.*')
        ->orderBy('users.id', 'DESC')
        ->limit(4)
        ->get()->toArray();
        //echo "<pre>"; print_r($favoriteData); exit;
        return view('frontend.users.favorites',compact('favoriteData'));
    }


     /* Become a Nursing */
    public function BecomeNursing(Request $request)
    {
        //echo"<pre>";print_r($request->all()); die();
        if($request -> ismethod('post')){
           $data = $request->all();
           $req_data = new BecomeNursing;
            //echo "<pre>";print_r($data);die;
            $req_data->first_name = $data['first_name'];
            $req_data->last_name = $data['last_name'];

            $req_data->email = $data['email'];
            $req_data->contact_num = $data['contact_num'];

            $req_data->gender = $data['gender'];
            $req_data->experience = $data['experience'];
            $req_data->specialization = $data['specialization'];

            $req_data->city = $data['city'];
            $req_data->state = $data['state'];
            $req_data->country = $data['country'];
            $req_data->zip_code = $data['zip_code'];

            $req_data->address1 = $data['address1'];
            $req_data->address2 = $data['address2'];

            $req_data->about_me = $data['about_me'];

           $req_data->save();    
           return redirect()->back()->with('message','Your requested data submited successful!');
        }
            return view('frontend.index');
    } 
}
