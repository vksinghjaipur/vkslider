<?php
namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use App\Models\Page;
use App\Models\Service;
use App\Models\Testimonial;
use App\Models\User;
use App\Models\Banner;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use DB;

class FrontendController extends Controller
{
    
    public function index()
    {
        $body_class = '';
        $services=Service::where('is_featured',1)
        ->where('status',1)->get();
        $my_testi=Testimonial::where('status',1)->get();
        $banners=Banner::where('status',1)->get();
        return view('frontend.index', compact('body_class','services','my_testi','banners'));
    }

    public function index2()
    {
        $body_class = '';
        $services=Service::where('is_featured',1)
        ->where('status',1)->get();
        $my_testi=Testimonial::where('status',1)->get();
        $banners=Banner::where('status',1)->get();
        return view('frontend.demo-index', compact('body_class','services','my_testi','banners'));
    }

    
    public function privacy()
    {
        $body_class = '';

        return view('frontend.privacy', compact('body_class'));
    }

    
    public function terms()
    {
        $body_class = '';

        return view('frontend.terms', compact('body_class'));
    }

    /* pages view */

    public function getPages($page_slug)
    {
        $page = Page::where('page_slug',$page_slug)->first();
        if(empty($page->title)) {
            return redirect()->back()->with('error', 'Url Does not exist');
            // return redirect()->back()->withFlashInfo('Url Does not exist');
        }
        return view('frontend.pages.pages',compact('page'));
    }

    public function getAboutus()
    {
        $body_class = '';
        return view('frontend.pages.aboutus', compact('body_class'));
    }

    /* function for add countries in db */

    public function getCountries(Request $request)
    { 
        $fileD = fopen(base_path('public/countries.csv'), 'r');
        $column=fgetcsv($fileD);
        while(!feof($fileD)){
         $rowData[]=fgetcsv($fileD);
        }
        foreach ($rowData as $key => $value) {
            $inserted_data=array('sortname'=>$value[0],
                                 'name'=>$value[1],
                                 'phonecode'=>$value[2],
                            );
            
             Country::insert($inserted_data);
        }
        echo 'Country list Data Updated Successfully.!';exit;
    } 

    /* function for add states in db */

    public function getStates(Request $request)
    { 
        $fileD = fopen(base_path('public/states.csv'), 'r');
        $column=fgetcsv($fileD);
        while(!feof($fileD)){
         $rowData[]=fgetcsv($fileD);
        }
        foreach ($rowData as $key => $value) {
            $inserted_data=array('name'=>$value[0],
                                 'country_id'=>$value[1],
                            );
            
            State::insert($inserted_data);
        }
        echo 'State list Data Updated Successfully.!';exit;
    } 

    /* function for add Cities in db */

    public function getCities(Request $request)
    { 
        $fileD = fopen(base_path('public/cities.csv'), 'r');
        $column=fgetcsv($fileD);
        while(!feof($fileD)){
         $rowData[]=fgetcsv($fileD);
        }
        foreach ($rowData as $key => $value) {
            $inserted_data=array('name'=>$value[0],
                                 'state_id'=>$value[1],
                            );
            
            City::insert($inserted_data);
        }
        echo 'City list Data Updated Successfully.!';exit;
    } 
}
