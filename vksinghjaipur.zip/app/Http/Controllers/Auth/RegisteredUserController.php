<?php
namespace App\Http\Controllers\Auth;
use App\Events\Frontend\UserRegistered;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Service;
use App\Models\SubscriptionPlan;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use App\Notifications\Auth\UserNeedsConfirmation;
use App\Events\Frontend\UserConfirmed;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Role;
use DB;
class RegisteredUserController extends Controller
{
    public function create()
    {
        $getrole=Role::where('id', '!=', 1)->get();
        $getservices=Service::where('status', 1)->get();
        //echo "<pre>"; print_r($getrole); die();
        return view('auth.register',compact('getrole','getservices'));
    }
    
    public function store(Request $request)
    {
        //echo "<pre>"; print_r($request->all()); die();
        $request->validate([
            'username'   => 'required|string|max:191|unique:users',
            'first_name' => 'required|string|max:191',
            'last_name'  => 'required|string|max:191',
            //'mobile'     => 'required|unique:users|numeric|min:10',
            'email'      => 'required',
            'password'   => 'required|alpha_num|confirmed|min:6',
        ]);

        if(filter_var($request->email, FILTER_VALIDATE_EMAIL))
            {
                $email = $request->email;
            }
            else
            {
                $phone = $request->email;
            }


        if(!empty($email))
            { 
                $emailexist = DB::table('users')->whereRaw("(email = '".$email."' AND deleted_at IS null )")->first();

                if(!empty($emailexist))
                {
                    return Redirect()->route('register')->with('error','Email Already taken.!');
                  //  echo "Email Already taken";exit;

                }
            }

            if(isset($phone) && !empty($phone))
            {
                $mobilecheck = DB::table('users')->whereRaw("(mobile = '".$phone."' AND deleted_at IS null )")->first();
                if(!empty($mobilecheck))
                {
                    return Redirect()->route('register')->with('error','Mobile Already taken.!');
                    //echo "Mobile Already taken";exit;
                }
            }    

        $service_name=0;
        if(isset($request['service_id'])&& !empty($request['service_id']))
        {
           $service_name= implode(',',$request['service_id']);
        }
        
        $user = User::create([
            'first_name' => $request->first_name,
            'last_name'  => $request->last_name,
            'username'   => $request->username,
            'name'       => $request->first_name . ' ' . $request->last_name,
            'mobile'     => isset($phone)?$phone:'',
            'email'      => isset($email)?$email:'',
            'service_id' =>$service_name,
            'password'   => bcrypt($request->password),
            'confirmation_code' => md5(uniqid(mt_rand(), true)),
            'verify_otp' => rand(111111,999999),
            'user_type'  => $request->user_type,
        ]);

        // username
        // $username = config('app.initial_username') + $user->id;
        // $user->username = $username;
        $user->save();

        $roles=$request->user_type;
        $user->syncRoles($roles);
        $user->notify(new UserNeedsConfirmation($user->confirmation_code));

        // If the user must confirm their email or their account requires approval,
        // if active this auth direct login without confirmation.
        //Auth::login($user);

        //event(new Registered($user));
        event(new UserRegistered($user));

        return Redirect()->route('login')->with('success','Your account was successfully created. We have sent you an e-mail to confirm your account.!');

        //return redirect(RouteServiceProvider::HOME);
        //return redirect($this->redirectPath());
    }
}
