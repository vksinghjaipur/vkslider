<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use App\Exceptions\GeneralException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Events\Frontend\UserConfirmed;
use App\Models\User;
use Flash;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     *
     * @param \App\Http\Requests\Auth\LoginRequest $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(LoginRequest $request)
    {
        $request->authenticate();

        $request->session()->regenerate();

        if(Auth::user()->hasRole(['administrator'])) {
            $redirectTo = 'admin/dashboard';
        }else{ 
            $redirectTo = 'dashboard';
            //return redirect()->intended('/');
            //return Redirect::back();
            //return back();
            //$redirectTo = request()->redirectTo;
        }


        //$redirectTo = request()->redirectTo;

        if ($redirectTo) {
            return redirect($redirectTo);
        } else {
            //return redirect(RouteServiceProvider::HOME);
            return redirect()->route('backend.dashboard');
        }
    }

    /**
     * Destroy an authenticated session.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }

    public function confirm($token)
    {
        $user = User::where('confirmation_code',$token)->first();
        if ($user->confirmed==1) {
             Flash::success('<i class="fas fa-check"></i> Your account is already confirmed.')->important();
            return redirect()->route('login');
        }
        else{
                 $user->confirmed=1;
                 $user->save();
           Flash::success('<i class="fas fa-check"></i> Your account is confirmed.')->important();
            return redirect()->route('login');
        }
    }

    public function findByConfirmationCode($token)
    {
       $user = User::where('confirmation_code',$token)->first();

        if ($user->confirmed==1) {
             Flash::success('<i class="fas fa-check"></i> Your account is already confirmed.')->important();
            return redirect()->route('login');
        }
        return $user;
    }
}
