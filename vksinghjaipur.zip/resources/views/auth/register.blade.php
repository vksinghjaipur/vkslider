@extends('frontend.layouts.app')

@section('title') @lang('Register') @endsection

@section('content')

<style>
    header.header-global {
        display: none;
    }
    .site-footer {
        display: none;
    }
</style>


<div class="inner-login-section">
    <div class="container">
        <div class="login-box">
            <div class="row justify-content-center">
                <div class="col-lg-6 pr-0">
                    <!-- @include('auth.social_login_buttons') -->
                    <div class="login-form-right">
                        <div class="login-logo">
                            <a href="{{url('/')}}">
                                <img src="{{asset('img/logo.png')}}">
                            </a>
                        </div>
                        <h3>Sign up </h3>
                        <form role="form" method="POST" action="{{ route('register') }}">
                            @csrf
                            <label class="font-weight-bold">Choose Profile:-</label>
                            <div class="form-group row">
                                @foreach($getrole as $rolevalue)
                                    <div class="col-md-6">
                                        <div class="custom-control custom-radio">
                                           <input type="radio" value="{{$rolevalue->id}}" onclick="javascript:yesnoCheck();" id="yesCheck" name="user_type" checked>
                                            <label for="{{$rolevalue->name}}">{{ucfirst($rolevalue->name)}}</label>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="{{ old('first_name') }}" placeholder="{{ __('First Name') }}" aria-label="first_name" aria-describedby="first_name" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="{{ old('last_name') }}" placeholder="{{ __('Last Name') }}" aria-label="last_name" aria-describedby="last_name" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" id="username" name="username" value="{{ old('username') }}" placeholder="{{ __('User Name') }}" aria-label="username" aria-describedby="username" required>
                                </div>
                                 <div class="col-md-6">
                                    <!-- <input type="mobile" class="form-control" id="mobile" name="mobile" value="{{ old('mobile') }}" placeholder="{{ __('Enter Mobile') }}" aria-label="mobile" aria-describedby="mobile" required> -->
                                    <input type="text" class="form-control" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address/Mobile') }}" aria-label="email" aria-describedby="email" required>
                                </div> 
                            </div>

                            <!-- <div class="form-group row">
                                <div class="col-md-12">
                                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="email" required>
                                </div>
                            </div>   -->  

                            <div class="form-group row">
                                <div class="col-md-6">
                                     <input type="password" class="form-control" id="password" name="password" placeholder="@lang('Password')" aria-label="@lang('Password')" aria-describedby="password" required>
                                </div>
                                <div class="col-md-6">
                                   <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="@lang('Password Confirmation')" aria-label="@lang('password_confirmation')" aria-describedby="password_confirmation" required>
                                </div>
                            </div>

                            <div class="form-group row" id="ifYes" style="display:none">
                                {{ Form::label('service_id', trans('validation.attributes.backend.access.plans.service_id'), ['class' => 'col-md-2 from-control-label required']) }}

                               <div class="col-md-12">
                                   <select class="form-select select2" id="editor6" multiple="multiple" name="service_id[]" data-placeholder="Select Service">
                                        @foreach($getservices as $servicevalue)
                                            <option value="{{$servicevalue->id ?? ''}}" >{{$servicevalue->service_name}}({{$servicevalue->price}}) </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>


                            <div class="row my-4">
                                <div class="col-12">
                                    <div class="custom-control custom-control-alternative custom-checkbox">
                                        <input class="custom-control-input" id="customCheckRegister" type="checkbox">
                                        <label class="custom-control-label" for="customCheckRegister">
                                           I agree with the <a href="#!">Privacy Policy</a>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn submit-btn">
                                    @lang("Sign Up")
                                </button>
                            </div>
                        </form>
                        <div class="row mt-3">
                            <div class="col-6 text-left">
                                <a href="{{ route('password.request') }}" class="text-gray">
                                  {{ __('Forgot Your Password?') }}
                                </a>
                            </div>

                            <div class="col-6 text-right">
                                <a href="{{ route('login') }}" class="text-gray">
                                    {{ __('Login to account') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 pl-0">
                    <div class="login-left-box">
                        <img src="{{asset('img/login-bg.png')}}">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    // //Datemask dd/mm/yyyy
    // $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    // //Datemask2 mm/dd/yyyy
    // $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    // //Money Euro
    // $('[data-mask]').inputmask()

    //Date range picker
    // $('#reservation').daterangepicker()
    // //Date range picker with time picker
    // $('#reservationtime').daterangepicker({
    //   timePicker         : true,
    //   timePickerIncrement: 30,
    //   format             : 'MM/DD/YYYY h:mm A'
    // })
    //Date range as a button
    // $('#daterange-btn').daterangepicker(
    //   {
    //     ranges   : {
    //       'Today'       : [moment(), moment()],
    //       'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    //       'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
    //       'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    //       'This Month'  : [moment().startOf('month'), moment().endOf('month')],
    //       'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    //     },
    //     startDate: moment().subtract(29, 'days'),
    //     endDate  : moment()
    //   },
    //   function (start, end) {
    //     $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
    //   }
    // )

    //iCheck for checkbox and radio inputs
    // $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
    //   checkboxClass: 'icheckbox_minimal-blue',
    //   radioClass   : 'iradio_minimal-blue'
    // })
    //Red color scheme for iCheck
    // $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
    //   checkboxClass: 'icheckbox_minimal-red',
    //   radioClass   : 'iradio_minimal-red'
    // })
    //Flat red color scheme for iCheck
    // $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
    //   checkboxClass: 'icheckbox_flat-green',
    //   radioClass   : 'iradio_flat-green'
    // })

    //Colorpicker
    //$('.my-colorpicker1').colorpicker()
    //color picker with addon
    //$('.my-colorpicker2').colorpicker()

    //Timepicker
    // $('.timepicker').timepicker({
    //   showInputs: false
    // })
  })
</script> 

<!-- Ye radio button par condition pe kaam kar raha h yadi nursing h to niche select option aayega-->

<script>
    function yesnoCheck() {
    if (document.getElementById('yesCheck').checked) {
        document.getElementById('ifYes').style.display = 'block';
    }
    else document.getElementById('ifYes').style.display = 'none';

}
</script>

@endsection
