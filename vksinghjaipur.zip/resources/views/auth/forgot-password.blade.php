@extends('frontend.layouts.app')

@section('title') @lang('Forgot your password?') @endsection

@section('content')

<style>
    header.header-global {
        display: none;
    }
    .site-footer {
        display: none;
    }
</style>


<div class="inner-login-section">
    <div class="container">
        <div class="login-box">
          <div class="row justify-content-center">
            <div class="col-lg-6 pr-0">
                <div class="login-form-right">
                    <div class="login-logo">
                        <a href="{{url('/')}}">
                            <img src="{{asset('img/logo.png')}}">
                        </a>
                    </div>
                       <h3>Forgot Password</h3>

                        @include('flash::message')

                        @if (Session::has('status'))
                        <!-- Session Status -->
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-bolt"></i> {{ Session::get('status') }}
                            </p>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif

                        @if ($errors->any())
                        <!-- Validation Errors -->
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-exclamation-triangle"></i> @lang('Please fix the following errors & try again!')
                            </p>
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif

                        <form role="form" method="POST" action="{{ route('password.email') }}">
                            @csrf
                            <div class="form-group">
                                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="email" required>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn submit-btn">
                                    {{ __('Email Password Reset Link') }}
                                </button>
                            </div>
                        </form>
                    
                    <div class="row">
                        @if (Route::has('register'))
                        <div class="col-6 text-left">
                            <a href="{{ route('register') }}" class="text-gray">
                                Create new account
                            </a>
                        </div>
                        @endif
                    <div class="col-6 text-right">
                        <a href="{{ route('login') }}" class="text-gray">
                           Login to account
                        </a>
                    </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 pl-0">
                <div class="login-left-box">
                    <img src="{{asset('img/login-bg.png')}}">
                </div>
            </div>  
        </div>
      </div>
    </div>
</div>

@endsection
