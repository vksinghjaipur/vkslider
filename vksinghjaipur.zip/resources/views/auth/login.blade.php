@extends('frontend.layouts.app')

@section('title') @lang('Login') @endsection

@section('content')
<style>
header.header-global {
    display: none;
}
.site-footer {
    display: none;
}
</style>

<div class="inner-login-section">
    <div class="container">
         <div class="login-box">
            <div class="row justify-content-center">
               <div class="col-lg-6 pr-0">
                <div class="login-form-right">
                    <div class="login-logo">
                        <a href="{{url('/')}}">
                            <img src="{{asset('img/logo.png')}}">
                        </a>
                    </div>

                        <!-- @include('auth.social_login_buttons') -->
                        <h3>Sign in</h3>
                        @include('flash::message')

                        <form role="form" method="POST" action="{{ route('login') }}">
                            @csrf

                            <!-- redirectTo URL -->
                            <input type="hidden" name="redirectTo" value="{{ request()->redirectTo }}">

                                <div class="form-group">
                                    <input type="text" class="form-control" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="input-email" required>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="@lang('Password')" aria-label="@lang('Password')" aria-describedby="input-password" required>
                                </div>
                            <div class="row my-4">
                                <div class="col-12">
                                    <div class="custom-control custom-control-alternative custom-checkbox">
                                        <input class="custom-control-input" name="remember" id="remember" type="checkbox" {{ old('remember') ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="remember">
                                                Remember my login
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn submit-btn">
                                    @lang('Log In')
                                </button>
                            </div>
                        </form>
                        <div class="row mt-3">
                            <div class="col-6">
                                <a href="{{ route('password.request') }}" class="text-gray">
                                   {{ __('Forgot Your Password?') }}
                                </a>
                            </div>
                            @if (Route::has('register'))
                            <div class="col-6 text-right">
                                <a href="{{ route('register') }}" class="text-gray">
                                  Create new account
                                </a>
                            </div>
                            @endif
                        </div>

                        <div class="or-seperator"><b>or</b></div>
                        <div class="row text-center social-btn">
                            <div class="col-md-6">
                                <a href="{{ route('social.redirect','facebook') }}" class="btn btn-primary btn-lg btn-block"><i class="fab fa-facebook"></i> Sign in with <b>Facebook</b></a>
                            </div>        
                            <div class="col-md-6">    
                                <a href="{{ route('social.redirect','google') }}" class="btn btn-danger btn-lg btn-block"><i class="fab fa-google"></i> Sign in with <b>Google</b></a>
                            </div>
                        </div>    
                    </div>
                </div>
                <div class="col-lg-6 pl-0">
                    <div class="login-left-box">
                        <img src="{{asset('img/login-bg.png')}}">
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

@endsection
