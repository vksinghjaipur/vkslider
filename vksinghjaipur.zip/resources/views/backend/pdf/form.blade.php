<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('PDF Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Pdf') : __('Pdf create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            

            <!-------form-group------>
            <div class="form-group row">
                {{ Form::label('name', trans('PDF Title'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    {{ Form::text('name', null, ['class' => 'form-control', 'placeholder' => trans('PDF Title'), 'required' => 'required']) }}
                </div>
            </div>
            
            
            <div class="form-group row">
                 {{ Form::label('Select PDF', trans('Select PDF'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    <input type="file" name="file" class="custom-file-input" id="chooseFile">
                    {{ Form::file('file', ['id' => 'file']) }}
                </div>
            </div>

            
            <div class="form-group row">
                {{ Form::label('status', trans('Status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
                <!--col-->
            </div>
            <!--form-group-->
        </div>
        <!--col-->
    </div>
    <!--row-->
</div>
<!--card-body-->
<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

@section('pagescript')

@stop