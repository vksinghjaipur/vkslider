<footer class="c-footer text-muted">
    <div>
        <a href="/">{{app_name()}}</a>
        @if(setting('show_copyright'))
        @lang('Copyright') &copy; {{ date('Y') }}
        @endif
    </div>
    <div class="ml-auto text-muted">Developed By vksinghjaipur@gmail.com</div>
</footer>
