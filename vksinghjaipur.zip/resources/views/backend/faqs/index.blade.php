@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Faqs Management'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-wrench"></i> Faqs</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="content-header">
    <div id="message_success" style="display:none" class="alert alert-success"> Status Enabled </div>
    <div id="message_error" style="display:none" class="alert alert-danger"> Status Disabled </div>
</div>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('Faqs') }} 
                </h4>
            </div>
           <div class="col-5">
                <div class="float-right">
                    <x-buttons.create route='{{ route("backend.faqs.create") }}' title="{{__('Create')}}" />

                    <div class="btn-group" role="group" aria-label="Toolbar button groups">
                        <div class="btn-group" role="group">
                            <button id="btnGroupToolbar" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupToolbar">
                                <a class="dropdown-item" href="">
                                    <i class="fas fa-eye-slash"></i> View trash
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Id</th>
                                <th>Question</th>
                                <th>Answer</th>
                                <th>Display Order</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($faqs) && !empty($faqs))
                            @foreach($faqs as $my_faqs)
                            <tr>
                                <td>{{$my_faqs->id}}</td>
                                <td>{{$my_faqs->question}}</td>
                                <td>{!!$my_faqs->answer!!}</td>
                                <td>{{$my_faqs->display_order}}</td>
                                <td>
                                    <input class="changeUserStatus btn btn-success chkToggle2" type="checkbox" rel="{{$my_faqs->id}}" data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" {{($my_faqs->status) ? 'checked' : ''}}>
                                </td>

                                <td class="btn-td">
                                    <div class="btn-group action-btn"><a href="{{url('admin/faqs/'.$my_faqs->id.'/edit')}}" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST" action="{{route('backend.faqs.delete',$my_faqs->id)}}">@csrf
                                        <button type="button" class="btn btn-danger btn-sm show_confirm" data-toggle="tooltip" title='Delete Services'> <i class="fa fa-trash"></i></button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to Delete Services..?`,
              text: "Data will lost after delete.",
              icon: "success",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>


<script>
    $(document).ready( function () {
        // for Update status //
        $(".changeUserStatus").change(function(){
            var id = $(this).attr('rel');
            if($(this).prop("checked")==true){
            $.ajax({ 
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type : 'post',
                url : '{{route('backend.faqs.update-status')}}',
                data : {status:'1',id:id},
                success:function(data){
                   $("#message_success").show();
                   setTimeout(function() { $("#message_success").fadeOut('slow'); }, 2000);
                },error:function(){
                   alert("Error");
                }
            });
            }else{
            $.ajax({
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                    type : 'post',
                    url : '{{route('backend.faqs.update-status')}}',
                    data : {status:'0',id:id},
                    success:function(resp){
                       $("#message_error").show();
                       setTimeout(function() { $("#message_error").fadeOut('slow'); }, 2000);
                    },error:function(){
                       alert("Error");
                    }
                });
            }
        });
        });
    </script>

@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

@stop
