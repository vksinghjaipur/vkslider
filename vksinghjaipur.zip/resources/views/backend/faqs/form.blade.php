<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Faqs Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Service') : __('Faqs Type create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <!-------form-group------>
            <div class="form-group row">
                {{ Form::label('question', trans('Question'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    {{ Form::text('question', null, ['class' => 'form-control', 'placeholder' => trans('Question'), 'required' => 'required']) }}
                </div>
            </div>
            

            <div class="form-group row">
                {{ Form::label('display_order', trans('display_order'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    @php
                    $display_order = App\Models\Faq::count(); 
                    $display_order=$display_order+1;
                    @endphp
                    {{ Form::number('display_order', isset($faqs->display_order) ? $faqs->display_order : $display_order, ['class' => 'form-control required', 'max' => $display_order, 'min' => 0, 'placeholder' => trans('Display Order')]) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('answer', trans('answer'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::textarea('answer', null, ['class' => 'form-control tinymce', 'placeholder' => trans('answer')]) }}
                </div>
                <!--col-->
            </div>
            
            <div class="form-group row">
                {{ Form::label('status', trans('Status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : '0'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
                <!--col-->
            </div>
            <!--form-group-->
        </div>
        <!--col-->
    </div>
    <!--row-->
</div>
<!--card-body-->
{{-- <script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script> --}}

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
{{-- {{ script('tinymce/tinymce.min.js') }} --}}
<script src="{{ asset('tinymce/tinymce.min.js') }}"></script>
<!--------------------------V Tiny MCE Text Editor Start ------------------------------------>
<script type="text/javascript">
    tinymce.init({
    selector: 'textarea.tinymce',
    height: 200,
    plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste imagetools wordcount'
    ],
    toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
});
</script>   
<!--------------------------V Tiny MCE Text Editor End ------------------------------------->


@section('pagescript')

@stop