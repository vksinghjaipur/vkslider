@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Subscription Plan Management'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-rocket"></i> Subscription Plans</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('Subscription Plans') }} 
                </h4>
            </div>
           <div class="col-5">
                <div class="float-right">
                    <x-buttons.create route='{{ route("backend.subscriptionplans.create") }}' title="{{__('Create')}}" />

                    <div class="btn-group" role="group" aria-label="Toolbar button groups">
                        <div class="btn-group" role="group">
                            <button id="btnGroupToolbar" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupToolbar">
                                <a class="dropdown-item" href="">
                                    <i class="fas fa-eye-slash"></i> View trash
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Plan Name</th>
                                <th>Roles</th>
                                <th>Paln Price</th>
                                <th>Paln Duration</th>
                                <th>Created By</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($subscription_plans) && !empty($subscription_plans))
                            @foreach($subscription_plans as $plan_data)
                            <tr>
                                <td>{{$plan_data->plan_title}}</td>
                                <td>
                                    <?php
                                        $rolename = explode(',', $plan_data->role_id);
                                            $roleuser=array();
                                                 foreach($rolename as $key=>$value){
                                                    $selected = DB::table('roles')
                                                        ->where('id',$value) 
                                                        ->first();
                                                    $result= isset($selected->name)?$selected->name:'';
                                                    array_push($roleuser,$result);
                                                }
                                    ?>

                                {{implode(', ', $roleuser)}}</td>

                                <td>{{$plan_data->plan_price}}</td>
                                <td>{{$plan_data->plan_duration}} - Days</td>
                                <td>{{$plan_data->username}}</td>
                                <td>
                                    @if($plan_data->status==1)
                                        Active
                                    @else
                                        Inactive
                                    @endif
                                </td>
                                <td>{{ date('d-m-Y', strtotime($plan_data->created_at)) }}</td>
                                <td class="btn-td">
                                    <div class="btn-group action-btn"><a href="{{url('admin/subscriptionplans/'.$plan_data->id.'/edit')}}" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST" action="{{route('backend.subscriptionplans.delete',$plan_data->id)}}">@csrf
                                        <button type="button" class="btn btn-sm text-danger show_confirm" data-toggle="tooltip" title='Delete Plan'> <i class="fa fa-trash"></i></button>
                                    </form>
                                    
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--card-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to Delete Plan..?`,
              text: "Data will lost after delete.",
              icon: "success",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>

@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

@stop
