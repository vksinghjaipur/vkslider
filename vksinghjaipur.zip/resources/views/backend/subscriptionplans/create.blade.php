@extends('backend.layouts.app')

@section('title', __('Subscription Plans management') . ' | ' . __('Subscription Plans create'))

@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item route='{{route("backend.subscriptionplans")}}' icon=''><i class="fa fa-rocket"></i> Subscription Plans
    </x-backend-breadcrumb-item>
    <x-backend-breadcrumb-item type="active">{{ __() }}</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection

@section('content')
    {{ Form::open(['route' => 'backend.subscriptionplans.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-permission', 'files' => true]) }}

    <div class="card">
        @include('backend.subscriptionplans.form')
        	<div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <x-buttons.create title="{{__('Create')}} ">
                            {{__('Create')}}
                        </x-buttons.create>
                    </div>
                </div>
                <div class="col-6">
                    <div class="float-right">
                        <div class="form-group">
                            <x-buttons.cancel />
                        </div>
                    </div>
                </div>
            </div>
    </div><!--card-->
    {{ Form::close() }}
@endsection

