<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Subscription Plans Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Subscription Plans') : __('Subscription Plans create') }}</small>
            </h4>
        </div>
    </div>
    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <div class="form-group row">
                {{ Form::label('plan_title', trans('validation.attributes.backend.access.plans.plan_title'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('plan_title', $subscription_plans->plan_title, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.plans.plan_title'), 'required' => 'required']) }}
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('plan_description', trans('validation.attributes.backend.access.plans.plan_description'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::textarea('plan_description', $subscription_plans->plan_description, ['class' => 'form-control tinymce', 'placeholder' => trans('validation.attributes.backend.access.plans.plan_description')]) }}
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('plan_price', trans('validation.attributes.backend.access.plans.plan_price'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('plan_price', $subscription_plans->plan_price, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.plans.plan_price')]) }}
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('plan_duration', trans('validation.attributes.backend.access.plans.plan_duration'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('plan_duration', $subscription_plans->plan_duration, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.plans.plan_duration')]) }}
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('role_id', trans('validation.attributes.backend.access.plans.role_id'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select class="form-control font-14 select2" id="editor6" multiple="multiple" name="role_id[]">
                        <option value="">Choose Role</option>
                            @if(!empty($getrole))
                                @foreach($getrole as $rolevalue)
                                    <option value="{{$rolevalue->id}}" {{ $subscription_plans->role_id == $rolevalue->id ? 'selected="selected"' : '' }} >{{$rolevalue->name}} </option>
                                @endforeach
                            @endif    
                    </select>
                </div>
            </div>

            
            <div class="form-group row">
                {{ Form::label('service_id', trans('validation.attributes.backend.access.plans.service_id'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select class="form-control font-14 select2" id="editor6" multiple="multiple" name="service_id[]">
                        <option value="">Choose Services</option>
                            @if(!empty($services_data))
                                @foreach($services_data as $servicevalue)
                                    <option value="{{$servicevalue->id}}" {{ $subscription_plans->service_id == $servicevalue->id ? 'selected="selected"' : '' }} >{{$servicevalue->service_name}}({{$servicevalue->price}}) </option>
                                @endforeach
                            @endif    
                    </select>
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('status', trans('validation.attributes.backend.access.plans.status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="{{ asset('tinymce/tinymce.min.js') }}"></script>
<script type="text/javascript">
    tinymce.init({
    selector: 'textarea.tinymce',
    height: 200,
    plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste imagetools wordcount'
    ],
    toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
});
</script> 
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker         : true,
      timePickerIncrement: 30,
      format             : 'MM/DD/YYYY h:mm A'
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>   