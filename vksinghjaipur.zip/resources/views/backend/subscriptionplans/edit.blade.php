@extends('backend.layouts.app')

@section('title', __('Subscription Plan Management') . ' | ' . __('Subscription Plan Edit'))

@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item route='{{route("backend.subscriptionplans")}}' icon=''><i class="fa fa-rocket"></i> Subscription Plan Edit
    </x-backend-breadcrumb-item>

    <x-backend-breadcrumb-item type="active">{{ __() }}</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection

@section('content')
<form method="post" action="{{route('backend.subscriptionplans.update',$subscription_plans->id)}}" enctype="multipart/form-data">
  @csrf
    <div class="card">
        @include('backend.subscriptionplans.editform')
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    {{ html()->submit($text = icon('fas fa-save')." Save")->class('btn btn-success') }}
                </div>
            </div>

            <div class="col-sm-8">
                <div class="float-right">
                    <a href="{{ route("backend.subscriptionplans") }}" class="btn btn-warning" data-toggle="tooltip" title="{{__('labels.backend.cancel')}}"><i class="fas fa-reply"></i> Cancel</a>
                </div>
            </div>
        </div>
    </div><!--card-->
</form>
@endsection

