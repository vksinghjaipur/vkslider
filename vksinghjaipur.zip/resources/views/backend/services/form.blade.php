<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Services Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Service') : __('Services Type create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <!-------form-group------>
            <div class="form-group row">
                {{ Form::label('service_name', trans('Service Name'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    {{ Form::text('service_name', null, ['class' => 'form-control', 'placeholder' => trans('Service name'), 'required' => 'required']) }}
                </div>
            </div>
            <!-----------------form-group------------------->
            <div class="form-group row">
                {{ Form::label('price', trans('Service Price'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    {{ Form::text('price', null, ['class' => 'form-control', 'placeholder' => trans('Service price'), 'required' => 'required']) }}
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('display_order', trans('display_order'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    @php
                    $display_order = App\Models\Service::count(); 
                    $display_order=$display_order+1;
                    @endphp
                    {{ Form::number('display_order', isset($services->display_order) ? $services->display_order : $display_order, ['class' => 'form-control required', 'max' => $display_order, 'min' => 0, 'placeholder' => trans('Display Order')]) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('description', trans('description'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::textarea('description', null, ['class' => 'form-control', 'id' =>'editor1', 'placeholder' => trans('description')]) }}
                </div>
                <!--col-->
            </div>

            <!-------form-group Service Image Start-------->
            <div class="form-group row">
                {{ Form::label('service_icon', trans('Service Icon'), ['class' => 'col-md-2 from-control-label required'])}}
                @if(!empty($services->service_icon))
                    <div class="col-lg-1">
                        <img src="{{ asset('/img/service-icon/'.$services->service_icon) }}" height="80" width="80">
                    </div>
                    <div class="col-lg-5">
                        {{ Form::file('service_icon', ['id' => 'service_icon']) }}
                    </div>
                @else
                    <div class="col-lg-5">
                        {{ Form::file('service_icon', ['id' => 'service_icon']) }}
                    </div>
                @endif
            </div>
            <!----------form-group Business image end------->

            <div class="form-group row">
                {{ Form::label('service_image', trans('Service Image'), ['class' => 'col-md-2 from-control-label required'])}}
                @if(!empty($services->service_image))
                    <div class="col-lg-1">
                        <img src="{{ asset('/img/service-icon/'.$services->service_image) }}" height="80" width="80">
                    </div>
                    <div class="col-lg-5">
                        {{ Form::file('service_image', ['id' => 'service_image']) }}
                    </div>
                @else
                    <div class="col-lg-5">
                        {{ Form::file('service_image', ['id' => 'service_image']) }}
                    </div>
                @endif
            </div>

            <div class="form-group row">
                {{ Form::label('is_featured', trans('is_featured'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                    $is_featured = isset($scooter) ? '' : '0'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="is_featured" id="role-1" value="1" {{ (isset($scooter->is_featured) && $scooter->is_featured === 1) ? "checked" : $is_featured }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
                <!--col-->
            </div>

            
            <div class="form-group row">
                {{ Form::label('status', trans('Status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
                <!--col-->
            </div>
            <!--form-group-->
        </div>
        <!--col-->
    </div>
    <!--row-->
</div>
<!--card-body-->
<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

@section('pagescript')

@stop