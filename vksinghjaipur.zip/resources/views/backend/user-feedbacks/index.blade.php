@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('User feedbacks Management'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-wrench"></i> List User feedbacks</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('User feedbacks') }} 
                </h4>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Ser. Num.</th>
                                <th>User Name </th>
                                <th>Nursing Name</th>
                                <th>feedback Star</th>
                                <th>User feedback</th>
                                <th>Feedback Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($user_feedbacks) && !empty($user_feedbacks))
                                @foreach($user_feedbacks as $k=>$user_feedback)
                                    <tr>
                                        <td>{{$no++}}</td>
                                        <td>{{ucwords($user_feedback->user_id)}}</td>
                                        <td>{{ucwords($user_feedback->doctor_id)}}</td>
                                        <td>
                                            @for ($i = 0; $i < $user_feedback->ratings; $i++)
                                                <span class="fa fa-star text-warning"></span>
                                            @endfor
                                        </td> 
                                        <td>{{$user_feedback->feedback}}</td>
                                        <td>{{ date('d-m-Y', strtotime($user_feedback->created_at)) }}</td>   
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
                 
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to Delete Appointments..?`,
              text: "Data will lost after delete.",
              icon: "success",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>
@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>


@stop
