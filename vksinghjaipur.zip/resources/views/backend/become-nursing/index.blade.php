@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Become Nursing Management'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-wrench"></i> List Become Nursing</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('Become Nursing') }} 
                </h4>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Ser. Num.</th>
                                <th>User Name </th>
                                <th>User Email</th>
                                <th>Contact Num</th>
                                <th>Gender</th>
                                <th>experience</th>
                                <th>specialization</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($become_requests) && !empty($become_requests))
                            @foreach($become_requests as $k=>$become_request)
                            <tr>
                                <td>{{$no++}}</td>
                                <td>{{ucwords($become_request->first_name)}} {{$become_request->last_name}}</td>
                                <td>{{$become_request->email}}</td>
                                <td>{{$become_request->contact_num}}</td>
                                <td>{{ucwords($become_request->gender)}}</td>
                                <td>{{$become_request->experience}} years</td>
                                <td>{{$become_request->specialization}}</td>
                                <td>
                                    <button type="button" class="btn btn-info btn btn-sm mr-1" data-toggle="modal" data-target="#myModal9_{{$k}}" title="Booking Details"><i class="fa fa-eye"></i></button>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
                 
            </div>
        </div>

        @if(!empty($become_requests))
            @foreach($become_requests as $kp => $become_request)
                <!--- Modal for show booking details --->
                <div class="modal" id="myModal9_{{$k}}">
                    <div class="modal-dialog">
                        <div class="modal-content" style="width:600px;">
                            <div class="modal-header">
                                <h5 class="modal-title font-weight-bold text-info" id="exampleModalScrollableTitle">Become Nursing Detail</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">City</label>
                                            <input type="text" class="form-control" id="inputEmail4" value="{{ucwords($become_request->city)}}" readonly="">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">State</label>
                                            <input type="text" class="form-control" id="inputEmail4" value="{{ucwords($become_request->state)}}" readonly="">
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">Country</label>
                                            <input type="text" class="form-control" id="inputEmail4" value="{{ucwords($become_request->country)}}" readonly="">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">Zip Code</label>
                                            <input type="text" class="form-control" id="inputEmail4" value="{{$become_request->zip_code}}" readonly="">
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">address 1</label>
                                            <input type="email" class="form-control" id="inputEmail4" value="{{$become_request->address1}}" readonly="">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">address 2</label>
                                            <input type="email" class="form-control" id="inputEmail4" value="{{$become_request->address2}}" readonly="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputAddress2" class="text-info">About Me</label>
                                        <textarea col="15" row="20" class="form-control" id="inputAddress2">{{$become_request->about_me}}</textarea>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif

    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to Delete Appointments..?`,
              text: "Data will lost after delete.",
              icon: "success",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>
@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>


@stop
