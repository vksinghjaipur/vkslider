@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Nursing Slots List'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-rss"></i> Nursing Available Slots</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="content-header">
    <div id="message_success" style="display:none" class="alert alert-success"> Status Enabled </div>
    <div id="message_error" style="display:none" class="alert alert-danger"> Status Disabled </div>
</div>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('Nursing Availabe Time Slots') }} 
                </h4>
            </div>
           <div class="col-5">
                <div class="float-right">
                    

                    <div class="btn-group" role="group" aria-label="Toolbar button groups">
                        <div class="btn-group" role="group">
                            <button id="btnGroupToolbar" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupToolbar">
                                <a class="dropdown-item" href="">
                                    <i class="fas fa-eye-slash"></i> View trash
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Image</th>
                                <th>Specializations</th>
                                <th>Appointment Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($nursingslist) && !empty($nursingslist))
                            @foreach($nursingslist as $k=>$nursing)
                                <tr>
                                    <td>{{$nursing->id}}</td>
                                    <td>{{ucfirst($nursing->name)}}</td>
                                        @if(!empty($nursing->avatar))
                                    <td><img src="{{asset('img/avatars/'.$nursing->avatar)}}" width="100" /></td>
                                        @else
                                    <td><img src="{{asset('img/avatars/default-user-profile.png')}}" width="100" /></td>
                                        @endif
                                    <td>{{$nursing->specializations}}</td>
                                    <td>
                                       {{CheckSlotCreate($nursing->id)}}
                                    </td>

                                    <td class="btn-td">
                                        <div class="btn-group action-btn">
                                            <a href="#">
                                                <button type="button" class="btn btn-primary btn btn-sm mr-1" data-toggle="modal" data-target="#myModal9" title="Booking Details"><i class="fa fa-eye"></i>
                                                </button>
                                            </a>

                                            <a href="{{route('backend.slotsdetail',$nursing->id)}}">    
                                                <button type="button" class="btn btn-info btn btn-sm mr-1" title="Slots Details"><i class="far fa-calendar-alt"></i>
                                                </button>
                                            </a>  
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
                
            </div>
        </div>

    </div>
</div>
@stop
