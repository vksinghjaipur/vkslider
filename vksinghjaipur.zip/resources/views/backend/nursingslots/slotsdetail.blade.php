@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Nursing Slots List'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-rss"></i> Nursing Available Slots</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="content-header">
    <div id="message_success" style="display:none" class="alert alert-success"> Status Enabled </div>
    <div id="message_error" style="display:none" class="alert alert-danger"> Status Disabled </div>
</div>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('Nursing Availabe Time Slots') }} 
                </h4>
            </div>
           <div class="col-5">
                <div class="float-right">
                    

                    <div class="btn-group" role="group" aria-label="Toolbar button groups">
                        <div class="btn-group" role="group">
                            <button id="btnGroupToolbar" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupToolbar">
                                <a class="dropdown-item" href="">
                                    <i class="fas fa-eye-slash"></i> View trash
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example" class="table table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Day</th>
                                <th>Availablity</th>
                                <th>Bookings</th>
                            </tr>
                        </thead>
                        <tbody>
                                <tr>
                                    <td>
                                        <span  class="nav-link active h6 p-2 daycode"  data-day="1" value="sunday">Sunday </span>
                                    </td>
                                            
                                    <td>
                                        @php
                                            $daysunmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='sun' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daysunmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="sun" @if($daysunmor==1) checked @endif data-style="ios">
                                    </td>
                                    
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot1">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sun' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','sun')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sun][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','sun')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sun][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot1">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sun' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','sun')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sun][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sun')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[sun][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot1">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sun' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','sun')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sun][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sun')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sun][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>          
                                </tr>

                                <!--- Monday code --->

                                <tr>   
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="2" value="monday">Monday </span>
                                    </td>
                                    <td>
                                        @php
                                            $daymonmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='mon' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daymonmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="mon" @if($daymonmor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot2">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='mon' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','mon')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[mon][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','mon')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[mon][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot2">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='mon' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','mon')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[mon][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','mon')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[mon][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot2">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='mon' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','mon')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[mon][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','mon')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[mon][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <!--- Tuesday Code --->

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="3" value="tuesday">Tuesday </span>
                                    </td>
                                    <td>
                                        @php
                                            $daytuemor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='tue' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daytuemor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="tue" @if($daytuemor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot3">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='tue' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','tue')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[tue][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','tue')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[tue][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot3">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='tue' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','tue')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[tue][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','tue')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[tue][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot3">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='tue' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','tue')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[tue][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','tue')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[tue][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="4" value="wednesday">Wednesday </span>
                                    </td>
                                    <td>
                                        @php
                                            $daywedmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='wed' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daywedmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="wed" @if($daywedmor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot4">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='wed' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','wed')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[wed][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','wed')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[wed][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot4">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='wed' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','wed')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[wed][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','wed')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[wed][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot4">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='wed' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','wed')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[wed][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','wed')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[wed][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="5" value="thursday">Thursday </span>
                                    </td>
                                    <td>
                                        @php
                                            $daythumor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='thu' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daythumor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="thu" @if($daythumor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot5">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='thu' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','thu')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[thu][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','thu')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[thu][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot5">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='thu' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','thu')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[thu][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','thu')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[thu][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot5">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='thu' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','thu')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[thu][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','thu')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[thu][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="6" value="friday">Friday </span>
                                    </td>
                                    <td>
                                        @php
                                            $dayfrimor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='fri' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $dayfrimor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="fri" @if($dayfrimor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot6">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='fri' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','fri')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[fri][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','fri')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[fri][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot6">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='fri' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','fri')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[fri][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','fri')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[fri][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot6">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='fri' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','fri')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[fri][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','fri')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[fri][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                               <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="7" value="saturday">Saturday </span>
                                    </td>
                                    <td>
                                        @php
                                            $daysatmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='sat' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daysatmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="sat" @if($daysatmor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot7">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sat' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','sat')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sat][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','sat')
                                                                ->where('calendar_day_sections.doctor_id',$getmyid)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sat][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot7">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sat' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','sat')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sat][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sat')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[sat][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot7">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sat' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',$getmyid)
                                                    ->where('calendar_day_sections.day_code','sat')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sat][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sat')
                                                            ->where('calendar_day_sections.doctor_id',$getmyid)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sat][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>
                        </tbody>    
                    </table>
                </div>
                
            </div>
        </div>

    </div>
</div>







@stop
