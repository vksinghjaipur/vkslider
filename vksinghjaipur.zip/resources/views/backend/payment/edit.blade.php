@extends('backend.layouts.app')

@section('title', __('Payment Management') . ' | ' . __('labels.backend.access.blogs.edit'))

@section('breadcrumb-links')
    @include('backend.Payment.includes.breadcrumb-links')
@endsection

@section('content')
   
<form method="post" action="{{route('admin.payment.update',$getpack->id)}}" enctype="multipart/form-data">
  @csrf
    <div class="card">
        @include('backend.payment.form')
        @include('backend.components.footer-buttons', [ 'cancelRoute' => 'admin.payment.show', 'id' => $getpack->id ])
    </div><!--card-->
</form>
@endsection