@extends('backend.layouts.app')

@section('title', app_name() . ' | ' . __('Payment Management'))


@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    {{ __('Payment Management') }} <small class="text-muted"></small>
                </h4>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Id</th>
                                <th>Order Id</th>
                                <th>Txn Id</th>
                                <th>Payment Status</th>
                                <th>Payment Currency</th>
                                <th>Payment Amount</th>
                                <th>Payment type</th>
                                <th>payment Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($payment) && !empty($payment))
                                @foreach($payment as $vp)
                                    <tr>
                                        <td>{{$vp->id}}</td>
                                        <td>{{$vp->booking_id}}</td>
                                        <td>{{$vp->txn_id}}</td>
                                        <td>
                                            @if($vp->payment_status==1)
                                                success
                                            @elseif($vp->payment_status==0)
                                                cancel
                                            @endif        
                                        </td>
                                        <td>{{$vp->currency}}</td>
                                        <td>{{$vp->total_amount}}</td>
                                        <td>{{$vp->payment_method}}</td>
                                       <td>{{ date('d-m-Y', strtotime($vp->created_at)) }}</td>
                                    </tr>
                                @endforeach
                            @endif        
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

@stop
