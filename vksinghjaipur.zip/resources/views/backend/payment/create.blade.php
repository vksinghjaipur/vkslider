@extends('backend.layouts.app')

@section('title', __('Scooter management') . ' | ' . __('Scooter create'))

@section('breadcrumb-links')
    @include('backend.plan.includes.breadcrumb-links')
@endsection

@section('content')
    {{ Form::open(['route' => 'admin.subscription.plan.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-permission', 'files' => true]) }}

    <div class="card">
        @include('backend.plan.form')
        @include('backend.components.footer-buttons', [ 'cancelRoute' => 'admin.subscription.plan' ])
    </div><!--card-->
    {{ Form::close() }}
@endsection