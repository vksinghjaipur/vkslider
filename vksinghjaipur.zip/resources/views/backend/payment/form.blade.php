<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Payment Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Payment') : __('Payment create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->
    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <div class="form-group row">
                {{ Form::label('type', trans('Type'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select id="type" class="form-control" name="type">
                    <option value="order sale" @if($getpack->type=='order sale') selected='selected' @endif >order sale</option>
                    <option value="reservation" @if($getpack->type=='reservation') selected='selected' @endif >reservation</option>
                    <option value="commission" @if($getpack->type=='commission') selected='selected' @endif >commission</option> 
                    <option value="withdrawal" @if($getpack->type=='withdrawal') selected='selected' @endif >withdrawal</option>
                    <option value="shipping" @if($getpack->type=='shipping') selected='selected' @endif >shipping</option> 
                    <option value="refund order" @if($getpack->type=='refund order') selected='selected' @endif >refund order</option>
                    </select>
                </div>
                <!--col-->
            </div>
            <!--form-group-->

            <div class="form-group row">
                {{ Form::label('model', trans('Amount'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                     {{ Form::number('amount', $getpack->amount, ['class' => 'form-control', 'placeholder' => trans('Amount'), 'required' => 'required']) }}
                </div>
            </div> 
             <div class="form-group row">
                {{ Form::label('model', trans('Notes'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                     {{ Form::textarea('notes',  $getpack->notes, ['class' => 'form-control', 'placeholder' => trans('Notes'), 'required' => 'required']) }}
                </div>
            </div>
            <div class="form-group row">
                {{ Form::label('status', trans('validation.attributes.backend.access.faqs.status'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    <select id="type" class="form-control" name="status">
                    <option value="pending" @if($getpack->status=='pending') selected='selected' @endif >pending</option>
                   <option value="completed" @if($getpack->status=='completed') selected='selected' @endif >completed</option>
                   <option value="cancelled" @if($getpack->status=='cancelled') selected='selected' @endif >cancelled</option>
                   
                   </select>
                </div>
                <!--col-->
            </div>
            <!--form-group-->
        </div>
        <!--col-->
    </div>
    <!--row-->
</div>
<!--card-body-->

@section('pagescript')
<script type="text/javascript">
    FTX.Utils.documentReady(function() {
        FTX.Blogs.edit.init("{{ config('locale.languages.' . app()->getLocale())[1] }}");
    });
</script>
@stop