@extends('backend.layouts.app')

@section('title', __('labels.backend.access.cancellation-fee.management') . ' | ' . __('labels.backend.access.cancellation-fee.edit'))



@section('content')
    {{ Form::model($data->id, ['route' => ['backend.cancellation-fee.update', $data->id], 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'POST', 'id' => 'edit-role', 'files' => true]) }}

    <div class="card">
        @include('backend.cancellation-fee.editform')
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group ml-4">
                    {{ html()->submit($text = icon('fas fa-save')." Save")->class('btn btn-success') }}
                </div>
            </div>

            <div class="col-sm-8">
                <div class="float-right mr-4">
                    <a href="{{ route("backend.cancellation-fee") }}" class="btn btn-warning" data-toggle="tooltip" title="{{__('labels.backend.cancel')}}"><i class="fas fa-reply"></i> Cancel</a>
                </div>
            </div>
        </div>
    </div>
    {{ Form::close() }}
@endsection