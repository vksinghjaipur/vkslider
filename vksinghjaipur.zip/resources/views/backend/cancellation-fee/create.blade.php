@extends('backend.layouts.app')

@section('title', __('cancellation Fee') . ' | ' . __('Carebee'))


@section('content')
    {{ Form::open(['route' => 'backend.cancellation-fee.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-permission', 'files' => true]) }}

    <div class="card">
        @include('backend.cancellation-fee.form')
		    <div class="row">
		        <div class="col-6">
                    <div class="form-group ml-4">
                        <x-buttons.create title="{{__('Create')}} ">
                            {{__('Create')}}
                        </x-buttons.create>
                    </div>
                </div>
                <div class="col-6">
                    <div class="float-right">
                        <div class="form-group mr-4">
                            <x-buttons.cancel />
                        </div>
                    </div>
                </div>
            </div>
    </div><!--card-->
    {{ Form::close() }}
@endsection