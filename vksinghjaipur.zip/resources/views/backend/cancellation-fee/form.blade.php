<div class="card-body">
    <div class="row">
        <div class="col-sm-12">
            <h4 class="card-title mb-0">
                Cancellation Fee
            </h4>
        </div>
    </div>
    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
             <div class="form-group row">
                {{ Form::label('user_type', trans('User Type'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    @foreach($getrole as $rolevalue)
                        <input type="radio" value="{{$rolevalue->id}}" onclick="javascript:yesnoCheck();" id="yesCheck" name="user_type" checked>
                        <label for="{{$rolevalue->name}}" class="mr-5">{{ucfirst($rolevalue->name)}}</label>
                    @endforeach
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('time', trans('Enter Time'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('time', null, ['class' => 'form-control', 'placeholder' => trans('Enter Time'), 'required' => 'required']) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('Fee type', trans('Fee Type'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                   <input type="radio" value="Fixed" id="fixed" name="fee_type" checked>
                    <label for="fixed" class="mr-5">Fixed</label>

                    <input type="radio" value="Percentage" id="percentage" name="fee_type">
                    <label for="percentage">Percentage</label> 
                </div>
            </div> 

            <div class="form-group row">
                {{ Form::label('cancellation_fee', trans('Cancellation Fee'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('cancellation_fee', null, ['class' => 'form-control', 'placeholder' => trans('Cancellation Fee'), 'required' => 'required']) }}
                </div>
            </div>

            
        </div>
    </div>
</div>
@section('pagescript')
<script type="text/javascript">
    $('input[type=radio]').click(function(){
  if($(this).is(':checked'))
  {
    var checkedOne=$(this).val()
    if(checkedOne=='Percentage')
    {
       $('input[type=text]').val('');
    }
  }
})
</script>
@stop