@extends('backend.layouts.app')

@section('title', __('Commission Fee') . ' | ' . __('Carebee'))


@section('content')
    {{ Form::open(['route' => 'backend.service-fee.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-permission', 'files' => true]) }}

    <div class="card">
        @include('backend.service-fee.form')
       		<div class="row">
		        <div class="col-6">
                    <div class="form-group ml-4">
                        <x-buttons.create title="{{__('Create')}} ">
                            {{__('Create')}}
                        </x-buttons.create>
                    </div>
                </div>
                <div class="col-6">
                    <div class="float-right">
                        <div class="form-group mr-4">
                            <x-buttons.cancel />
                        </div>
                    </div>
                </div>
            </div>
    </div><!--card-->
    {{ Form::close() }}
@endsection