@extends('backend.layouts.app')

@section('title', __('labels.backend.access.service-fee.management') . ' | ' . __('labels.backend.access.service-fee.edit'))



@section('content')
    {{ Form::model($data->id, ['route' => ['admin.service-fee.update', $data->id], 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'POST', 'id' => 'edit-role', 'files' => true]) }}

    <div class="card">
        @include('backend.service-fee.form')
        
    </div><!--card-->
    {{ Form::close() }}
@endsection