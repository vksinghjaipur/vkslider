<div class="card-body">
    <div class="row">
        <div class="col-sm-12">
            <h4 class="card-title mb-0">
                Commission Fee
            </h4>
        </div>
    </div>
    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <div class="form-group row">
                {{ Form::label('Fee type', trans('Fee Type'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    <input type="hidden" name="id" value="{{isset($data->id)?$data->id:''}}">
                   <input type="radio" <?php if(isset($data) && $data->fee_type == 'Fixed'){ echo "checked='checked'";} ?> value="Fixed" id="fixed" name="fee_type" checked>
                    <label for="fixed">Fixed</label>

                    <input type="radio" <?php if(isset($data) && $data->fee_type == 'Percentage'){ echo "checked='checked'";} ?> value="Percentage" id="percentage" name="fee_type">
                    <label for="percentage">Percentage</label> 
                </div>
            </div> 

            <div class="form-group row">
                {{ Form::label('service_fee', trans('Commission Fee'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('service_fee', isset($data->service_fee) && !empty($data->service_fee) ? $data->service_fee : '', ['class' => 'form-control', 'placeholder' => trans('Enter Commission Fee'), 'required' => 'required']) }}
                </div>
            </div>
        </div>
    </div>
</div>
@section('pagescript')
<script type="text/javascript">
    $('input[type=radio]').click(function(){
  if($(this).is(':checked'))
  {
    var checkedOne=$(this).val()
    if(checkedOne=='Percentage')
    {
       $('input[type=text]').val('');
    }
  }
})
</script>
@stop