@extends('backend.layouts.master')

@section('title', app_name() . ' | Commission Fee')

@section('content')
<div class="card">
	<div class="card-body">
		<div class="row">
			<div class="col-sm-10">
				<h4 class="card-title mb-0">
					Commission Fee <small class="text-muted">Commission Fee List</small>
				</h4>               
			</div>
			<div class="col-sm-2">
				<a href="{{route('admin.service-fee.add')}}" style="margin-left:55%;color:white" class="btn btn-primary">Add <i class="fa fa-plus"></i></a>
			</div>
			<!--col-->
		</div>
		<!--row-->

		<div class="row mt-4">
			<div class="col">
				<div class="table-responsive">
					<table id="data-table" class="table">
						<thead>
							<tr>
								<th>{{ trans('Service Fee') }}</th>
								<th>{{ trans('Service Type') }}</th>
								<th>{{ trans('labels.general.actions') }}</th>
							</tr>
						</thead>
						<tbody>
							
							@if(!empty($data) && !empty($data))
								@foreach($data as $k=>$v)
									<tr role="row">
										<td>{!! $v->service_fee !!}</td>
										<td>{!! $v->fee_type !!}</td>
										<td class="btn-td">
											<div class="btn-group action-btn">

												<a href="{!! URL::to('admin/service-fee/edit'.'/'.$v->id)!!}" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-primary btn-sm">
												<i class="fas fa-edit"></i>
												</a>

												<a href="#" class="btn btn-primary btn-danger btn-sm" data-method="delete" data-trans-button-cancel="Cancel" data-trans-button-confirm="Delete" data-trans-title="Are you sure you want to do this?" style="cursor:pointer;" onclick="$(this).find(&quot;form&quot;).submit();">
													<i data-toggle="tooltip" data-placement="top" title="Delete" class="fa fa-trash"></i>
													{{ Form::open(['route' => 'admin.service-fee.delete', 'name' => 'delete_item', 'style' => 'display:none', 'method' => 'post']) }}
														<input type="hidden" name="id" value="{!! $v->id !!}">
													{{ Form::close() }}
												</a>
											</div>
										</td>
									</tr>
								@endforeach
							@endif
						</tbody>
					</table>
				</div>
			</div>
			<!--col-->
		</div>
		<!--row-->

	</div>
	<!--card-body-->
</div>
<!--card-->
@endsection

@section('pagescript')
<script>
	FTX.Utils.documentReady(function() {
		FTX.Pages.list.init();
	});
</script>
{!! script('js/dataTables.bootstrap4.min.js') !!}

    <script>
        
            $('#data-table').dataTable();
        
    </script>
@endsection