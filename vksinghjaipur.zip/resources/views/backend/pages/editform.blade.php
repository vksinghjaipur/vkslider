<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Pages Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Pages') : __('Pages create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <div class="form-group row">
                {{ Form::label('title', trans('validation.attributes.backend.access.pages.title'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('title', $pages->title, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.pages.title'), 'required' => 'required']) }}
                </div>
                <!--col-->
            </div>
            
            <div class="form-group row">
                {{ Form::label('page_slug', trans('validation.attributes.backend.access.pages.slug'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('page_slug', $pages->page_slug, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.pages.slug'), 'disabled' => 'disabled']) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('description', trans('validation.attributes.backend.access.pages.description'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::textarea('description', $pages->description, ['class' => 'form-control description ckeditor', 'id' =>'editor1', 'placeholder' => trans('validation.attributes.backend.access.pages.description')]) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('cannonical_link', trans('validation.attributes.backend.access.pages.cannonical_link'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('cannonical_link', $pages->cannonical_link, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.pages.cannonical_link')]) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('seo_title', trans('validation.attributes.backend.access.pages.seo_title'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('seo_title', $pages->seo_title, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.pages.seo_title')]) }}
                </div>
                <!--col-->
            </div>
            
            <!--form-group-->

            <div class="form-group row">
                {{ Form::label('seo_keyword', trans('validation.attributes.backend.access.pages.seo_keywords'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('seo_keyword', $pages->seo_keyword, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.pages.seo_keywords')]) }}
                </div>
                <!--col-->
            </div>
            <!--form-group-->

            <div class="form-group row">
                {{ Form::label('seo_description', trans('validation.attributes.backend.access.pages.seo_description'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::textarea('seo_description', $pages->seo_description, ['class' => 'form-control description ckeditor', 'id' => 'editor1', 'placeholder' => trans('validation.attributes.backend.access.pages.seo_description')]) }}
                </div>
                <!--col-->
            </div>
            <!--form-group-->

            <!-- <div class="form-group row">
                {{ Form::label('status', trans('validation.attributes.backend.access.pages.status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

@push('after-styles')

<!-- Select2 Bootstrap 4 Core UI -->
<link href="{{ asset('vendor/select2/select2-coreui-bootstrap4.min.css') }}" rel="stylesheet" />

<!-- Date Time Picker -->
<link rel="stylesheet" href="{{ asset('vendor/bootstrap-4-datetime-picker/css/tempusdominus-bootstrap-4.min.css') }}" />

@endpush
@push ('after-scripts')
<!--card-body-->
<script type="text/javascript" src="{{ asset('vendor/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/bootstrap-4-datetime-picker/js/tempusdominus-bootstrap-4.min.js') }}"></script>

<script type="text/javascript">
$(function() {
    $('.datetime').datetimepicker({
        format: 'YYYY-MM-DD HH:mm:ss',
        icons: {
            time: 'far fa-clock',
            date: 'far fa-calendar-alt',
            up: 'fas fa-arrow-up',
            down: 'fas fa-arrow-down',
            previous: 'fas fa-chevron-left',
            next: 'fas fa-chevron-right',
            today: 'far fa-calendar-check',
            clear: 'far fa-trash-alt',
            close: 'fas fa-times'
        }
    });
});
</script>

@endpush