<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Time Slots Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Time Slots') : __('Time Slots create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">

            <div class="form-group row">
                {{ Form::label('slot_day', trans('validation.attributes.backend.access.slots.day_name'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select class="form-control font-14" id="editor6"  name="day_name" data-placeholder="Select day Name" disabled="">
                        <option value="sun" @if($slots->day_name=='sun')selected @endif> Sunday</option>
                        <option value="mon" @if($slots->day_name=='mon')selected @endif> Monday</option>
                        <option value="tue" @if($slots->day_name=='tue')selected @endif> Tuesday</option>
                        <option value="wed" @if($slots->day_name=='wed')selected @endif> Wednesday</option>
                        <option value="thu" @if($slots->day_name=='thu')selected @endif> Thursday</option>
                        <option value="fri" @if($slots->day_name=='fri')selected @endif> Friday</option>
                        <option value="sat" @if($slots->day_name=='sat')selected @endif> Saturday</option>
                    </select>
                </div>
                <!--col-->
            </div>
            
            <div class="form-group row">
                {{ Form::label('name', trans('validation.attributes.backend.access.slots.day_section_title'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select class="form-control font-14" id="editor6"  name="day_section" data-placeholder="Select Section Title" disabled="">
                        <option value="morning" @if($slots->day_section=='morning')selected @endif>Morning Slot</option>
                        <option value="afternoon" @if($slots->day_section=='afternoon')selected @endif>Afternoon Slot</option>
                        <option value="evening" @if($slots->day_section=='evening')selected @endif> Evening Slot</option>
                    </select>
                </div>
                <!--col-->
            </div>
            <div class="form-group row">
                {{ Form::label('slot_time', trans('validation.attributes.backend.access.slots.time_slot'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('slot_time', $slots->time_slot, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.slots.time_slot')]) }}
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

