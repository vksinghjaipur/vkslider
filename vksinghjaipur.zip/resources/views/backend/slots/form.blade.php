<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Time Slots Management') }}
            </h4>
        </div>
    </div>
    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">

            <div class="form-group row">
                {{ Form::label('slot_day', trans('validation.attributes.backend.access.slots.day_name'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select class="form-control font-14" id="editor6"  name="day_name" data-placeholder="Select day Name">
                        <option value="sun"> Sunday</option>
                        <option value="mon"> Monday</option>
                        <option value="tue"> Tuesday</option>
                        <option value="wed"> Wednesday</option>
                        <option value="thu"> Thursday</option>
                        <option value="fri"> Friday</option>
                        <option value="sat"> Saturday</option>
                    </select>
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('name', trans('validation.attributes.backend.access.slots.day_section_title'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                   <select class="form-control font-14" id="editor6"  name="day_section" data-placeholder="Select Section Title">
                        <option value="morning"> Morning Slot</option>
                        <option value="afternoon"> Afternoon Slot</option>
                        <option value="evening"> Evening Slot</option>
                    </select>
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('time_slot', trans('validation.attributes.backend.access.slots.time_slot'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('time_slot', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.slots.time_slot')]) }}
                </div>
            </div>

            <div class="form-group row">
                {{ Form::label('status', trans('validation.attributes.backend.access.slots.status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
