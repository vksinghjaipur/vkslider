<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Testimonials Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Testimonials') : __('Testimonials create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <div class="form-group row">
                {{ Form::label('title', trans('validation.attributes.backend.access.testimonials.title'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('title', $testimonials->title, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.testimonials.title'), 'required' => 'required']) }}
                </div>
                <!--col-->
            </div>
            
            <div class="form-group row">
                {{ Form::label('description', trans('validation.attributes.backend.access.testimonials.description'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::textarea('description', $testimonials->description, ['class' => 'form-control description ckeditor', 'id' =>'editor1', 'placeholder' => trans('validation.attributes.backend.access.testimonials.description')]) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('star_value', trans('validation.attributes.backend.access.testimonials.star_value'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    <select class="form-control font-14" name="star_value">
                        <option value="1">1</option>
                        <option value="2">2 </option>
                        <option value="3">3 </option>
                        <option value="4">4 </option>
                        <option value="5">5 </option>
                    </select> 
                </div>
                <!--col-->
            </div>

             <div class="form-group row">
                {{ Form::label('user_name', trans('validation.attributes.backend.access.testimonials.user_name'), ['class' => 'col-md-2 from-control-label required']) }}

                <div class="col-md-10">
                    {{ Form::text('user_name', $testimonials->user_name, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.testimonials.user_name')]) }}
                </div>
                <!--col-->
            </div>

            <div class="form-group row">
                {{ Form::label('user_image', trans('validation.attributes.backend.access.testimonials.user_image'), ['class' => 'col-md-2 from-control-label required']) }}

                @if(!empty($testimonials->user_image))
                <div class="col-lg-1">
                    <img src="{{ asset('img/testimonials-image/'.$testimonials->user_image) }}" height="80" width="80">
                </div>
                <div class="col-lg-5">
                    {{ Form::file('user_image', ['id' => 'user_image']) }}
                </div>
                @else
                <div class="col-lg-5">
                    {{ Form::file('user_image', ['id' => 'user_image']) }}
                </div>
                @endif
            </div>

            <!-- <div class="form-group row">
                {{ Form::label('status', trans('validation.attributes.backend.access.testimonials.status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

@push('after-styles')

<!-- Select2 Bootstrap 4 Core UI -->
<link href="{{ asset('vendor/select2/select2-coreui-bootstrap4.min.css') }}" rel="stylesheet" />

<!-- Date Time Picker -->
<link rel="stylesheet" href="{{ asset('vendor/bootstrap-4-datetime-picker/css/tempusdominus-bootstrap-4.min.css') }}" />

@endpush
@push ('after-scripts')
<!--card-body-->
<script type="text/javascript" src="{{ asset('vendor/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/bootstrap-4-datetime-picker/js/tempusdominus-bootstrap-4.min.js') }}"></script>

<script type="text/javascript">
$(function() {
    $('.datetime').datetimepicker({
        format: 'YYYY-MM-DD HH:mm:ss',
        icons: {
            time: 'far fa-clock',
            date: 'far fa-calendar-alt',
            up: 'fas fa-arrow-up',
            down: 'fas fa-arrow-down',
            previous: 'fas fa-chevron-left',
            next: 'fas fa-chevron-right',
            today: 'far fa-calendar-check',
            clear: 'far fa-trash-alt',
            close: 'fas fa-times'
        }
    });
});
</script>

@endpush