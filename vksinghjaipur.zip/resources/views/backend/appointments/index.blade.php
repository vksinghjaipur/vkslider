@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Appointment Management'))
@section('breadcrumbs')
<x-backend-breadcrumbs>
    <x-backend-breadcrumb-item type="active"><i class="fa fa-wrench"></i> List Appointments</x-backend-breadcrumb-item>
</x-backend-breadcrumbs>
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-7">
                <h4 class="card-title mb-0">
                    {{ __('List Appointments') }} 
                </h4>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example1" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>App. Id</th>
                                <th>Nursing Name </th>
                                <th>Payment Method</th>
                                <th>Txn. Id</th>
                                <th>Payment Status</th>
                                <th>Booking Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($appointments) && !empty($appointments))
                            @foreach($appointments as $k=>$myappointments)
                            <tr>
                                <td>{{$myappointments->id}}</td>
                                <td>{{ucwords($myappointments->doctor_id)}}</td>
                                <td>{{$myappointments->payment_method}}</td>
                                <td>{{$myappointments->txn_id}}</td>            
                                <td>
                                    @if($myappointments->payment_status==1)
                                        Success
                                    @else
                                        Pending
                                    @endif
                                </td>
                                <td>
                                    @if($myappointments->status=='Pending')
                                        <span class="btn btn-warning fa fa-hourglass-end"> Pending</span>
                                    @elseif($myappointments->status=='Confirm')
                                        <span class="btn btn-success fa fa-check"> Confirm</span>
                                    @elseif($myappointments->status=='Reject')
                                        <span class="btn btn-danger fa fa-window-close"> Canceled</span>
                                    @elseif($myappointments->status=='Reject Request')
                                        <span class="btn btn-danger fa fa-window-close" title='appointment reject request' data-toggle="modal" data-target="#exampleModal_{{$k}}"> Appointment Cancel Request by 
                                            @if($myappointments->user_type==2)
                                                Nursing Staff
                                            @elseif($myappointments->user_type==3)
                                                Careseeker
                                            @endif
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    <button type="button" class="btn btn-info btn btn-sm mr-1" data-toggle="modal" data-target="#myModal9_{{$k}}" title="Booking Details"><i class="fa fa-eye"></i></button>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>    
                    </table>
                </div>
                 
            </div>
        </div>

@if(isset($appointments) && !empty($appointments))
    @foreach($appointments as $k=>$myappointments)
    <!--- Modal for show booking details --->
        <div class="modal" id="myModal9_{{$k}}">
            <div class="modal-dialog">
              <div class="modal-content" style="width:900px; margin-left: -135px; margin-top: 60px;">
              <!-- Modal body -->
                <div class="modal-body">
                  <div class="card">
                    <div class="card-body">
                      <div class="create_form">
                        <div class="questions_div">
                            <div class="form-group">
                                <p class="font-weight-bold h5 text-info mb-3"><i class="fa fa-address-card text-info"></i> Appointment Booking Details :</p>
                                <span class="h4">Patient Name: </span>
                                <span class="text-success h4">{{ucwords($myappointments->user_id)}}</span>
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Nursing Image</th>
                                                <th>Nursing Name</th>
                                                <th>Total Amount</th>
                                                <th>Booking Date</th>
                                                <th>Booking Day</th>
                                                <th>Booking Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <tr>
                                                <td> 
                                                    <span class="round">
                                                       @if(!empty($myappointments->avatar) && file_exists(public_path('/img/avatars/'.$myappointments->avatar)))
                                                            <img src="{{ asset('img/avatars/'.$myappointments->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                                            @else
                                                            <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                                        @endif
                                                    </span>
                                                </td>
                                                <td>
                                                    <h6>{{ucwords($myappointments->doctor_id)}}</h6>
                                                </td>
                                                <td><span class="label label-success">{{$myappointments->total_amount}}</span></td>
                                                
                                                <td><span class="label label-success">{{$myappointments->booking_date}}</span></td>
                                                <td><span class="label label-success">
                                                    @if($myappointments->booking_day=='Sun')
                                                        Sunday
                                                    @elseif($myappointments->booking_day=='Mon')
                                                        Monday
                                                    @elseif($myappointments->booking_day=='Tue')
                                                        Tuesday
                                                    @elseif($myappointments->booking_day=='Wed')
                                                        Wednesday
                                                    @elseif($myappointments->booking_day=='Thu')
                                                        Thursday
                                                    @elseif($myappointments->booking_day=='Fri')
                                                        Friday
                                                    @elseif($myappointments->booking_day=='Sat')
                                                        Saturday
                                                    @endif
                                                    </span></td>
                                                <td><span class="label label-success">{{$myappointments->booking_time}}</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                      <div class="text-center">
                        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                      </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>

        <!-- modal for show reschedule appointment -->
        <div class="modal" id="myModal10_{{$k}}">
            <div class="modal-dialog">
                <form method="post" action="{{route('backend.reschedule',$myappointments->id)}}">
                    {{ csrf_field() }}
                    <div class="modal-content" style="margin-left: -90px; margin-top: 60px;">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold">Reschedule appointment</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="hidden" name="_token" value="">
                                    <div class="form-group">
                                        <label for="booking_date">Booking Date</label>
                                            <select name="booking_date" class="form-control form-select form-select-lg mb-3">
                                                <?php
                                                    $todayDay = \Carbon\Carbon::now();
                                                    $date = date('Y-m-d',strtotime('-1 day'));
                                                    // print_r($todayDay); die();
                                                    for($i =1; $i <= 7; $i++)
                                                    {
                                                        $date = date('Y-m-d', strtotime('+1 day', strtotime($date)));?>
                                                        <option data-day="{{date('D',strtotime($date))}}" data-date="{{date('D',strtotime($date))}}, {{date('d M',strtotime($date))}}, {{date('Y',strtotime($date))}}">{{date('D',strtotime($date))}}, {{date('d M',strtotime($date))}}, {{date('Y',strtotime($date))}}</option>
                                                        <?php 
                                                    }
                                                ?>
                                            </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="booking_time_id">Booking Time</label>
                                            <select name="booking_time_id" class="form-control">
                                                <option value="10:00AM - 11:00AM">10:00AM - 11:00AM</option>
                                            </select>
                                    </div>
                            </div>    
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Save Change</button>
                        </div>     
                    </div>
                </form>
            </div>
        </div>

        <!-- Modal for accept or cancel rejection request -->
        <div class="modal" id="exampleModal_{{$k}}">
            <div class="modal-dialog" role="document">
                <div class="modal-content"style="margin-top: 150px;">
                    <div class="modal-header">
                        <h5 class="modal-title">Appointment Rejection Request by <span class="text-danger">
                            @if($myappointments->user_type==2)
                                Nursing Staff
                            @elseif($myappointments->user_type==3)
                                Careseeker
                            @endif </span>
                        </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                    </div>
                    <div class="modal-body">
                        <p class="font-weight-bold text-danger">Cancellation Reason</p>
                        <p>{{$myappointments->cancel_reason}} <i class="fa fa-thumbs-up" style="color:red;"></i></p>
                    </div>
                    <div class="modal-footer">
                        <form method="POST" action="{{route('backend.reject',$myappointments->id)}}">@csrf
                            <button type="submit" class="btn btn-danger">Accept Cancellation</button>
                        </form>
                        <form method="POST" action="{{route('backend.pending',$myappointments->id)}}">@csrf    
                            <button type="submit" class="btn btn-success">Decline Cancellation</button>
                        </form>    
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endif
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to Delete Appointments..?`,
              text: "Data will lost after delete.",
              icon: "success",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>
@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>


@stop
