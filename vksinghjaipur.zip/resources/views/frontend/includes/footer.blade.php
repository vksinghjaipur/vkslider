<footer class="site-footer">
    <div class="container">
        <div class="footer-logo">
            <img src="{{asset('img/logo.png')}}">
        </div>
        <div class="footer-menu">
            <ul>
                <li><a href="{{url('/')}}">Home</a></li>
                <li><a href="{{url('contact') }}">Contact</a></li>
                <li><a href="{{url('services') }}">Services</a></li>
                <li><a href="{{url('aboutus') }}">About Us</a></li>

                <?php 
                    $getPages=App\Models\Page::where('status','1')->orderBy('id')->get();
                ?>

                 @foreach($getPages as $mypage)
                    <li>
                        <a href="{{ url($mypage->page_slug) }}">{{$mypage->title}}</a>
                    </li>
                @endforeach
               
            </ul>
        </div>
        <div class="footer-social">
            <a href="#"><i class="fab fa-facebook-f fa-fw"></i></a>
            <a href="#"><i class="fab fa-linkedin-in fa-fw"></i></a>
            <a href="#"><i class="fab fa-instagram fa-fw"></i></a>
            <a href="#"><i class="fab fa-pinterest-p fa-fw"></i></a>
            <a href="#"><i class="fab fa-twitter fa-fw"></i></a>
        </div>
    </div>
    <div class="copyright">
        <p>&copy; {{ app_name() }}, {!! setting('footer_text') !!}</p>
    </div>
</footer>



<!-- <footer class="footer section pt-6 pt-md-8 pt-lg-10 pb-3 bg-primary text-white overflow-hidden">
    <div class="pattern pattern-soft top"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4 mb-lg-0">
                <a class="footer-brand mr-lg-5 d-flex" href="/">
                    <img src="{{asset('img/backend-logo.jpg')}}" height="35" class="mr-3" alt="Footer logo">
                </a>
                <p class="my-4">
                    {!! setting('meta_description') !!}
                </p>
            </div>
            <div class="col-6 col-sm-3 col-lg-2 mb-4 mb-lg-0 text-center">
                <h6>
                    Pages
                </h6>
                <?php 
                    $getPages=App\Models\Page::where('status','1')->orderBy('id')->get();
                ?>
                <ul class="links-vertical">
                    @foreach($getPages as $mypage)
                        <li>
                            <a href="{{ url('pages/'.$mypage->page_slug) }}">{{$mypage->title}}</a>
                        </li>
                    @endforeach
                </ul>
            </div>
            <div class="col-6 col-sm-3 col-lg-2 mb-4 mb-lg-0 text-center">
                <h6>
                    Account
                </h6>
                <ul class="links-vertical">
                    @guest
                    @if(user_registration())
                    <li>
                        <a href="{{ route('register') }}">Register</a>
                    </li>
                    @endif
                    <li>
                        <a href="{{ route('login') }}">Login</a>
                    </li>
                    @else
                    <li>
                        <a href="#">{{ Auth::user()->name }}</a>
                    </li>
                    <li>
                        <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Logout
                        </a>
                        <form id="logout-form" action="{{route('logout')}}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </li>
                    @endguest
                </ul>
            </div>            
        </div>

        <hr class="my-4 my-lg-5">

        <div class="row">
            <div class="col pb-4 mb-md-0">
                <div class="d-flex text-center justify-content-center align-items-center">
                    <p class="font-weight-normal mb-0">
                        &copy; {{ app_name() }}, {!! setting('footer_text') !!}
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer> -->
