<header class="header-global">
    <section class="topbar-one">
        <div class="container">
            <div class="topbar-one__left">
                <h6>Welcome to CareBee</h6>
            </div>

            <div class="topbar-one__right">
                <div class="row">
                    <div class="col-md-4 mt-1">
                        <div class="topbar-one__social">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in fa-fw"></i></a>
                            <a href="#"><i class="fab fa-instagram fa-fw"></i></a>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <button class="topbar-one__center thm-btn ml-5">
                            <h6 data-toggle="modal" data-target="#myModal9"title="Become a nursing">Become a nursing</h6>
                        </button>
                    </div>    
                </div>
            </div>
        </div>
    </section>

    <nav class="main-nav-one stricky">
        <div class="container">
            <div class="inner-container">
                <div class="logo-box">
                    <a href="{{url('/')}}">
                        <img src="{{asset('img/logo.png')}}">
                    </a>
                    <a href="#" class="side-menu__toggler"><i class="fa fa-bars"></i></a>
                </div>
                
                <div class="main-nav__main-navigation">

                    <ul class="main-nav__navigation-box">
                        {{-- <li><a class="active" href="{{url('/')}}">Home</a></li> --}}
                       <!--  <div class="dropdown">
                            <li class="mr-4 text-primary font-weight-bold" type="button" id="" data-toggle="dropdown" aria-expanded="false">
                            Home
                            </li>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="{{url('/')}}">Home 1</a>
                                <a class="dropdown-item" href="{{url('demo-index')}}">Home 2</a>
                            </div>
                        </div> -->
                         <li><a href="{{url('') }}">Home</a></li>
                        <li><a href="{{url('aboutus') }}">About Us</a></li>
                        <li><a href="{{url('services') }}">Services</a></li>
                        <li><a href="{{url('nursing-list') }}">Nursing Staff</a></li>
                        <li><a href="{{url('blog') }}">Blog</a></li>
                        <li><a href="{{url('contact') }}">Contact Us</a></li>
                    </ul>
                </div>
                <div class="main-nav__right">
                    <div class="btn-group">
                        <a href="#" class="search-btn"><i class="fa fa-search"></i></a>
                            @can('view backend')
                            <?php $role = Auth::user()->roles()->get();?>

                            @if(!$role->isEmpty())
                                @if($role[0]['id'] == 1)
                                <a class="login-vdash" href="{{route('backend.dashboard')}}" class="{{ active_class(Route::is('backend.dashboard')) }}">@lang('navs.frontend.dashboard')</a>
                            @endcan
                                @endif
                            @endif    
                            @guest  
                                <a href="{{ route('login') }}" class="thm-btn without-bg">Login</a>
                                <a href="{{ route('register') }}" class="thm-btn main-nav-one__btn">Sign Up</a>
                            @else 
                            <ul class="c-header-nav ml-auto">
                                <li class="c-header-nav-item dropdown d-md-down-none mx-2">
                                    <?php
                                    $notifications = optional(auth()->user())->unreadNotifications;
                                    $notifications_count = optional($notifications)->count();
                                    $notifications_latest = optional($notifications)->take(5);
                                    ?>
                                    <a class="c-header-nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-bell"></i>&nbsp;
                                        @if($notifications_count)<span class="badge badge-pill badge-danger">{{$notifications_count}}</span>@endif
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-lg pt-0">
                                        <div class="dropdown-header bg-light">
                                            <strong>@lang("You have :count notifications", ['count'=>$notifications_count])</strong>
                                        </div>
                                        @if($notifications_latest)
                                        @foreach($notifications_latest as $notification)
                                        @php
                                        $notification_text = isset($notification->data['title'])? $notification->data['title'] : $notification->data['module'];
                                        @endphp
                                        <a class="dropdown-item" href="{{route("users.notifications", $notification)}}">
                                            <i class="c-icon {{isset($notification->data['icon'])? $notification->data['icon'] : 'cil-bullhorn'}} "></i>&nbsp;{{$notification_text}}
                                        </a>
                                        @endforeach
                                        @endif
                                    </div>
                                </li>

                                <li class="c-header-nav-item dropdown">
                                    <a class="c-header-nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                        <div class="c-avatar">
                                            @if(!empty(auth()->user()->avatar) && file_exists(public_path('/img/avatars/'.auth()->user()->avatar)))
                                                <img src="{{ asset('img/avatars/'.auth()->user()->avatar)}}" class="rounded-circle" alt="User Image" width="50">
                                                @else
                                                <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="rounded-circle" alt="User Image" width="50">
                                            @endif    
                                        </div>
                                    </a>

                                    <?php $role = Auth::user()->roles()->get(); ?>
                                    <!-- Nursing Professional Edit --> 
                                 @if(!$role->isEmpty())        
                                    @if($role[0]['id'] == 1)
                                    <div class="dropdown-menu dropdown-menu-right pt-0">
                                        <a class="dropdown-item" href="{{ route('backend.dashboard')}}"><i class="fa fa-user"></i>&nbsp; {{ucfirst(auth()->user()->name) }}</a>

                                        <a class="dropdown-item" href="{{ route('backend.dashboard')}}"><i class="fa fa-dashboard"></i>&nbsp; @lang('navs.frontend.dashboard')</a>

                                        <a class="dropdown-item" href="#"><i class="fa fa-envelope"></i>&nbsp;
                                            {{ Auth::user()->email }}</a>

                                        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="fas fa-sign-out-alt"></i></i>&nbsp;
                                            @lang('Logout')
                                        </a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;"> 
                                            @csrf 
                                        </form>
                                    </div>
                                    
                                    @else
                                    <div class="dropdown-menu dropdown-menu-right pt-0">
                                        <a class="dropdown-item" href="{{ route('users.dashboard')}}"><i class="fa fa-user"></i>&nbsp; {{ucfirst(auth()->user()->name) }}</a>

                                        <a class="dropdown-item" href="{{ route('users.dashboard')}}"><i class="fa fa-dashboard"></i>&nbsp; @lang('navs.frontend.dashboard')</a>

                                        <a class="dropdown-item" href="{{ route('frontend.users.profile', auth()->user()->id) }}"><i class="fas fa-user-check"></i>&nbsp; @lang('navs.frontend.user.account')</a>

                                        <a class="dropdown-item" href="#"><i class="fa fa-envelope"></i>&nbsp;
                                            {{ Auth::user()->email }}</a>

                                        <a class="dropdown-item" href="{{ url('notifications') }}"><i class="fa fa-bell"></i>&nbsp;
                                            @lang('Notifications') <span class="badge badge-danger ml-auto">{{$notifications_count}}</span></a>

                                        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="fas fa-sign-out-alt"></i></i>&nbsp;
                                            @lang('Logout')
                                        </a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;"> 
                                            @csrf 
                                        </form>
                                    </div>
                                    @endif
                                @endif    
                                </li>
                            </ul>
                            @endguest
                        </div>      
                    </div>
            </div>
        </div>
    </nav>

    <div class="side-menu__block">

        <a href="#" class="side-menu__toggler side-menu__close-btn"><i class="fa fa-times"></i>
        </a>

        <div class="side-menu__block-overlay custom-cursor__overlay">
        </div>
        <div class="side-menu__block-inner ">
            <a href="/" class="side-menu__logo"><img src="{{asset('img/logo.png')}}"></a>
            <nav class="mobile-nav__container">
            </nav>
        </div>
    </div>


    <!-- <nav id="navbar-main" class="navbar navbar-main navbar-expand-lg headroom py-lg-3 px-lg-6 navbar-dark navbar-theme-primary">
        <div class="container">
            <a class="navbar-brand" href="/">
                <img class="navbar-brand-dark common" src="{{asset('img/logo.png')}}" height="35" alt="Logo light">
            </a>
            <div class="navbar-collapse collapse" id="navbar_global">
                <div class="navbar-collapse-header">
                    <div class="row">
                        <div class="col-6 collapse-brand">
                            <a href="/">
                                <img src="{{asset('img/backend-logo.jpg')}}" height="35" alt="Logo Impact">
                            </a>
                        </div>
                        <div class="col-6 collapse-close">
                            <a href="#navbar_global" role="button" class="fas fa-times" data-toggle="collapse"
                                data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false"
                                aria-label="Toggle navigation"></a>
                        </div>
                    </div>
                </div>
                <ul class="navbar-nav navbar-nav-hover justify-content-center">
                    <li class="nav-item">
                        <a href="/" class="nav-link">
                            <span class="fas fa-home mr-2"></span> Home
                        </a>
                    </li>    
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" aria-expanded="false" data-toggle="dropdown">
                            <span class="nav-link-inner-text mr-1">
                                <span class="fas fa-user mr-1"></span>
                                Account
                            </span>
                            <i class="fas fa-angle-down nav-link-arrow"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-lg">
                            <div class="col-auto px-0" data-dropdown-content>
                                <div class="list-group list-group-flush">
                                    @auth
                                    <a href="{{ route('frontend.users.profile', auth()->user()->id) }}"
                                        class="list-group-item list-group-item-action d-flex align-items-center p-0 py-3 px-lg-4">
                                        <span class="icon icon-sm icon-success"><i class="fas fa-user"></i></span>
                                        <div class="ml-4">
                                            <span class="text-dark d-block">
                                                {{ Auth::user()->name }}
                                            </span>
                                            <span class="small">View profile details!</span>
                                        </div>
                                    </a>
                                    <a href="{{ route('logout') }}"
                                        class="list-group-item list-group-item-action d-flex align-items-center p-0 py-3 px-lg-4" onclick="event.preventDefault(); document.getElementById('account-logout-form').submit();">
                                        <span class="icon icon-sm icon-secondary">
                                            <i class="fas fa-sign-out-alt"></i>
                                        </span>
                                        <div class="ml-4">
                                            <span class="text-dark d-block">
                                                Logout
                                            </span>
                                            <span class="small">Logout from your account!</span>
                                        </div>
                                    </a>
                                    <form id="account-logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                    @else
                                    <a href="{{ route('login') }}"
                                        class="list-group-item list-group-item-action d-flex align-items-center p-0 py-3 px-lg-4">
                                        <span class="icon icon-sm icon-secondary"><i class="fas fa-key"></i></span>
                                        <div class="ml-4">
                                            <span class="text-dark d-block">
                                                Login
                                            </span>
                                            <span class="small">Login to the application</span>
                                        </div>
                                    </a>
                                    @if(user_registration())
                                    <a href="{{ route('register') }}"
                                        class="list-group-item list-group-item-action d-flex align-items-center p-0 py-3 px-lg-4">
                                        <span class="icon icon-sm icon-primary">
                                            <i class="fas fa-address-card"></i>
                                        </span>
                                        <div class="ml-4">
                                            <span class="text-dark d-block">Register</span>
                                            <span class="small">Join with us!</span>
                                        </div>
                                    </a>
                                    @endif
                                    @endauth
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="d-none d-lg-block">
                @can('view_backend')
                <a href="{{ route('backend.dashboard') }}" class="btn btn-white animate-up-2 mr-3"><i class="fas fa-tachometer-alt mr-2"></i> Dashboard</a>
                @endcan
            </div> -->
            <div class="d-flex d-lg-none align-items-center">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            </div>
        </div>


        <div class="modal" id="myModal9">
            <div class="modal-dialog">
                <div class="modal-content" style="width:900px; margin-left: -135px;">
                    <div class="modal-header">
                        <h5 class="modal-title font-weight-bold text-info" id="exampleModalScrollableTitle">Become Nursing Detail</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="needs-validation" novalidate method="POST" action="{{url('become-nursing')}}" accept-charset="UTF-8" class="form-horizontal" role="form" id="dynamicTable" name="mainForm" enctype="multipart/form-data"> {{csrf_field()}}    
                            <div class="form-row">
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom01">First name</label>
                                        <input type="text" class="form-control" id="validationCustom01" placeholder="First name" name="first_name" value="" required>
                                        <div class="valid-feedback">
                                        Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter first name.
                                        </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom02">Last name</label>
                                        <input type="text" class="form-control" id="validationCustom02" placeholder="Last name" name="last_name" value="" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter last name.
                                        </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustomEmail">Email</label>
                                        <input type="email" name="email" class="form-control" id="validationCustomEmail" placeholder="Email" value="" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid email.
                                        </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Contact Num</label>
                                        <input type="number" name="contact_num" class="form-control" id="validationCustom03" placeholder="Contact Number" value="" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" maxlength="13" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid Phone Num.
                                        </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="col-md-4 mb-3">
                                    <label for="validationCustom10">Gender</label>
                                        <div class="custom-control custom-radio">
                                           <input type="radio" value="male" id="male" name="gender" checked>
                                            <label for="Male">Male</label>
                                        </div>
                                        <div class="custom-control custom-radio">
                                           <input type="radio" value="female" id="female" name="gender">
                                            <label for="Female">Female</label>
                                        </div>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid Gender.
                                        </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="validationCustom11">Specialization</label>
                                        <input type="text" name="specialization" class="form-control" id="validationCustom11" placeholder="Specialization" value="" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid Specialization.
                                        </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="validationCustom12">Experience <span class="text-danger">(in years) </span></label>
                                        <input type="text" name="experience" class="form-control" id="validationCustom12" placeholder="Experience" value="" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid Experience.
                                        </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="col-md-3 mb-3">
                                    <label for="validationCustom04">City</label>
                                        <input type="text" name="city" class="form-control" id="validationCustom04" placeholder="City" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please provide a valid city.
                                        </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="validationCustom05">State</label>
                                        <input type="text" name="state" class="form-control" id="validationCustom05" placeholder="State" required>
                                         <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please provide a valid state.
                                        </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="validationCustom06">Country</label>
                                        <input type="text" name="country" class="form-control" id="validationCustom06" placeholder="Country" required>
                                         <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please provide a valid Country.
                                        </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="validationCustom07">Zip</label>
                                        <input type="text" name="zip_code" class="form-control" id="validationCustom07" placeholder="Zip" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please provide a valid zip.
                                        </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom08">Address street 1</label>
                                        <input type="text" name="address1" class="form-control" id="validationCustom08" placeholder="Address 1" value="" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid Address.
                                        </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom09">Address street 2</label>
                                        <input type="text" name="address2" class="form-control" id="validationCustom09" placeholder="Address 2" value="" required>
                                        <div class="valid-feedback">
                                            Looks good!
                                        </div>
                                        <div class="invalid-feedback">
                                            Please enter valid address 2.
                                        </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="validationTextarea">About you</label>
                                    <textarea class="form-control" id="validationTextarea" placeholder="Describe about you" row="10" cols="100" name="about_me" required></textarea>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                    <div class="invalid-feedback">
                                        Please enter a message in the textarea.
                                    </div>
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
                                    <label class="form-check-label" for="invalidCheck">
                                        Agree to terms and conditions
                                    </label>
                                    <div class="invalid-feedback">
                                        You must agree before submitting.
                                    </div>
                                </div>
                            </div>
                            <!-- <button class="btn btn-success" type="submit">Submit form</button> -->
                            <div class="btn_group">
                                <input class="btn btn-info float-right btn-sm" type="submit" value="submit">
                                <button type="button" class="btn btn-danger float-right mr-3 btn-sm" data-dismiss="modal">Close</button>
                            </div>
                        </form>

                        <script>
                        // Example starter JavaScript for disabling form submissions if there are invalid fields
                        (function() {
                          'use strict';
                          window.addEventListener('load', function() {
                            // Fetch all the forms we want to apply custom Bootstrap validation styles to
                            var forms = document.getElementsByClassName('needs-validation');
                            // Loop over them and prevent submission
                            var validation = Array.prototype.filter.call(forms, function(form) {
                              form.addEventListener('submit', function(event) {
                                if (form.checkValidity() === false) {
                                  event.preventDefault();
                                  event.stopPropagation();
                                }
                                form.classList.add('was-validated');
                              }, false);
                            });
                          }, false);
                        })();
                        </script>
                    </div>
                    <!-- <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div> -->
                </div>
            </div>
        </div>
    </nav> 
</header>
