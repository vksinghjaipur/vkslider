<div class="inner-page-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="user-sidebar">
                    <ul>

                        <li><a class="nav-link {{active_class(Route::is('users.dashboard'))}}" href="{{ route('users.dashboard')}}"><span><i class="fa fa-dashboard"></i></span> Dashboard</a></li>


                        <?php
                            $notifications = optional(auth()->user())->unreadNotifications;
                            $notifications_count = optional($notifications)->count();
                            $notifications_latest = optional($notifications)->take(5);
                        ?>

                        <?php $role = Auth::user()->roles()->get(); ?>

                        <!-- Nursing Professional Sidebar -->
                        @if(!$role->isEmpty()) 
                        @if($role[0]['id'] == 2)
                        <li>
                            <a class="nav-link {{active_class(Route::is('users.notifications'))}}" href="{{ url('notifications') }}"><span><i class="fa fa-bell"></i></span> Notifications @if($notifications_count)<span class="badge badge-pill badge-danger text-white">{{$notifications_count}}</span>@endif 
                            </a>
                        </li>

                        {{-- <li><a href="{{url('/subscription-plans')}}"><span><i class="fa fa-rocket"></i></span> Subscription Plans</a></li> --}}

                        <li>
                            <a class="nav-link {{active_class(Route::is('frontend.users.profile'))}}" href="{{ route('frontend.users.profile', auth()->user()->id) }}"><span><i class="fa fa-user"></i></span> 
                            My Profile
                            </a>
                        </li>

                        <li>
                            <a class="nav-link {{active_class(Route::is('users.timeavailability-slots'))}}" href="{{url('/timeavailability-slots')}}"><span><i class="fa-solid fa-check-to-slot"></i></span> 
                                Time Availability Slots
                            </a>
                        </li>
                        <li>
                            <a class="nav-link {{active_class(Route::is('users.appointments'))}}" href="{{url('/appointments')}}">
                                <span><i class="fa fa-calendar"></i></span> 
                                My Appointment
                            </a>

                        </li>
                        <li>
                            <a class="nav-link {{active_class(Route::is('pages.transaction-history'))}}" href="{{url('/transaction-history')}}">
                                <span><i class="fa fa-history"></i></span> 
                                Transaction History
                            </a>
                        </li>
                       
                        <li>
                            <a class="nav-link {{active_class(Route::is('users.feedbacks'))}}" href="{{url('/feedbacks')}}">
                                <span><i class="fa fa-star"></i></span> 
                                Feedback/Reviews
                            </a>
                        </li>

                        <li>
                            <a href="#"><span><i class="fas fa-address-card"></i></span> 
                                Contact Us
                            </a>
                        </li>
                        
                        <li>
                            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out ml-2" style="font-size:20px;color:#1E67BF"></i>
                                @lang('Logout')
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">  @csrf 
                            </form>
                        </li>

                        <!-- Care Seeker Sidebar -->

                        @elseif( $role[0]['id'] == 3)

                        <li>
                            <a class="nav-link {{active_class(Route::is('users.notifications'))}}" href="{{ url('notifications') }}"><span><i class="fa fa-bell"></i></span> Notifications @if($notifications_count)<span class="badge badge-pill badge-danger text-white">{{$notifications_count}}</span>@endif 
                            </a>
                        </li>

                        <li>
                            <a class="nav-link {{active_class(Route::is('users'))}}" href="{{ route('frontend.users.profile', auth()->user()->id) }}"><span><i class="fa fa-user"></i></span>
                             My Profile
                            </a>
                        </li>

                        <li>
                            <a class="nav-link {{active_class(Route::is('users.my-appointment'))}}" href="{{url('/my-appointment')}}">
                                <span><i class="fa fa-calendar"></i></span> 
                                My Bookings
                            </a>

                        </li>


                        <li>
                            <a class="nav-link {{active_class(Route::is('pages.transaction-history'))}}" href="{{url('/transaction-history')}}">
                                <span><i class="fa fa-inr"></i></span> 
                                Payment History
                            </a>
                        </li>

                        <li>
                            <a class="nav-link {{active_class(Route::is('users.favorites'))}}" href="{{url('/favorites')}}">
                                <span><i class="fa fa-heart"></i></span> 
                                My Favorites
                            </a>

                        </li>


                        <li>
                            <a class="nav-link {{active_class(Route::is('users.feedbacks'))}}" href="{{url('/feedbacks')}}">
                                <span><i class="fa fa-star"></i></span> 
                                Feedback/Reviews
                            </a>
                        </li>

                        <li>
                            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out ml-2" style="font-size:20px;color:#1E67BF"></i>
                                    @lang('Logout')
                                 </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;"> 
                                            @csrf 
                                 </form>
                        </li>


                        @elseif( $role[0]['id'] == 'care seeker')

                        <li>
                            <a class="nav-link {{active_class(Route::is('users.notifications'))}}" href="{{ url('notifications') }}"><span><i class="fa fa-bell"></i></span> Notifications @if($notifications_count)<span class="badge badge-pill badge-danger text-white">{{$notifications_count}}</span>@endif 
                            </a>
                        </li>

                        <li>
                            <a class="nav-link {{active_class(Route::is('users'))}}" href="{{ route('frontend.users.profile', auth()->user()->id) }}"><span><i class="fa fa-user"></i></span>
                             My Profile
                            </a>
                        </li>

                       
                        <li>
                            <a class="nav-link {{active_class(Route::is('users.favorites'))}}" href="{{url('/favorites')}}">
                                <span><i class="fa fa-heart"></i></span> 
                                My Favorites
                            </a>

                        </li>


                        <li>
                            <a class="nav-link {{active_class(Route::is('users.feedbacks'))}}" href="{{url('/feedbacks')}}">
                                <span><i class="fa fa-star"></i></span> 
                                Feedback/Reviews
                            </a>
                        </li>

                        <li>
                            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out ml-2" style="font-size:20px;color:#1E67BF"></i>
                                    @lang('Logout')
                                 </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;"> 
                                            @csrf 
                                 </form>
                        </li>


                        @elseif($role[0]['id'] == 0)

                        return redirect('/home');
                        @endif
                        @endif      
                    </ul>
                </div>
            </div>