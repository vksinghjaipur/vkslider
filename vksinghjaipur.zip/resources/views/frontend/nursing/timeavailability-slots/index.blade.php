@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<style>
  .toggle.ios, .toggle-on.ios, .toggle-off.ios { border-radius: 20rem; }
  .toggle.ios .toggle-handle { border-radius: 20rem; }
</style>
<div class="col-md-9">
    <!-- <div class="content-header">
        <div id="message_success" style="display:none" class="alert alert-success"> Slots Status Enabled </div> 
        <div id="message_error" style="display:none" class="alert alert-danger"> Slots Status Disabled </div>
    </div> -->
    <div class="dashboard-right-box">
        <div class="availability-slots">
            <h4 class="card-title mb-0">
                <i class="fa-solid fa-check-to-slot"></i> Time Availability Slots
            </h4>
        </div>
        <div class="row mt-4">
            <div class="col">
                <form method="POST" action="{{route('users.timeavailability-slots.store')}}" enctype="multipart/form-data" >@csrf
                    <input type="hidden" id="duration" name="duration" value="45" />
                    <input type="hidden" id="day_code" name="day_code" value="1" />
                    <div class="table-responsive">
                        <table id="example11" class="table table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Day</th>
                                    <th>Availablity</th>
                                    <th>Bookings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <span  class="nav-link active h6 p-2 daycode"  data-day="1" value="sunday">Sunday </span>
                                        
                                        <?php 

                                            echo date("d M Y", strtotime('sunday this week')), "\n";
                                        ?>

                                    </td>
                                            
                                    <td>
                                        @php
                                            $daysunmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='sun' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daysunmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                        
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox" name="status[sun][]" value="1"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="sun" @if($daysunmor==1) checked @endif data-style="ios">
                                    </td>
                                    
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot1">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sun' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','sun')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sun][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','sun')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sun][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot1">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sun' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','sun')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sun][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sun')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[sun][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot1">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sun' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','sun')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sun][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sun')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sun][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>          
                                </tr>

                                <!--- Monday code --->

                                <tr>   
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="2" value="monday">Monday </span>
                                        <?php 
                                            echo date("d M Y", strtotime('monday this week')), "\n";   
                                        ?>
                                    </td>   
                                    <td>
                                        @php
                                            $daymonmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='mon' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daymonmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox" name="status[mon][]" value="1"   data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="mon" @if($daymonmor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot2">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='mon' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','mon')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[mon][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','mon')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[mon][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot2">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='mon' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','mon')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[mon][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','mon')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[mon][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot2">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='mon' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','mon')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[mon][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','mon')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[mon][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <!--- Tuesday Code --->

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="3" value="tuesday">Tuesday </span>
                                        <?php 
                                            echo date("d M Y", strtotime('tuesday this week')), "\n";   
                                        ?>
                                    </td>
                                    <td>
                                        @php
                                            $daytuemor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='tue' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daytuemor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  name="status[tue][]" value="1"  data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="tue" @if($daytuemor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot3">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='tue' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','tue')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[tue][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','tue')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[tue][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot3">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='tue' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','tue')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[tue][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','tue')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[tue][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot3">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='tue' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','tue')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[tue][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','tue')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[tue][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="4" value="wednesday">Wednesday </span>
                                        <?php 
                                            echo date("d M Y", strtotime('wednesday this week')), "\n";   
                                        ?>
                                    </td>
                                    <td>
                                        @php
                                            $daywedmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='wed' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daywedmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  name="status[wed][]" value="1"   data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="wed" @if($daywedmor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot4">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='wed' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','wed')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[wed][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','wed')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[wed][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot4">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='wed' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','wed')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[wed][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','wed')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[wed][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot4">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='wed' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','wed')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[wed][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','wed')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[wed][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="5" value="thursday">Thursday </span>
                                        <?php 
                                            echo date("d M Y", strtotime('thursday this week')), "\n";   
                                        ?>
                                    </td>
                                    <td>
                                        @php
                                            $daythumor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='thu' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daythumor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  name="status[thu][]" value="1"   data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="thu" @if($daythumor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot5">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='thu' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','thu')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[thu][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','thu')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[thu][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot5">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='thu' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','thu')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[thu][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','thu')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[thu][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot5">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='thu' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','thu')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[thu][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','thu')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[thu][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                                <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="6" value="friday">Friday </span>
                                        <?php 
                                            echo date("d M Y", strtotime('friday this week')), "\n";   
                                        ?>
                                    </td>
                                    <td>
                                        @php
                                            $dayfrimor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='fri' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $dayfrimor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  name="status[fri][]" value="1"   data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="fri" @if($dayfrimor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot6">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='fri' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','fri')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[fri][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','fri')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[fri][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot6">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='fri' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','fri')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[fri][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','fri')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[fri][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot6">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='fri' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','fri')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[fri][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','fri')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[fri][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>

                               <tr>    
                                    <td>
                                        <span class="nav-link active h6 p-2 daycode" data-day="7" value="saturday">Saturday </span>
                                        <?php 
                                            echo date("d M Y", strtotime('saturday this week')), "\n";   
                                        ?>
                                    </td>
                                    <td>
                                        @php
                                            $daysatmor=0;
                                        @endphp
                                        @foreach($slots as $slot_data)
                                            @if($slot_data->day_code=='sat' && $slot_data->title=='mor' && $slot_data->status==1)
                                                @php
                                                $daysatmor=1;
                                                @endphp
                                            @endif
                                        @endforeach
                                            <input  class="changeSlotStatus btn btn-success chkToggle2" type="checkbox"  name="status[sat][]" value="1"   data-toggel="toggel" data-on="on" data-of="no" data-onstyle="success" data-offstyle="danger" data-size="xs" data-code="sat" @if($daysatmor==1) checked @endif data-style="ios">
                                    </td>
                                    <td>      
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="slot7">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sat' && $slot_data->day_section=='morning')
                                                <?php
                                                    $check= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','mor')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','sat')->pluck('day_code')->toArray();
                                                        // print_r($check);
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sat][mor][]" @if(in_array($slot_data->day_name,$check)) checked @endif value="7:00 AM - 12:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                                    <div class="slot-doc-times">
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                            <?php
                                                                $check= DB::table('calendar_day_section_times')
                                                                ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                                ->where('calendar_day_sections.day_code','sat')
                                                                ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                                ->where('calendar_day_sections.title','mor')->pluck('slot_time')->toArray();
                                                                // print_r($check);
                                                            ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sat][mor][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif  value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>  
                                                @endif
                                                 @endforeach
                                            </div>

                                            <div class="tab-pane active" id="slot7">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sat' && $slot_data->day_section=='afternoon')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','aft')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','sat')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sat][aft][]"  @if(in_array($slot_data->day_name,$check1)) checked @endif value="12:00 PM - 17:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                    @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                    @foreach($slot_data->getDayData as $slot_data1)
                                                        <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sat')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','aft')->pluck('slot_time')->toArray();
                                                        ?>
                                                        <div class="doc-slot-list btn btn-sm">
                                                            <span class="mt-1"><input type="checkbox" name="slot_time[sat][aft][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                            <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                            <a href="#" class="delete_schedule"></a>
                                                        </div>
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>

                                            <div class="tab-pane active" id="slot7">
                                                @foreach($result as $slot_data)
                                                @if($slot_data->day_name=='sat' && $slot_data->day_section=='evening')
                                                <?php
                                                    $check1= DB::table('calendar_day_sections')
                                                    ->where('calendar_day_sections.title','eve')
                                                    ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                    ->where('calendar_day_sections.day_code','sat')->pluck('day_code')->toArray();
                                                ?>
                                                <div class="slot-body">
                                                    <span><input type="checkbox" name="title[sat][eve][]" @if(in_array($slot_data->day_name,$check1)) checked @endif value="17:00 PM - 23:00 PM"></span>
                                                    <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM ) </span>
                                                    <div class="slot-doc-times">
                                                     @if(isset($slot_data->getDayData) && !empty($slot_data->getDayData))
                                                        @foreach($slot_data->getDayData as $slot_data1)
                                                           
                                                            <?php
                                                            $check= DB::table('calendar_day_section_times')
                                                            ->join('calendar_day_sections','calendar_day_sections.id','=','calendar_day_section_times.calendar_day_section_id')
                                                            ->where('calendar_day_sections.day_code','sat')
                                                            ->where('calendar_day_sections.doctor_id',auth::user()->id)
                                                            ->where('calendar_day_sections.title','eve')->pluck('slot_time')->toArray();
                                                                ?>
                                                            <div class="doc-slot-list btn btn-sm">
                                                                <span class="mt-1"><input type="checkbox" name="slot_time[sat][eve][]" @if(in_array($slot_data1->time_slot,$check)) checked @endif value="{{$slot_data1->time_slot}}"></span>
                                                                <span class="ml-2">{{$slot_data1->time_slot}}</span>
                                                                <a href="#" class="delete_schedule"></a>
                                                            </div>
                                                           
                                                        @endforeach
                                                    @endif  
                                                    </div>
                                                </div> 
                                                @endif
                                                 @endforeach 
                                            </div>
                                        </div>
                                    </td>    
                                </tr>
                                        
         
                            </tbody>    
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                {{ html()->submit($text = icon('fas fa-save')." Save")->class('btn btn-success') }}
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="float-right">
                                <a href="{{ route("users.timeavailability-slots") }}" class="btn btn-warning" data-toggle="tooltip" title="{{__('labels.backend.cancel')}}"><i class="fas fa-reply"></i> Cancel</a>
                            </div>
                        </div>
                    </div>    
                </form>
            </div>
        </div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
  

<!-- for Update status -->
<script>
    $(document).ready( function () {
         //Update School Teacher Status
         $(".changeSlotStatus").change(function(){
          var day_code = $(this).data('code');
          if($(this).prop("checked")==true){
             $.ajax({ 
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type : 'post',
                url : '{{route('users.timeavailability-slots.update-status')}}',
                data : {status:'1',day_code:day_code},
                success:function(data){
                   toastr.success(data.success);
                },error:function(){
                   alert("Error");
                }
             });

          }else{
            $.ajax({
                headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type : 'post',
                url : '{{route('users.timeavailability-slots.update-status')}}',
                data : {status:'0',day_code:day_code},
                success:function(data){
                    if(data.status==0)
                    {
                           toastr.error(data.error);
                    }
                    else{
                        toastr.success(data.success);
                    }
                },error:function(){
                   alert("Error");
                }
             });
          }
        });
    });
</script>

<script>
$('.nav-link').click(function()
{
    var day= $(this).data('day');
    $('#day_code').val(day);
});
</script>

@endsection

