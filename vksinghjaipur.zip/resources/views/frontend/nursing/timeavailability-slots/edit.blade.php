@extends('frontend.layouts.app')
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    @if(Session::has('flash_message_success'))
        <div class="alert alert-sm alert-success alert-book" role="alert">
            <button type="button" class="close" data-dismiss="alert" area-label="close">
                <span area-hidden="true"> &times;</span>
            </button>
            <strong>{!!session('flash_message_success')!!} </strong>
        </div>
    @endif
    <form method="post" action="{{route('users.timeavailability-slots.update',$slots->id)}}" enctype="multipart/form-data">
      @csrf
        
            @include('frontend.nursing.timeavailability-slots.editform')
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        {{ html()->submit($text = icon('fas fa-save')." Update")->class('btn btn-success') }}
                    </div>
                </div>

                <div class="col-sm-8">
                    <div class="float-right">
                        <a href="{{ route("users.timeavailability-slots") }}" class="btn btn-warning" data-toggle="tooltip" title="{{__('labels.frontend.cancel')}}"><i class="fas fa-reply"></i> Cancel</a>
                    </div>
                </div>
            </div>
        
    </form>
</div>    
@endsection

