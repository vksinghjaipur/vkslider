@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    @if(Session::has('flash_message_success'))
        <div class="alert alert-sm alert-success alert-book" role="alert">
            <button type="button" class="close" data-dismiss="alert" area-label="close">
                <span area-hidden="true"> &times;</span>
            </button>
            <strong>{!!session('flash_message_success')!!} </strong>
        </div>
    @endif

   <form method="POST" action="{{route('users.timeavailability-slots.store')}}" enctype="multipart/form-data" >@csrf
        <div class="dashboard-right-box">
            <h4><i class="fa-solid fa-check-to-slot"></i> Create Time Availability Slots</h4>
                <!-- <div class="time-duration">
                    <label>Timing Slot Duration </label>
                    <select class="form-control" name="duration">
                        <option value="15 mins">15 mins</option>
                        <option value="30 mins">30 mins</option>
                        <option value="45 mins">45 mins</option>
                        <option value="60 mins">60 mins</option>
                    </select>
                </div> -->
                <div class="schedule-box">
                    <div class="schedule-header">
                        <input type="hidden" id="duration" name="duration" value="45" />
                        <input type="hidden" id="day_code" name="day_code" value="1" />
                        <ul class="nav nav-tabs">
                          <li class="nav-item ml-0" id='1'>
                            <a class="nav-link active h6 p-2" data-toggle="tab" href="#slot1" class="daycode" data-day="1" value="sunday">Sunday</a>
                          </li>
                          <li class="nav-item ml-1" id='2' value="monday">
                            <a class="nav-link h6 p-2" data-toggle="tab" href="#slot2" class="daycode" data-day="2">Monday</a>
                          </li>
                          <li class="nav-item ml-1" id='3'>
                            <a class="nav-link h6 p-2" data-toggle="tab" href="#slot3" class="daycode" data-day="3">Tuesday</a>
                          </li>
                          <li class="nav-item ml-1" id='4'>
                            <a class="nav-link h6 p-2" data-toggle="tab" href="#slot4" class="daycode" data-day="4">Wednesday</a>
                          </li>
                          <li class="nav-item ml-1">
                            <a class="nav-link h6 p-2" data-toggle="tab" href="#slot5" class="daycode" data-day="5">Thursday</a>
                          </li>
                          <li class="nav-item ml-1">
                            <a class="nav-link h6 p-2" data-toggle="tab" href="#slot6" class="daycode" data-day="6">Friday</a>
                          </li>
                          <li class="nav-item ml-1">
                            <a class="nav-link h6 p-2 " data-toggle="tab" href="#slot7" class="" data-day="7">Saturday</a>
                          </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane active" id="slot1">
                            <div class="slot-body">
                               {{--  <input type="hidden" name="start_time['mon']" value="7:00 AM">
                                <input type="hidden" name="end_time['mon']" value="12:00 PM"> --}}
                                <span><input type="checkbox" name="title[mor]" value="7:00 AM - 12:00 PM"></span>
                                <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                <div class="slot-doc-times">
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="7:00 am - 7:45 am"></span>
                                        <span class="ml-2">7:00 am - 7:45 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="7:45 am - 8:30 am"></span>
                                         <span class="ml-2">7:45 am - 8:30 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="8:30 am - 9:15 am"></span>
                                        <span class="ml-2"> 8:30 am - 9:15 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>  
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="09:15 am - 10:00 am"></span>
                                         <span class="ml-2">09:15 am - 10:00 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="10:00 am - 10:45 am"></span>
                                         <span class="ml-2">10:00 am - 10:45 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="10:45 am - 11:30 am"></span>
                                         <span class="ml-2">10:45 am - 11:30 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[mor][]" value="11:30 am - 12:00 am"></span>
                                        <span class="ml-2">11:30 am - 12:00 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        <div class="tab-pane active" id="slot1">
                            <div class="slot-body">
                                {{-- <input type="hidden" name="start_time['aft']" value="12:00 PM">
                                <input type="hidden" name="end_time['aft']" value="17:00 PM"> --}}
                                <span><input type="checkbox" name="title[aft]" value="12:00 PM - 17:00 PM"></span>
                                <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 PM - 17:00 PM ) </span>
                                <div class="slot-doc-times">
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="12:00 am - 12:45 pm"></span>
                                        <span class="ml-2">12:00 am - 12:45 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                       <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="12:45 pm - 13:30 pm"></span>
                                        <span class="ml-2">12:45 pm - 13:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                       <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="13:30 pm - 14:15"></span>
                                        <span class="ml-2">13:30 pm - 14:15 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="14:15 pm - 15:00 pm"></span>
                                        <span class="ml-2">14:15 pm - 15:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                       <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="15:00 pm - 15:45 pm"></span>
                                        <span class="ml-2">15:00 pm - 15:45 pm </span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="15:45 pm - 16:30 pm"></span>
                                        <span class="ml-2">15:45 pm - 16:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[aft][]" value="16:30 pm - 17:00 pm"></span>
                                        <span class="ml-2">16:30 pm - 17:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        <div class="tab-pane active" id="slot1">
                            <div class="slot-body">
                               {{--  <input type="hidden" name="start_time['eve']" value="17:00 PM">
                                <input type="hidden" name="end_time['eve']" value="23:00 PM"> --}}
                                <span><input type="checkbox" name="title[eve]" value="17:00 PM - 23:00 PM"></span>
                                <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 PM - 23:00 PM )</span>
                                <div class="slot-doc-times">
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="17:00 pm - 17:45 pm"></span>
                                        <span class="ml-2">17:00 pm - 17:45 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="17:45 pm - 18:30 pm"></span>
                                        <span class="ml-2">17:45 pm - 18:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="18:30 pm - 19:15 pm"></span>
                                        <span class="ml-2">18:30 pm - 19:15 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="19:15 pm - 20:00 pm"></span>
                                        <span class="ml-2">19:15 pm - 20:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="19:15 pm - 20:00 pm"></span>
                                        <span class="ml-2">20:00 pm - 20:45 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="20:45 pm - 21:30 pm"></span>
                                        <span class="ml-2">20:45 pm - 21:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="21:30 pm - 22:15 pm"></span>
                                        <span class="ml-2">21:30 pm - 22:15 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[eve][]" value="22:15 pm - 23:00 pm"></span>
                                        <span class="ml-2">22:15 pm - 23:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    {{ html()->submit($text = icon('fas fa-save')." Save")->class('btn btn-success') }}
                </div>
            </div>

            <div class="col-sm-8">
                <div class="float-right">
                    <a href="{{ route("users.timeavailability-slots") }}" class="btn btn-warning" data-toggle="tooltip" title="{{__('labels.backend.cancel')}}"><i class="fas fa-reply"></i> Cancel</a>
                </div>
            </div>
        </div>
    </form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$('.nav-link').click(function()
{
    var day= $(this).data('day');
    $('#day_code').val(day);
});
</script>
@endsection
