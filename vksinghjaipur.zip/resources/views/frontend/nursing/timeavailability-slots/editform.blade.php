<div class="dashboard-right-box">
    <h4><i class="fa-solid fa-check-to-slot"></i> Update Time Availability Slot</h4>
            <!-- <div class="time-duration">
                <label>Timing Slot Duration </label>
                <select class="form-control">
                    <option>15 mins</option>
                    <option>30 mins</option>
                    <option>45 mins</option>
                    <option>1 Hour</option>
                </select>
            </div> -->
            <div class="schedule-box">
                <div class="schedule-header">
                    <ul class="nav nav-tabs">
                      <li class="nav-item ml-0" id='1'>
                        <a class="nav-link active h6 p-2" data-toggle="tab" href="#slot1" class="daycode" data-day="sun" value="sunday">Sunday</a>
                      </li>
                      <li class="nav-item ml-1" id='2' value="monday">
                        <a class="nav-link h6 p-2" data-toggle="tab" href="#slot2" class="daycode" data-day="mon">Monday</a>
                      </li>
                      <li class="nav-item ml-1" id='3'>
                        <a class="nav-link h6 p-2" data-toggle="tab" href="#slot3" class="daycode" data-day="tue">Tuesday</a>
                      </li>
                      <li class="nav-item ml-1" id='4'>
                        <a class="nav-link h6 p-2" data-toggle="tab" href="#slot4" class="daycode" data-day="wed">Wednesday</a>
                      </li>
                      <li class="nav-item ml-1">
                        <a class="nav-link h6 p-2" data-toggle="tab" href="#slot5" class="daycode" data-day="thu">Thursday</a>
                      </li>
                      <li class="nav-item ml-1">
                        <a class="nav-link h6 p-2" data-toggle="tab" href="#slot6" class="daycode" data-day="fri">Friday</a>
                      </li>
                      <li class="nav-item ml-1">
                        <a class="nav-link h6 p-2 " data-toggle="tab" href="#slot7" class="" data-day="sat">Saturday</a>
                      </li>
                    </ul>
                </div>
                <div class="tab-content">
                    <div class="tab-pane active" id="slot1">
                        <div class="slot-body">
                                <span><input type="checkbox" name="title[]" value="Morning"></span>
                                <span class="font-weight-bold text-dark h6">Morning Time Slots ( 7:00 AM - 12:00 AM ) </span>
                                <div class="slot-doc-times">
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time" value="07:00 am - 07:45 am" @if($slots->slot_time=='07:00 am - 07:45 am')checked @endif></span>
                                        <span class="ml-2">7:00 am - 7:45 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[0][]" value="07:45 am - 08:30 am" @if($slots->slot_time=='07:45 am - 08:30 am')checked @endif></span>
                                         <span class="ml-2">7:45 am - 8:30 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[0][]" value="8:30 am - 9:15 am"{{($slots->slot_time == '8:30 am - 9:15 am' ? ' checked' : '') }}></span>
                                        <span class="ml-2"> 8:30 am - 9:15 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>  
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[0][]" value="09:15 am - 10:00 am"></span>
                                         <span class="ml-2">09:15 am - 10:00 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[0][]" value="10:00 am - 10:45 am"></span>
                                         <span class="ml-2">10:00 am - 10:45 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[0][]" value="10:45 am - 11:30 am"></span>
                                         <span class="ml-2">10:45 am - 11:30 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[0][]" value="11:30 am - 12:00 am"></span>
                                        <span class="ml-2">11:30 am - 12:00 am</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                </div>
                        </div>  
                    </div>
                    <div class="tab-pane active" id="slot1">
                        <div class="slot-body">
                                <span><input type="checkbox" name="title[]" value="Afternoon"></span>
                                <span class="font-weight-bold text-dark h6">Afternoon Time Slots ( 12:00 AM - 17:00 PM ) </span>
                                <div class="slot-doc-times">
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="12:00 am - 12:45 pm"></span>
                                        <span class="ml-2">12:00 am - 12:45 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                       <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="12:45 pm - 13:30 pm"></span>
                                        <span class="ml-2">12:45 pm - 13:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                       <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="13:30 pm - 14:15"></span>
                                        <span class="ml-2">13:30 pm - 14:15 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="14:15 pm - 15:00 pm"></span>
                                        <span class="ml-2">14:15 pm - 15:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                       <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="15:00 pm - 15:45 pm"></span>
                                        <span class="ml-2">15:00 pm - 15:45 pm </span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="15:45 pm - 16:30 pm"></span>
                                        <span class="ml-2">15:45 pm - 16:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[1][]" value="16:30 pm - 17:00 pm"></span>
                                        <span class="ml-2">16:30 pm - 17:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                </div>
                            </div>  
                    </div>  
                    <div class="tab-pane active" id="slot1">
                        <div class="slot-body">
                                <span><input type="checkbox" name="title[]" value="Evening"></span>
                                <span class="font-weight-bold text-dark h6">Evening Time Slots ( 17:00 AM - 23:00 PM )</span>
                                <div class="slot-doc-times">
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="17:00 pm - 17:45 pm"></span>
                                        <span class="ml-2">17:00 pm - 17:45 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="17:45 pm - 18:30 pm"></span>
                                        <span class="ml-2">17:45 pm - 18:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                        <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="18:30 pm - 19:15 pm"></span>
                                        <span class="ml-2">18:30 pm - 19:15 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="19:15 pm - 20:00 pm"></span>
                                        <span class="ml-2">19:15 pm - 20:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="19:15 pm - 20:00 pm"></span>
                                        <span class="ml-2">20:00 pm - 20:45 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="20:45 pm - 21:30 pm"></span>
                                        <span class="ml-2">20:45 pm - 21:30 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="21:30 pm - 22:15 pm"></span>
                                        <span class="ml-2">21:30 pm - 22:15 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                    <div class="doc-slot-list">
                                         <span class="mt-1"><input type="checkbox" name="slot_time[2][]" value="22:15 pm - 23:00 pm"></span>
                                        <span class="ml-2">22:15 pm - 23:00 pm</span>
                                        <a href="#" class="delete_schedule"><i class="fa fa-times"></i></a>
                                    </div>
                                </div>
                            </div>    
                    </div>
                </div>
            </div>
</div>

<script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>

@push('after-styles')

<!-- Select2 Bootstrap 4 Core UI -->
<link href="{{ asset('vendor/select2/select2-coreui-bootstrap4.min.css') }}" rel="stylesheet" />

<!-- Date Time Picker -->
<link rel="stylesheet" href="{{ asset('vendor/bootstrap-4-datetime-picker/css/tempusdominus-bootstrap-4.min.css') }}" />

@endpush
@push ('after-scripts')
<!--card-body-->
<script type="text/javascript" src="{{ asset('vendor/moment/moment.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('vendor/bootstrap-4-datetime-picker/js/tempusdominus-bootstrap-4.min.js') }}"></script>

<script type="text/javascript">
$(function() {
    $('.datetime').datetimepicker({
        format: 'YYYY-MM-DD HH:mm:ss',
        icons: {
            time: 'far fa-clock',
            date: 'far fa-calendar-alt',
            up: 'fas fa-arrow-up',
            down: 'fas fa-arrow-down',
            previous: 'fas fa-chevron-left',
            next: 'fas fa-chevron-right',
            today: 'far fa-calendar-check',
            clear: 'far fa-trash-alt',
            close: 'fas fa-times'
        }
    });
});
</script>

@endpush