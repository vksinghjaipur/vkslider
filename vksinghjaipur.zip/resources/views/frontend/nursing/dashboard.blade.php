@extends('frontend.layouts.app')
@section('title')  @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4>Welcome ! <span>{!! isset(Auth::user()->name) && !empty(Auth::user()->name) ? Auth::user()->name : '' !!}</span></h4>
        <div class="row">
            <div class="col-md-8">
                <div class="dash-ban">
                    <div class="dash-text">
                        <h4>How are feeling today ?</h4>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="media dash-tslot">
                    <div class="media-left">
                        <i class="fa-light fa-clock"></i>
                        <h5>Available days</h5>
                    </div>
                    <div class="media-right">
                        <p>Total :- {{ ($daysNursing->count()/3) }} days</p>
                        <p>
                            @if(isset($daysNursing) && !empty($daysNursing))
                                @foreach($daysNursing as $days)
                                    @if($days->day_code=='sun')
                                        Sunday
                                    @elseif($days->day_code=='mon')
                                        Monday
                                    @elseif($days->day_code=='tue')
                                        Tuesday
                                    @elseif($days->day_code=='wed')
                                        Wednesday
                                    @elseif($days->day_code=='thu')
                                        Thursday
                                    @elseif($days->day_code=='fri')
                                        Friday
                                    @elseif($days->day_code=='sat')
                                        Saturday
                                    @endif
                                @endforeach
                            @endif
                        </p>

                    </div>
                </div>
            </div>
        </div>

        
        <div class="dash-cards">
            <div class="row">

                <!-- show toatl & average of feedbacks -->
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <h5>Users Feedback</h5>
                            <h6>total feedback:-  {{ $feedbackNursing->count() }}</h6>
                            <div class="progress">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="font-weight-bold">Feedback Average :-
                                <?php 
                                    $sum = 0;
                                    foreach($feedbackNursing as $value){
                                        $sum += $value->ratings;
                                    }
                                    if(count($feedbackNursing)!=0)
                                    {
                                        $avg = $sum / count($feedbackNursing);
                                    }
                                    else
                                    {
                                        $avg = $sum;
                                    }
                                    //echo  (number_format($avg,2)); 
                                    echo  '<i class="fa fa-star text-warning"></i>&nbsp;'.number_format($avg,1);
                                ?>    
                            </p>
                        </div>
                    </div>
                </div>

                <!-- show Latest appointment slot -->
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <h5 class="mb-3">Latest Slot</h5>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <!-- show toatl & today Revenew -->
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <h5>Total Income</h5>
                                <?php $total_point= 0; ?> 
                                @if(isset($revenewNursing) && !empty($revenewNursing))
                                    @foreach($revenewNursing as $nursing_income)
                                        <?php   
                                            $total_point=$total_point + (isset($nursing_income->commission_amount)?$nursing_income->commission_amount:''); 
                                        ?>
                                    @endforeach
                                @endif        
                            <div class="progress">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="ml-5 mt-2" style="font-size: 20px;"><i class="fa-solid fa-rupee-sign" style="color:#23CFCF;"></i> {{$total_point}}</p>
                        </div>
                    </div>
                </div>

                <!-- show toatl & today booking -->
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <h5>Appointments</h5>
                            <h6>Today Appointment:- {{ $todaybooking }}</h6>
                            <div class="progress">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p>Total Appointment:- {{ $totalbooking }}</p>
                        </div>
                    </div>
                </div>
            </div>    
        </div> 

        
        <!--- show latest 5 bookings --->
        <div class="dash-cards">
           <div class="card-header dash-table-head">Latest Appointments</h5>
                </div>
            <table class="dashboard-table-new table table-bordered ">
                <thead>
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Image</th>
                        <th scope="col">Name</th>
                        <th scope="col">Cont. Num.</th>
                        <th scope="col">Serivces</th>
                        <th scope="col">Amount</th>
                        <th scope="col">App. Day/Date</th>
                        <th scope="col">App. Time</th>
                        <th scope="col">status</th>
                    </tr>
                </thead>
                <tbody>
                    @if($booking_data->count() == 0)
                        <tr>
                            <td colspan="10" style="text-align:center; font-weight: bold; color:blue; font-size:18px; margin-top: 50px;">No Appointment found.
                            </td>
                        </tr>
                    @endif
                    @if(isset($booking_data) && !empty($booking_data))
                        @foreach($booking_data as $bookings)
                        <tr>
                            <th scope="row">{{$no++}}</th>
                            <td>
                                @if(!empty($bookings->avatar) && file_exists(public_path('/img/avatars/'.$bookings->avatar)))
                                    <img src="{{ asset('img/avatars/'.$bookings->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                @else
                                    <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                @endif
                            </td>
                            <td>{{ucwords($bookings->user_id)}}</td>
                            <td>
                                @if($bookings->status=='Confirm')
                                    <p><span><i class="fa-regular fa-phone"></i></span> {{$bookings->mobile}}</p>
                                @else  
                                    <p><span><i class="fa-regular fa-phone"></i></span> <span class="no-show">********</span></p>
                                @endif 
                            </td>
                            <?php
                                $stname = explode(',', $bookings->service_id);
                                $servicename=array();
                                foreach($stname as $key=>$value){
                                $selected = DB::table('services')
                                ->where('id',$value) 
                                ->first();
                                $result= isset($selected->service_name)?$selected->service_name:'';
                                array_push($servicename,$result);
                                }
                            ?>  
                            <td>{{implode(', ', $servicename)}}</td>
                            <td>{{$bookings->total_amount}}</td>
                            <td>{{$bookings->booking_date}}, {{$bookings->booking_day}}</td>
                            <td>{{$bookings->booking_time}}</td>
                            <td>{{$bookings->status}}</td>
                        </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
         
            </div>    
        </div> 
            
            

        
    </div>
</div>
        </div>
     </div>
 </div>
                        
@endsection

