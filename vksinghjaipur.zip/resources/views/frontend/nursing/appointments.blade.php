@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4><i class="fa fa-calendar"></i> My Appointments</h4>
        <div class="appointment-seaction">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <button class="nav-link btn btn-sm form-cortrol btn-info mr-5 mb-2 font-weight-bold" data-toggle="tab" href="#information"><i class="fa fa-arrow-down"></i></i> Previous Bookings</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link active btn btn-sm form-cortrol btn-success mr-5" data-toggle="tab" href="#feedback"><i class="fa-solid fa-arrow-up"></i> Upcoming Bookings</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link form-cortrol btn btn-danger btn-sm font-weight-bold" data-toggle="tab" href="#booking"><i class="fa-regular fa-xmark"></i> Canceled Bookings</button>
                </li>
            </ul>
            <div class="tab-content">
                <?php 
                    $todaydate = date('Y-m-d');
                    //print_r($todaydate); die();
                ?>
                <div class="tab-pane fade" id="information">
                   @if(!empty($booking_data))
                        @foreach($booking_data as $kp => $vp)
                         <?php   $mydate=strtotime($vp->booking_date); ?>
                            @if($mydate < strtotime($todaydate))
                            <div class="appointment-list">
                                <div class="appointment-user">
                                    @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                        <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                    @else
                                        <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                    @endif
                                </div>
                                <div class="appointment-user-detail">
                                    <div class="appointment-info">
                                        <h3><span><i class="fa-regular fa-user"></i></span> {{ucwords($vp->user_id)}}</h3>
                                        <p><span><i class="fa-regular fa-calendar"></i></span>{{$vp->booking_date}}, {{$vp->booking_day}}</p>
                                        <p><span><i class="fa-regular fa-clock"></i></span>{{$vp->booking_time}}</p>
                                        @if($vp->status=='Confirm')
                                            <p><span><i class="fa-regular fa-envelope"></i></span> {{$vp->email}}</p>
                                            <p><span><i class="fa-regular fa-phone"></i></span> {{$vp->mobile}}</p>
                                        @else
                                            <p><span><i class="fa-regular fa-envelope"></i></span> <span class="no-show">********</span></p>
                                            <p><span><i class="fa-regular fa-phone"></i></span> <span class="no-show">********</span></p>
                                        @endif  
                                    </div>
                                    <div class="appointment-action">
                                        <button class="btn view-btn" data-toggle="modal" data-target="#myModal9_{{$kp}}"title="Booking Details"><i class="fa-regular fa-eye"></i> View</button>

                                        <!-- @if($vp->status=='Confirm')
                                            <button class="btn view-btn accept-btn"><i class="fa-regular fa-check"></i> Accepted</button>
                                        @endif   -->
                                        @if($vp->status=='Reject')  
                                            <button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Rejected</button>
                                        @elseif($vp->status=='Reject Request')
                                            <button class="btn view-btn cancel-btn" data-toggle="tooltip" title='You applied for appointment rejection, it will be Confirm by admin.'><i class="fa-regular fa-xmark"></i> 
                                                @if($vp->user_type==2)
                                                    You Applied for rejection
                                                @elseif($vp->user_type==3)
                                                    Careseeker Applied for rejection
                                                @endif        
                                            </button>
                                        @elseif($vp->status=='Confirm') 
                                            <button class="btn view-btn accept-btn"><i class="fa-regular fa-check"></i> Accepted</button>
                                        @if($vp->booking_status=='UnComplete')  
                                            <a href="{!! URL::to('booking'.'/'.$vp->id.'/complete') !!}"><button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> UnComplete</button></a>
                                        @else    
                                            <!-- <form method="POST" action="{{route('users.complete',$vp->id)}}">@csrf
                                                <button type="button" class="btn btn-sm show_complete btn view-btn accept-btn" data-toggle="tooltip" title='Appointment Complete'> <i class="fa-regular fa-check"></i> Complete</button>
                                            </form> -->
                                            <button class="btn view-btn info-btn"><i class="fa-regular fa-xmark"></i> Completed</button>
                                        @endif     
                                        @else    
                                            <button class="btn view-btn info-btn"><i class="fa-regular fa-xmark"></i> Not Responce</button>
                                        @endif     
                                    </div>
                                </div>
                            </div>
                            @endif
                        @endforeach
                        @else
                        No Previous Appointment found..
                    @endif
                </div>
                <div class="tab-pane active" id="feedback">
                    @if(!empty($booking_data))
                        @foreach($booking_data as $kp => $vp)
                          <?php   $mydate=strtotime($vp->booking_date); ?>
                            @if(!empty($todaydate) && ($mydate >= strtotime($todaydate)))
                            <div class="appointment-list">
                                <div class="appointment-user">
                                    @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                        <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                    @else
                                        <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                    @endif
                                </div>
                                <div class="appointment-user-detail">
                                    <div class="appointment-info">
                                        <h3><span><i class="fa-regular fa-user"></i></span> {{ucwords($vp->user_id)}}</h3>
                                        <p><span><i class="fa-regular fa-calendar"></i></span>{{$vp->booking_date}}, {{$vp->booking_day}}</p>
                                        <p><span><i class="fa-regular fa-clock"></i></span>{{$vp->booking_time}}</p>
                                        @if($vp->status=='Confirm')
                                            <p><span><i class="fa-regular fa-envelope"></i></span> {{$vp->email}}</p>
                                            <p><span><i class="fa-regular fa-phone-flip"></i></span> {{$vp->mobile}}</p>
                                        @else
                                            <p><span><i class="fa-regular fa-envelope"></i></span> <span class="no-show">********</span></p>
                                            <p><span><i class="fa-regular fa-phone-flip"></i></span> <span class="no-show">********</span></p>
                                        @endif    
                                    </div>
                                    <div class="appointment-action">
                                        <button class="btn view-btn" data-toggle="modal" data-target="#myModal9_{{$kp}}"title="Booking Details"><i class="fa-regular fa-eye"></i> View</button>

                                        @if($vp->status=='Confirm')
                                            <button class="btn view-btn accept-btn"><i class="fa-regular fa-check"></i> Accepted</button>
                                        @elseif($vp->status=='Reject Request')  
                                            <button class="btn view-btn cancel-btn" data-toggle="tooltip" title='You applied for appointment rejection, it will be Confirm by admin.'><i class="fa-regular fa-xmark"></i> 
                                                @if($vp->user_type==2)
                                                    You Applied for rejection
                                                @elseif($vp->user_type==3)
                                                    Careseeker Applied for rejection
                                                @endif        
                                            </button>
                                        @else    
                                            <form method="POST" action="{{route('users.confirm',$vp->id)}}">@csrf
                                                <button type="button" class="btn btn-sm show_confirm btn view-btn accept-btn" data-toggle="tooltip" title='Appointment Confirm'> <i class="fa-regular fa-check"></i> Accept</button>
                                            </form>
                                        @endif  
                                        @if($vp->status=='Reject')  
                                            <button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Rejected</button>
                                        @elseif($vp->status=='Reject Request')
                                            
                                        @else    
                                            <!-- <a href="{!! URL::to('booking'.'/'.$vp->id.'/reject') !!}"><button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Reject</button></a> -->
                                            <button class="btn view-btn cancel-btn" data-toggle="modal" data-target="#myModal5_{{$kp}}"title="Reject Request"><i class="fa-regular fa-xmark"></i> Reject</button>
                                        @endif     
                                    </div>
                                </div>
                            </div>
                            @endif
                        @endforeach
                        @else
                        No Upcomming Appointment found..
                    @endif  
                </div>
                <div class="tab-pane fade" id="booking">
                   @if(!empty($booking_data))
                        @foreach($booking_data as $kp => $vp)
                            @if($vp->status=='Reject')
                            <div class="appointment-list">
                                <div class="appointment-user">
                                    @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                        <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                    @else
                                        <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                    @endif
                                </div>
                                <div class="appointment-user-detail">
                                    <div class="appointment-info">
                                        <h3><span><i class="fa-regular fa-user"></i></span> {{ucwords($vp->user_id)}}</h3>
                                        <p><span><i class="fa-regular fa-calendar"></i></span>{{$vp->booking_date}}, {{$vp->booking_day}}</p>
                                        <p><span><i class="fa-regular fa-clock"></i></span>{{$vp->booking_time}}</p>
                                        @if($vp->status=='Confirm')
                                            <p><span><i class="fa-regular fa-envelope"></i></span> {{$vp->email}}</p>
                                            <p><span><i class="fa-regular fa-phone-flip"></i></span> {{$vp->mobile}}</p>
                                        @else
                                            <p><span><i class="fa-regular fa-envelope"></i></span> <span class="no-show">********</span></p>
                                            <p><span><i class="fa-regular fa-phone-flip"></i></span> <span class="no-show">********</span></p>
                                        @endif  
                                    </div>
                                    <div class="appointment-action">
                                        <button class="btn view-btn" data-toggle="modal" data-target="#myModal9_{{$kp}}"title="Booking Details"><i class="fa-regular fa-eye"></i> View</button>

                                        @if($vp->status=='Reject')  
                                            <button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Rejected</button>
                                        @elseif($vp->status=='Reject Request')
                                            <button class="btn view-btn cancel-btn" data-toggle="tooltip" title='You applied for appointment rejection, it will be Confirm by admin.'><i class="fa-regular fa-xmark"></i> 
                                                @if($vp->user_type==2)
                                                    You Applied for rejection
                                                @elseif($vp->user_type==3)
                                                    Careseeker Applied for rejection
                                                @endif        
                                            </button>
                                        @else    
                                            <a href="{!! URL::to('booking'.'/'.$vp->id.'/reject') !!}"><button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Reject</button></a>
                                        @endif     
                                    </div>
                                </div>
                            </div>
                            @endif
                        @endforeach
                        @else
                        No Cancelled Appointment found..
                    @endif  
                </div>
            </div> 
        </div>

        <!--- View Booking details --->
        @if(!empty($booking_data))
            @foreach($booking_data as $kp => $vp)
                <!--- Modal for show booking details --->
                <div class="modal app-modal" id="myModal9_{{$kp}}">
                    <div class="modal-dialog">
                        <div class="modal-content" style="width:600px;">
                            <div class="modal-header">
                                <h5 class="modal-title font-weight-bold text-info" id="exampleModalScrollableTitle">Appointment Detail</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputEmail4" class="text-info">Patient Name</label>
                                            <input type="email" class="form-control" id="inputEmail4" value="{{ucwords($vp->patient_name)}}" readonly="">
                                        </div>
                                        @if($vp->status=='Confirm')
                                            <div class="form-group col-md-5">
                                                <label for="inputEmail4" class="text-info">Patient Email</label>
                                                <input type="email" class="form-control" id="inputEmail4" value="{{ucwords($vp->email)}}" readonly="">
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="inputEmail4" class="text-info">Contact Number</label>
                                                <input type="email" class="form-control" id="inputEmail4" value="{{$vp->contact_num}}" readonly="">
                                            </div>
                                        @else
                                            <div class="form-group col-md-5">
                                                <label for="inputEmail4" class="text-info">Patient Email</label>
                                                <input type="email" class="form-control" id="inputEmail4" value="**********" readonly="">
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="inputEmail4" class="text-info">Contact Number</label>
                                                <input type="email" class="form-control" id="inputEmail4" value="**********" readonly="">
                                            </div>
                                        @endif    
                                    </div>
                                    <?php
                                        $stname = explode(',', $vp->service_id);
                                        $servicename=array();
                                        foreach($stname as $key=>$value){
                                        $selected = DB::table('services')
                                        ->where('id',$value) 
                                        ->first();
                                        $result= isset($selected->service_name)?$selected->service_name:'';
                                        array_push($servicename,$result);
                                        }
                                    ?>  
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail4" class="text-info">Services</label>
                                            <input type="email" class="form-control" id="inputEmail4" value="{{implode(', ', $servicename)}}" readonly="">
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="inputEmail4" class="text-info">Total Amount</label>
                                            <input type="email" class="form-control" id="inputEmail4" value="{{$vp->total_amount}}" readonly="">
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="inputEmail4" class="text-info">Booking Status</label>
                                            <input type="email" class="form-control" id="inputEmail4" value="{{$vp->status}}" readonly="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputAddress2" class="text-info">Message</label>
                                        <textarea col="15" row="20" class="form-control" id="inputAddress2">{{$vp->message}}</textarea>
                                    </div>
                                   
                                    <div class="form-group">
                                        <label for="inputAddress2" class="text-info">Address</label>
                                        <textarea col="15" row="20" class="form-control" id="inputAddress2">{{$vp->house_num}},{{$vp->address}},{{$vp->landmark}}</textarea>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif


        <!--- Reject Booking with cancel reason --->
        @if(!empty($booking_data))
            @foreach($booking_data as $kp => $vp)
                <!--- Modal for show booking details --->
                <div class="modal" id="myModal5_{{$kp}}">
                    <div class="modal-dialog">
                        <div class="modal-content" style="width:500px; margin-top: 100px;">
                            <div class="modal-header">
                                <h5 class="modal-title font-weight-bold text-info" id="exampleModalScrollableTitle">Select Cancellation Reason</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="POST" action="{{route('users.reject',$vp->id)}}">@csrf
                                    
                                      <input type="radio" id="html" name="cancel_reason" value="Need the service immediately">
                                      <label for="html">Need the service immediately</label><br>

                                      <input type="radio" id="css" name="cancel_reason" value="No longer need the service">
                                      <label for="css">No longer need the service</label><br>

                                      <input type="radio" id="javascript" name="cancel_reason" value="Nursing professional asked to cancel">
                                      <label for="javascript">Nursing professional asked to cancel</label><br>

                                      <input type="radio" id="dbms" name="cancel_reason" value="Other" class="ml-2">
                                      <label for="dbms">Other</label><br>

                                    <div class="btn_group">
                                        <input class="btn btn-info float-right btn-sm" type="submit" value="Update">
                                        <button type="button" class="btn btn-danger float-right mr-3 btn-sm" data-dismiss="modal">Close</button>
                                    </div>     
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
    $('.show_confirm').click(function(event) {
        var form =  $(this).closest("form");
        var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to do Complete appointment ?`,
              text: "you will get notification.",
              icon: "success",
              buttons: true,
              dangerMode: true,
            })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
    $('.nav-link').click(function()
    {
      var type= $(this).data('approve');
      $('.searchtype').val(type);
    })
</script>
@endsection
