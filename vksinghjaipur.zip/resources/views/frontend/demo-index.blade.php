@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
<section class="slider-one__wrapper">
    <div class="slider-one__nav">
        <a href="#" class="slider-one__nav-left">
            <i class="far fa-angle-left"></i>
        </a>
        <a href="#" class="slider-one__nav-right">
            <i class="far fa-angle-right"></i>
        </a>
    </div>
    <div class="slider-one__carousel owl-carousel owl-theme thm__owl-carousel" data-options='{
        "items": 1, "loop": true, "autoplay": true, "autoplayHoverPause": true, "autoplayTimeout": 5000,
        "margin": 0, "dots": false, "nav": false, "animateOut": &quot;fadeOut&quot;, "animateIn": &quot;fadeIn&quot;, "active": true, "smartSpeed": 1000
    }' data-carousel-next-btn=".slider-one__nav-right" data-carousel-prev-btn=".slider-one__nav-left">

        @if(isset($banners) && !empty($banners))
            @foreach($banners as $banner_data)
                <div class="item" style="background-image: url({{asset('img/banners/'.$banner_data->banner_image)}});">
                    <div class="slider-one__item">
                        <div class="container">
                            <div class="row justify-content-end">
                                <div class="col-lg-12 d-flex justify-content-end">
                                    <div class="slider-one__content">
                                        <div class="slider-one__content-inner">
                                            <h3>{{$banner_data->banner_title}}</h3>
                                            <p>{!! $banner_data->banner_content !!}</p>
                                            <a href="#" class="thm-btn slider-one__btn">Get Appointment</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif    
        
    </div>
</section>

<section class="ml-5 mb-5">
    <div class="container">
        <h2 class="text-center font-weight-bold text-dark mb-5">So, why choose us?</h2>
        <div class="row">
            <div class="col">
                <img src="{{asset('img/booking-patient.png')}}" width="250" height="200">
                <h5 class="font-weight-bold text-dark mt-3">Offer your appointment</h5>
                <p class="font-weight-bold">you can book appointment with doctor according your choice, with according your suitable time.</p>
            </div>
            <div class="col">
                <img src="{{asset('img/booking-app.png')}}" width="250" height="190">
                <h5 class="font-weight-bold text-dark mt-4">Freedom of appointment</h5>
                <p class="font-weight-bold">you can book appointment with doctor according your choice, with according your suitable time.</p>
            </div>
            <div class="col">
                <img src="{{asset('img/booking-doctor.png')}}" width="250" height="200">
                <h5 class="font-weight-bold text-dark mt-3">As choice appointment with nursing </h5>
                <p class="font-weight-bold">you can book appointment with doctor according your choice, with according your suitable time.</p>
            </div>
        </div>
    </div>
</section>

<section class="ml-5 bg-white">
    <div class="container ">
        <div class="row">
            <div class="col-md-7">
                <h2 class="text-center font-weight-bold text-dark show-space">How does it work?</h2>
                    <div class="row">
                        <div class="col-md-0">
                            <span aria-hidden="true" class="round-num">1</span>
                        </div>
                        <div class="col-md-11"><h5 class="home-work">Save on rides</h5></div>
                        <h6 class="ml-5 mt-2">With inDriver, you can book rides way cheaper! Say no to compulsory rates and high-demand manipulations.</h6>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-0">
                            <span aria-hidden="true" class="round-num">2</span>
                        </div>
                        <div class="col-md-11"><h5 class="home-work">Offer your own price</h5></div>
                        <h6 class="ml-5 mt-2">With carebee, you can book appointment way cheaper! Say no to compulsory rates and high-demand manipulations.</h6>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-0">
                            <span aria-hidden="true" class="round-num">3</span>
                        </div>
                        <div class="col-md-11"><h5 class="home-work">Select the best nursing staff offer</h5></div>
                        <h6 class="ml-5 mt-2">With carebee, you can book appointment way cheaper! Say no to compulsory rates and high-demand manipulations.</h6>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-0">
                            <span aria-hidden="true" class="round-num">4</span>
                        </div>
                        <div class="col-md-11"><h5 class="home-work">Average vehicle arrival time: 5 minutes</h5></div>
                        <h6 class="ml-5 mt-2">With carebee, you can book appointment way cheaper! Say no to compulsory rates and high-demand manipulations.</h6>
                    </div>
                
            </div>
            <div class="col-md-5 show-space">
                <img src="{{asset('img/my-app.png')}}" width="650" height="490">
                
            </div>
        </div>
    </div>
</section>

<section class="ml-5">
    <div class="container choose-staff">
        <h2 class="text-center font-weight-bold text-dark mb-5">Why nursing staff choose carebee?</h2>
        <div class="row">
            <div class="col">
                <img src="{{asset('img/why1.png')}}" width="250" height="200">
                <h5 class="font-weight-bold text-dark mt-3">Offer your own appointment</h5>
                <p class="font-weight-bold">Our service payments are always lower than those of our competitors, averaging at just 9.5%.</p>
            </div>
            <div class="col">
                <img src="{{asset('img/why2.png')}}" width="250" height="190">
                <h5 class="font-weight-bold text-dark mt-4">Only accept requests that make money</h5>
                <p class="font-weight-bold">carebee always shows the total cost of the appointment as well as its destination. Don't like a careseeker's price? Then offer your own right on the carebee!</p>
            </div>
            <div class="col">
                <img src="{{asset('img/why3.png')}}" width="250" height="200">
                <h5 class="font-weight-bold text-dark mt-3">No middlemen </h5>
                <p class="font-weight-bold">Get paid directly by careseeker at the end of their appointment. There's no need to wait for payments anymore.</p>
            </div>

            <div class="col">
                <img src="{{asset('img/why4.png')}}" width="250" height="200">
                <h5 class="font-weight-bold text-dark mt-3">Easy registration </h5>
                <p class="font-weight-bold">Complete a simple online registration and get access to appointment requests that will make you money within a day.</p>
            </div>
        </div>
    </div>
</section>


<section class="ml-5 bg-white">
    <div class="container choose-staff">
        <div class="row m">
            <div class="col-md-7">
                <h2 class="text-center font-weight-bold text-dark show-space">Why we are safe?</h2>
                    <div class="row">
                        <div class="col-md-11 mt-4"><h5 class="home-work">Verified nursing staff</h5></div>
                        <h6 class="mt-2">appointment requests can only be completed by nursing staff whose documents were fully verified online.</h6>
                    </div>

                    <div class="row mt-5">
                        <div class="col-md-11"><h5 class="home-work">Choose your nursing staff</h5></div>
                        <h6 class="mt-2">You are the one who chooses the best offer based on nursing staff` ratings and the numbers of previous rides which they completed.</h6>
                    </div>

                    <div class="row mt-5">
                        <div class="col-md-11"><h5 class="home-work">Secure consult with nursing staff</h5></div>
                        <h6 class="mt-2">The application has a safety button. You can use it to share with your family members and friends the name of your nursing staff, data about the nursing staff, route and current location.</h6>
                    </div>
            </div>
            <div class="col-md-5 mt-4 show-space">
                <img src="{{asset('img/bda_4.png')}}" width="650" height="490">
                
            </div>
        </div>
    </div>
</section>

<section class="blog-one mb-5">
    <div class="container">
        <div class="block-title">
            <div class="blog-heading">
                <p class="has-line">05. Latest Blog</p>
                <h3>Articles about<br> mental health for people </h3>
            </div>
            <button class="thm-btn cta-one__btn">Read all articles</button>
        </div>
        <div class="row">
            <div class="col-lg-4">
                <div class="blog-one__single">
                    <div class="blog-one__image">
                        <img src="{{asset('img/blog1.jpg')}}">
                        <a href="#"><i class="fal fa-plus"></i></a>
                    </div>
                    <div class="blog-one__content">
                       <span>April 02, 2022</span>
                        <h3>06 ways to do workout inside your home during </h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="blog-one__single">
                    <div class="blog-one__image">
                        <img src="{{asset('img/blog2.jpg')}}">
                        <a href="#"><i class="fal fa-plus"></i></a>
                    </div>
                    <div class="blog-one__content">
                       <span>April 02, 2022</span>
                        <h3>How to check blood pressure at home of people</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="blog-one__single">
                    <div class="blog-one__image">
                        <img src="{{asset('img/blog3.jpg')}}">
                        <a href="#"><i class="fal fa-plus"></i></a>
                    </div>
                    <div class="blog-one__content">
                       <span>April 02, 2022</span>
                        <h3>Diet for old people.How to contol food habit.</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

@endsection