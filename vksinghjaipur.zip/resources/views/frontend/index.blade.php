@extends('frontend.layouts.app')

@section('title') {{app_name()}} @endsection

@section('content')
    <section class="slider-one__wrapper">
        <div class="slider-one__nav">
            <a href="#" class="slider-one__nav-left">
                <i class="far fa-angle-left"></i>
            </a>
            <a href="#" class="slider-one__nav-right">
                <i class="far fa-angle-right"></i>
            </a>
        </div>
        <div class="slider-one__carousel owl-carousel owl-theme thm__owl-carousel" data-options='{
            "items": 1, "loop": true, "autoplay": true, "autoplayHoverPause": true, "autoplayTimeout": 5000,
            "margin": 0, "dots": false, "nav": false, "animateOut": &quot;fadeOut&quot;, "animateIn": &quot;fadeIn&quot;, "active": true, "smartSpeed": 1000
        }' data-carousel-next-btn=".slider-one__nav-right" data-carousel-prev-btn=".slider-one__nav-left">

            @if(isset($banners) && !empty($banners))
                @foreach($banners as $banner_data)
                <div class="item" style="background-image: url({{asset('img/banners/'.$banner_data->banner_image)}});">
                    <div class="slider-one__item">
                        <div class="container">
                            <div class="row justify-content-end">
                                <div class="col-lg-12 d-flex justify-content-end">
                                    <div class="slider-one__content">
                                        <div class="slider-one__content-inner">
                                            <h3>{{$banner_data->banner_title}}</h3>
                                            <p>{!! $banner_data->banner_content !!}</p>
                                            <a href="#" class="thm-btn slider-one__btn">Get Appointment</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            @endif    
        </div>
    </section>

    <section class="service-one service-one__home-one">
        <div class="container">
            <div class="block-title">
                <p class="has-line">01. Services</p>
                <h3>Everyone Deserves Our <br> Best Services</h3>
            </div><!-- /.block-title -->
            <div class="service-one__carousel-two thm__owl-carousel owl-carousel owl-theme" data-options='{
                "items": 2, "nav": false, "dots": true, "margin": 40, "loop": true, "smartSpeed": 700, "autoplay": true, "autoplayTimeout": 5000, "autoplayHoverPause": true, "responsive": {
                    "0": {"items": 1, "margin": 0, "dots": false, "nav": true },
                    "767": {"items": 1, "margin": 0, "dots": false, "nav": true },
                    "991": {"items": 2, "margin": 30},
                    "1199": {"items": 4, "margin": 20, "dots": false, "nav": true}
                }
            }'>

            @if(isset($services) && !empty($services))
                @foreach($services as $my_services)
                <div class="item">
                    <div class="service-one__single">
                        <div class="service-one__content">
                            <div class="service-one__icon">
                                <i class="oberlin-icon-stethoscope"></i>
                            </div>
                            <h3><a href="#">{{$my_services->service_name}}</a></h3>
                            <p>{!! $my_services->description !!}</p>
                            <a href="#" class="service-one__link"><i
                                    class="far fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                </div>
                @endforeach
            @endif    
            </div>
        </div>
    </section>


    <section class="cta-one" style="background-image: url(img/blood-pressure-male-patient.jpg);">
        <div class="overlay-box"></div>
        <div class="block-title container text-center">
            <p class="has-line">02.  Appointment</p>
            <h3>Book an Appointment Today!</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing <br>
                elit, sed do eiusmod tempor incididunt.</p>
            <a href="contact.html" class="thm-btn cta-one__btn">Get Appointment</a>
        </div>

    </section>


    <section class="faq-three">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="faq-three__image wow fadeInLeft" data-wow-duration="1500ms">
                        <img src="{{asset('img/faq-2-dot.png')}}" class="faq-three__image-dots">
                        <img src="{{asset('img/doctor.jpg')}}">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="faq-one__block">
                        <div class="block-title text-left">
                            <p class="has-line">03. Why Choose US</p>
                            <h3>Why Most of The People <br>Choose CareBee</h3>
                        </div>

                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing 
                            elit, sed do eiusmod tempor incididunt.</p>
                        <div class="accrodion-grp" data-grp-name="career-one__accrodion">
                            <div class="accrodion active">
                                <div class="accrodion-title">
                                    <h4>Resort Style Living</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                        <p>Lorem Ipsum is simply dummy text of the printing 
                                            and typesetting industry. Lorem Ipsum has been 
                                            the industry's standard dummy text ever since the 
                                            1500s, when an </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4>Safety & Security Guaranty</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                       <p>Lorem Ipsum is simply dummy text of the printing 
                                            and typesetting industry. Lorem Ipsum has been 
                                            the industry's standard dummy text ever since the 
                                            1500s, when an </p>
                                    </div>
                                </div>
                            </div>
                            <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4>24/7 Nursing Staff</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                       <p>Lorem Ipsum is simply dummy text of the printing 
                                            and typesetting industry. Lorem Ipsum has been 
                                            the industry's standard dummy text ever since the 
                                            1500s, when an </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="event-two">
        <div class="container">
            <div class="block-title text-center">
                <p class="has-line">04. Testimonials</p>
                <h3>What Our Clients Say About <br>CareBee?</h3>
            </div>
            <div class="testimonial-owl thm__owl-carousel owl-carousel owl-theme" data-options='{
                "items": 3, "nav": false, "dots": true, "margin": 40, "smartSpeed": 700, "autoplay": true, "autoplayTimeout": 5000, "autoplayHoverPause": true, "responsive": {
                    "0": {"items": 1, "margin": 0, "dots": false, "nav": true },
                    "767": {"items": 1, "margin": 0, "dots": false, "nav": true },
                    "991": {"items": 2, "margin": 30},
                    "1199": {"items": 3, "margin": 40, "dots": false, "nav": false}
                }
            }'>

            @if(isset($my_testi) && !empty($my_testi))
                @foreach($my_testi as $testi_data)
                <div class="item">
                    <div class="testimonial-box">
                        <div class="testimonial-inner-box">
                            <div class="client-img">
                                <img src="{{asset('img/testimonials-image/'.$testi_data->user_image)}}">
                            </div>
                            <div class="rating">
                                @for ($i = 0; $i < $testi_data->star_value; $i++)
                                    <a href="#"><i class="fa fa-star"></i></a>
                                @endfor    
                            </div>
                            <div class="client-detail">
                                <h5>{{$testi_data->user_name}}</h5>
                                <p>{!! $testi_data->description !!} </p>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            @endif    
            </div>
        </div>
    </section>

    <section class="blog-one">
        <div class="container">
            <div class="block-title">
                <div class="blog-heading">
                    <p class="has-line">05. Latest Blog</p>
                    <h3>Articles about<br> mental health for people </h3>
                </div>
                <button class="thm-btn cta-one__btn">Read all articles</button>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="blog-one__single">
                        <div class="blog-one__image">
                            <img src="{{asset('img/blog1.jpg')}}">
                            <a href="#"><i class="fal fa-plus"></i></a>
                        </div>
                        <div class="blog-one__content">
                           <span>April 02, 2022</span>
                            <h3>06 ways to do workout inside your home during </h3>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="blog-one__single">
                        <div class="blog-one__image">
                            <img src="{{asset('img/blog2.jpg')}}">
                            <a href="#"><i class="fal fa-plus"></i></a>
                        </div>
                        <div class="blog-one__content">
                           <span>April 02, 2022</span>
                            <h3>How to check blood pressure at home of people</h3>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="blog-one__single">
                        <div class="blog-one__image">
                            <img src="{{asset('img/blog3.jpg')}}">
                            <a href="#"><i class="fal fa-plus"></i></a>
                        </div>
                        <div class="blog-one__content">
                           <span>April 02, 2022</span>
                            <h3>Diet for old people.How to contol food habit.</h3>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="appointment-one appointment-one__home-one">
        <img src="{{asset('img/appointment-map-1-1.png')}}" class="appointment-one__map-1">
        <img src="{{asset('img/appointment-map-1-2.png')}}" class="appointment-one__map-2">
        <img src="{{asset('img/appointment-person-1-1.png')}}" class="appointment-one__moc">
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-lg-6">
                    <div class="block-title text-left">
                        <p class="has-line">06. Appointment</p>
                        <h3>Want to Hear More About <br> Oberlin Hospice?</h3>
                    </div>
                    <form action="#" class="contact-one__form contact-form-validated">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" placeholder="Full Name" name="name">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Email Address" name="email">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone Number" name="phone">
                            </div>
                            <div class="col-md-6">
                                <select name="discussion" class="selectpicker">
                                    <option value="">Discussion For</option>
                                    <option value="">Basic Query</option>
                                    <option value="">Patient Admission</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <textarea name="message" placeholder="Message"></textarea>
                            </div>
                            <div class="col-md-12 text-left">
                                <button type="submit" class="thm-btn contact-one__btn">Submit Now</button>
                            </div>
                        </div>
                    </form>
                    <div class="result"></div>
                </div>
            </div>
        </div>
    </section>

@endsection