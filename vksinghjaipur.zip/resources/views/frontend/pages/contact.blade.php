@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content') 

<section class="page-header" style="background-image: url(img/bg-05.jpg);">
    <div class="container">
        <h2>Contact Us</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>Contact Us</span></li>
        </ul>
    </div>
</section>

<div class="container">
    <section class="mb-2">
        <h2 class="h1-responsive font-weight-bold text-center my-4 text-info">Contact us</h2>
        <p class="text-center w-responsive mx-auto mb-5">Do you have any questions? Please do not hesitate to contact us directly. Our team will come back to you within
            a matter of hours to help you.</p>

        <div class="row">
            <div class="col-md-8 text-center info-contact">
                <ul class="list-unstyled mb-0">
                    

                    <li><i class="fas fa-map-marker-alt mt-3 fa-2x"></i></i>
                        <p>{!! setting('address') !!}</p>
                    </li>
                    <li><i class="fas fa-phone mt-3 fa-2x"></i>
                        <p>{!! setting('phone') !!}</p>
                    </li>

                    <li><i class="fas fa-envelope mt-3 fa-2x"></i>
                        <p>{!! setting('email') !!}</p>
                    </li>
                </ul>
            </div>

            <div class="col-md-8 mb-md-0 mb-5 contact-form">
                <form id="contact-form" name="contact-form" action="{{ route('contact.send') }}" method="POST">{{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-6">
                            <div class="md-form mb-4">
                                <label for="name" class=""><strong>Your name</strong></label>
                                <input type="text" id="name" name="name" class="form-control" value="{!! isset(Auth::user()->name) && !empty(Auth::user()->name) ? Auth::user()->name : '' !!}">
                                @if ($errors->has('name'))
                                    <span class="text-danger">{{ $errors->first('name') }}</span>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="md-form mb-4">
                                <label for="email" class=""><strong>Your email</strong></label>
                                <input type="text" id="email" name="email" class="form-control" value="{!! isset(Auth::user()->email) && !empty(Auth::user()->email) ? Auth::user()->email : '' !!}">
                                @if ($errors->has('email'))
                                    <span class="text-danger">{{ $errors->first('email') }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="md-form mb-4">
                                <label for="phone" class=""><strong>Phone</strong></label>
                                <input type="text" id="phone" name="phone" class="form-control" value="{!! isset(Auth::user()->phone) && !empty(Auth::user()->phone) ? Auth::user()->phone : '' !!}">
                                @if ($errors->has('phone'))
                                    <span class="text-danger">{{ $errors->first('phone') }}</span>
                                @endif
                            </div>
                        </div>
                    
                        <div class="col-md-6">
                            <div class="md-form mb-4">
                                <label for="subject" class=""><strong>Subject</strong></label>
                                <input type="text" id="subject" name="subject" class="form-control" >
                                @if ($errors->has('subject'))
                                    <span class="text-danger">{{ $errors->first('subject') }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="md-form mb-4">
                                <label for="message"><strong>Your message</strong></label>
                                <textarea type="text" id="message" name="message" rows="4" class="form-control md-textarea">{{ old('message') }}</textarea>
                                @if ($errors->has('message'))
                                    <span class="text-danger">{{ $errors->first('message') }}</span>
                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="form-group contact-submit">
                        <button class="btn btn-success btn-submit">Submit</button>
                    </div>
                </form>
                <div class="status"></div>
            </div>
            
        </div>
    </section>
</div>
@endsection