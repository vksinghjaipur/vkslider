@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4><i class="fa fa-calendar"></i> Transaction History</h4>
         <div class="appointment-seaction">
            <?php $role = Auth::user()->roles()->get(); ?>
            @if ($role[0]['id'] == 2) 
            <div class="row mt-4">
                <div class="col">
                    <div class="trans-table table-responsive">
                        <table id="example1" class="table table-striped table-bordered" style="width:100%;font-size:13px;font-family: arial";>
                            <thead>
                                <tr>
                                    <th>S.n.</th>
                                    <th>Booking id</th>
                                    <th>Txn id</th>
                                    <th>Amount</th>
                                    <th>Cancel Charge</th>
                                    <th>Cancel Amount</th>
                                    <th>Payment Date</th>
                                    <th>Payment Status</th>
                                    <th>Earning</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if ($NursingTransaction->count() == 0)
                                    <tr>
                                        <td colspan="10" style="text-align:center; font-weight: bold; color:red; font-size:18px; margin-top: 50px;">No transaction data found.</td>
                                    </tr>
                                @endif

                                <?php $total_point= 0; ?> 

                                @if(isset($NursingTransaction) && !empty($NursingTransaction))
                                    @foreach($NursingTransaction as $nursing_data)
                                        <tr>
                                            <td> {{$no++}} </td>
                                            <td> CAREBEE#{{$nursing_data->booking_id}} </td>
                                            <td> {{$nursing_data->txn_id}}</td>
                                            <td> {{$nursing_data->total_amount}}</td>
                                            <td> 
                                                @if($nursing_data->cancellation_charge=='')

                                                @else 
                                                    {{$nursing_data->cancellation_charge}} %
                                                @endif    
                                            </td>
                                            <td> {{$nursing_data->cancellation_amount}} </td>
                                            <td> {{ date('d-m-Y', strtotime($nursing_data->created_at)) }}</td> 
                                            <td>
                                                @if($nursing_data->payment_status==1)
                                                    success
                                                @elseif($nursing_data->payment_status==0)
                                                    cancel
                                                @endif 
                                            </td>
                                            <td> {{$nursing_data->commission_amount}} </td>
                                        </tr>
                                        <?php   
                                            $total_point = $total_point + ($nursing_data->commission_amount); 
                                        ?>
                                    @endforeach
                                @endif
                            </tbody>    
                        </table>
                        <div class="font-weight-bold text-right mr-5"><span class="text-success">Total Income:- </span> <i class="fa-solid fa-rupee-sign" style="color:#23CFCF;"></i> {{$total_point}} </div>
                    </div>
                </div>
            </div> 
            @else
            <div class="row mt-4">
                <div class="col">
                    <div class="table-responsive">
                        <table id="example3" class="table table-striped table-bordered" style="width:100%;font-size:13px;font-family: arial";>
                             <thead>
                                <tr>
                                    <th>Booking id</th>
                                    <th>Transaction id</th>
                                    <th>Amount</th>
                                    <th>Payment date</th>
                                    <th>Payment status</th>
                                    <th>Booking Status</th>
                                    <th>Cancellation Charge</th>
                                    <th>Diduct amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if ($transactionData->count() == 0)
                                    <tr>
                                        <td colspan="10" style="text-align:center; font-weight: bold; color:red; font-size:18px; margin-top: 50px;">No transaction  found.</td>
                                     </tr>
                                @endif
                                @if(isset($transactionData) && !empty($transactionData))
                                    @foreach($transactionData as $trans_data)
                                        <tr>
                                            <td>CAREBEE#{{$trans_data->booking_id}}</td>
                                            <td>{{$trans_data->txn_id}}</td>
                                            <td>{{$trans_data->total_amount}}</td>
                                            <td>{{ date('d-m-Y', strtotime($trans_data->created_at)) }}</td> 
                                            <td>
                                               @if($trans_data->payment_status==0)
                                                    <p class="text-danger">Cancled</p>
                                                @elseif($trans_data->payment_status==1)
                                                    <p class="text-success">Success</p>
                                                @endif  
                                            </td>
                                            <td>{{$trans_data->status}}</td>
                                            <td>{{$trans_data->cancellation_charge}}</td>
                                            <td>
                                                @if($trans_data->cancellation_amount==0.00)
                                                    0 INR
                                                @else    
                                                    {{$trans_data->cancellation_amount}} INR
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif  
                            </tbody>    
                        </table>
                    </div>
                </div>
            </div>
            @endif 
        </div>
    </div>
</div>
@endsection
