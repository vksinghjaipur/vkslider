@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')

<section class="page-header" style="background-image: url(img/bg-10.jpg);">
    <div class="container">
        <h2>Nursing Staff Detail</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>Nursing Staff Detail</span></li>
        </ul>
    </div>
</section>
<style type="text/css">
    .razorpay-payment-button{
        display: none;
    }
</style>


<section class="doctor-detail-info">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="doctor-profile">
                    @if(!empty($DocDetail->avatar) && file_exists(public_path('/img/avatars/'.$DocDetail->avatar)))
                        <img src="{{asset('img/avatars/'.$DocDetail->avatar)}}">
                    @else
                        <img src="{{asset('img/avatars/default-user-profile.png')}}"/>
                    @endif 
                </div>
            </div>
            <div class="col-md-7">
                <div class="doctor-information">
                    <h5 class="text-danger">{{$DocDetail->specializations}}s</h5>
                    <h2>{!! ucfirst($DocDetail->name) !!}</h2>
                    <h6><i class="fas fa-map-marked-alt"></i> {{$DocDetail->address}}</h6>
                    <p><span>Please Select Services: </span> 
                        <table id="example" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Select Service</th>
                                    <th>Service Name</th>
                                    <th>Service Price</th>
                                </tr>
                            </thead> 
                            <tbody>
                                <?php
                                    $ser_name = explode(',', $DocDetail->service_id);
                                    $servicename=array();
                                    foreach($ser_name as $key=>$value){
                                    $selected = DB::table('services')
                                        ->where('id',$value) 
                                        ->first();
                                    $result['service_name']= isset($selected->service_name)?$selected->service_name:'';
                                    $result['price']= isset($selected->price)?$selected->price:'';
                                    $result['id']= isset($selected->id)?$selected->id:'';
                                        array_push($servicename,$result);
                                    }
                                ?>
                            </tbody>    
                            <form name=form1 method=post>
                                @foreach($servicename as $serce)
                                    <tr >
                                        <td><input type=checkbox name=ckb class="serviceid" data-id="{{$serce['id']}}" value="{{$serce['price']}}" onclick='chkcontrol(0)';></td>
                                        <td>{{$serce['service_name']}}</td>
                                        <td>{{$serce['price']}}</td>
                                    </tr>
                                @endforeach
                            </form>
                        </table>
                    </p>
                    <div class="form-group">
                        <span id=msg></span>
                    </div>    
                </div>
            </div>
        </div>
        <div class="doctor-about-info">
        <div id="bookingError"></div><br>
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#information">Information</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#booking">Booking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#feedback">Feedback</a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade" id="information">
                    <div class="information">
                        <div class="about-description">
                            <h3>About Me</h3>
                            <p>{{$DocDetail->bio}}</p>
                        </div>
                        <div class="about-description">
                            <h3>Profile Info</h3>
                            <ul>
                                <li><span class="text-danger">Practicing :-</span> {{$DocDetail->practicing}}</li>
                                <li><span class="text-danger">Experience :-</span> {{$DocDetail->experience}} Years</li>
                                <li><span class="text-danger">License Number:-</span> {{$DocDetail->license_number}}</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="tab-pane active" id="booking">
                    <!-- @include('auth.social_login_buttons') -->
                        @include('flash::message')

                        @if ($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <p>
                                <i class="fas fa-exclamation-triangle"></i> @lang('Please fix the following errors & try again!')
                            </p>
                            <ul>
                                @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        @endif
                        <div class="row">
                            <div class="col-md-6">
                                <div class="booking-list">
                                    <h3>Available On    
                                        <?php  echo date('F Y');  ?> <!--- show for current month & year --->
                                    </h3>
                                    <ul>
                                        <?php
                                            $todayDay = \Carbon\Carbon::now();
                                            $date = date('Y-m-d',strtotime('-1 day'));
                                            // print_r($todayDay); die();
                                            for($i =1; $i <= 7; $i++)
                                            {
                                                $date = date('Y-m-d', strtotime('+1 day', strtotime($date)));?>
                                                <li class="slotgetday" data-day="{{date('D',strtotime($date))}}" data-doctorid="{{$doctor_id}}" data-date="{{date('D',strtotime($date))}}, {{date('d M',strtotime($date))}}, {{date('Y',strtotime($date))}}">
                                                    <input type="radio" name="slotno">
                                                    <span>{{date('D',strtotime($date))}}, {{date('d M',strtotime($date))}}, {{date('Y',strtotime($date))}}</span>
                                                </li>
                                                <?php 
                                            }
                                        ?>
                                    </ul>
                                    <h3 class="random-date">Availability On <small class="text-danger font-weight-bold">( * please select any date )</small> </h3>
                                    <div>
                                        <ul>
                                            <li style="font-weight:600; color:#090a0a;"><button type="button" class="btn btn-danger btn-circle btn-lg"></button> Booked slots</li>
                                            <li style="font-weight:600; color: #090a0a;"><button type="button" class="btn btn-secondary btn-circle btn-lg"></button> Available slots</li>
                                        </ul>
                                    </div>  
                                    <div class="slot-available">No booking time available
                                    </div>
                                </div>
                            </div>

                            @if(empty(Auth::check()))
                                <div class="col-md-6">
                                    <form role="form" method="POST" action="{{ route('login') }}">
                                    @csrf
                                        <div class="login-box">
                                            <div class="form-group">
                                                <div class="col-md-12">
                                                    <input type="text" class="form-control" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="input-email" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-md-12">
                                                    <input type="password" class="form-control" id="password" name="password" placeholder="@lang('Password')" aria-label="@lang('Password')" aria-describedby="input-password" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-md-12">
                                                    <button type="submit" class="btn submit-btn">
                                                    @lang('Log In')
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="form-group row m-0">
                                                <div class="col-md-6">
                                                    <label><input type="checkbox"> Remember Me</label>
                                                </div>
                                                <div class="col-md-6 text-right">
                                                    <a href="#">Create New account?</a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            @else
                                <div class="col-md-6">
                                    <div class="booking-info text-info">Booking Information</div><hr>
                                    
                                     <form class="needs-validation" novalidate method="POST" action="{{route('users.booking')}}" accept-charset="UTF-8" class="form-horizontal" role="form" id="regForm" name="mainForm" enctype="multipart/form-data"> {{csrf_field()}}    
                                        <div class="error-message"></div>
                                        <input type="hidden" name="doctor_id" value="{{$doctor_id}}">
                                        <input type="hidden" class="servicess" name="service_id" value="">
                                        <input type="hidden" class="bookingclass" name="booking_date" value="">
                                        <input type="hidden" class="bookingtimeclass" name="booking_time" value="">
                                        <input type="hidden" name="booking_day" value="">
                                        <input type="hidden" class="servicesamount" name="total_amount" id="getserviceamount">
                                        <input type="hidden" class="razorpayid" name="razorpay_payment_id" id="">
                                        <input type="hidden" name="lat" value="">
                                        <input type="hidden" name="lng" value="">

                                        <div class="form-row">
                                            <div class="col-md-6 mb-3">
                                                <label for="validationCustom01">Patient name</label>
                                                    <input type="text" class="form-control" id="validationCustom01" placeholder="Enter Name" name="patient_name" value="{!! isset(Auth::user()->username) && !empty(Auth::user()->username) ? Auth::user()->username : '' !!}" required>
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                    <div class="invalid-feedback">
                                                        Please enter your name.
                                                    </div>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="validationCustom02">Patient Email</label>
                                                    <input type="text" class="form-control" id="validationCustom02" placeholder="Patient Email" name="email" value="{!! isset(Auth::user()->email) && !empty(Auth::user()->email) ? Auth::user()->email : '' !!}" required>
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                                    <div class="invalid-feedback">
                                                        Please enter your email.
                                                    </div>
                                            </div>   
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label for="validationCustom03">Contact Num</label>
                                                    <input type="number" name="contact_num" class="form-control" id="validationCustom03" placeholder="Contact Number" value="{!! isset(Auth::user()->mobile) && !empty(Auth::user()->mobile) ? Auth::user()->mobile : '' !!}" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" maxlength="13" required>
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="validationCustom04">House Number</label>
                                                    <input type="text" class="form-control" id="validationCustom04" placeholder="House Number" name="house_num" value="" required>
                                                    <div class="valid-feedback">
                                                        Looks good!
                                                    </div>
                                            </div>    
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="validationCustom05">Address street 1</label>
                                            <input type="text" name="address" class="form-control" id="validationCustom05" placeholder="Enter Address" value="{!! isset(Auth::user()->address) && !empty(Auth::user()->address) ? Auth::user()->address : '' !!}" required>
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                        </div>
                                        <div class="form-group">
                                        <label for="validationCustom06">Address 2 <span class="text-danger">( landmark )</span></label>
                                            <input type="text" name="landmark" class="form-control" id="validationCustom06" placeholder="Enter Address" value="" required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                        </div>  
                                        <div class="form-group">
                                        <label for="inputAddress">Request Message</label>
                                            <textarea name="message" id="your-message" rows="5" class="form-control" placeholder="Message" required=""></textarea>
                                        </div>
                                        <div class="button-wrap">
                                            @if(isset(Auth::User()->id))
                                                @if(Auth::User()->user_type == 2)

                                                @else
                                                    <button type="button" class="btn login-btn booking_app" id="paybtn">Book Appointment <i class="fas fa-spinner fa-spin d-none"></i></button>
                                                @endif 
                                            @endif  
                                        </div>
                                    </form>
                                    <!---- Script for validation in nursing detail form ---->
                                   <!--  <div id='loader' style='display: block;'>
                                        <img src="{{url('img/loader.gif')}}" width='200px' height='200px'>
                                    </div> -->

                                </div>
                            @endif
                        </div>
                </div>
                <!--- user feedback blok --->
                <div class="tab-pane fade" id="feedback">
                    @if(empty(Auth::check()))
                    <div class="review-feedback">
                        <h3>Login To Leave Review</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <form role="form" method="POST" action="{{ route('login') }}">@csrf
                                <div class="login-box">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <input type="text" class="form-control" id="email" name="email" value="{{ old('email') }}" placeholder="{{ __('E-Mail Address') }}" aria-label="email" aria-describedby="input-email" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <input type="password" class="form-control" id="password" name="password" placeholder="@lang('Password')" aria-label="@lang('Password')" aria-describedby="input-password" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn login-btn">Login</button>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <label><input type="checkbox"> Remember Me</label>
                                        </div>
                                        <div class="col-md-6 text-right">
                                            <a href="#">Create New account?</a>
                                        </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    @else
                        <div class="review-feedback">
                            <h3>Leave your feedback</h3>
                            <div class="row">
                                <div class="col-md-12">
                               <form method="POST" action="{{url('add-feedback')}}" accept-charset="UTF-8" enctype="multipart/form-data"> {{csrf_field()}}
                                <input type="hidden" name="doctor_id" id="doctor_id" value="{{$doctor_id}}">
                                    <div class="login-box">
                                        <div class="form-group row">
                                                <label class="ml-3">Ratings</label>
                                            <div class="col-md-12">
                                                <div class="rate">
                                                    <input type="radio" id="star5" class="rate" name="ratings" value="5"/>
                                                    <label for="star5" title="text">5 stars</label>
                                                    <input type="radio" checked id="star4" class="rate" name="ratings" value="4"/>
                                                    <label for="star4" title="text">4 stars</label>
                                                    <input type="radio" id="star3" class="rate" name="ratings" value="3"/>
                                                    <label for="star3" title="text">3 stars</label>
                                                    <input type="radio" id="star2" class="rate" name="ratings" value="2">
                                                    <label for="star2" title="text">2 stars</label>
                                                    <input type="radio" id="star1" class="rate" name="ratings" value="1"/>
                                                    <label for="star1" title="text">1 star</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <label>Message</label>
                                                <textarea style="margin-top:5px; height: 100%;" class="form-control" rows="6" name="feedback" id="comment-1" placeholder="Please give your review here.." required=""></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-2">
                                                <button type="submit" class="btn-small btn login-btn" id="appointment_ratings"><i class="fas fa-spinner fa-spin d-none"></i> Submit </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- <div class="review-feedback">
                        <h3>Users feedback</h3>
                            <div class="row">
                                <div class="col-md-12">
                                    @if(isset($show_feedbacks) && !empty($show_feedbacks))
                                        @foreach($show_feedbacks as $feedback_data)
                                            <div class="login-box">
                                                <div class="testimonial-inner-box">
                                                    <div class="rating">
                                                        <h5>{{ucfirst($feedback_data->username)}}</h5>
                                                        @for ($i = 0; $i < $feedback_data->ratings; $i++)
                                                            <a href="#"><i class="fa fa-star"></i></a>
                                                        @endfor    
                                                        <p>{{ $feedback_data->feedback }} </p>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif        
                                </div>
                            </div>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</section>
 <div id='loader' style='display: none;'>
    <img src="{{url('img/loader.gif')}}" width='200px' height='200px'>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).on("click",'.slotgetday', function()
    {
        var doct=  $(this).data('doctorid');
        var day=   $(this).data('day');
        var randate=   $(this).data('date');
        $('.bookingclass').val(randate);
        $('.random-date').html('Availability On '+ randate);
        $.ajax({
            url:"{{url('availableSlotes')}}",
            type:'get',
            data:{'day':day,'id':doct,'date':randate},
            success:function(result)
            {
                if(result!='')
                {
                    $('.slot-available').html(' ');
                    $('.slot-available').html(result); 
                }
                else
                {
                     $('.slot-available').html('No booking time available');
                }
                    
            }
        });
    });

    $(document).on("click",'.bookingTimetget', function()
    {
        var time=  $(this).data('time');
        $('.bookingtimeclass').val(time);
    });
</script>
  <script src="https://checkout.razorpay.com/v1/checkout.js">
                                        </script>
<!----- code for get service selection and sum ----->
<script type="text/javascript">

function chkcontrol(j) {
var sum=0;
for(var i=0; i < document.form1.ckb.length; i++){

if(document.form1.ckb[i].checked){
sum = sum + parseInt(document.form1.ckb[i].value);
}
document.getElementById("msg").innerHTML="Total :"+ sum;
$('.servicesamount').val(sum);
}

}
    $('.serviceid').on('click', function() {
        var array = [];
        $("input:checkbox[name=ckb]:checked").each(function() {
            array.push($(this).attr('data-id'));
        });
        $('.servicess').val(array);
    });


    $('.booking_app').on('click', function() {
    
        var services= $('.servicess').val();
        var time= $('.bookingtimeclass').val();
        var date= $('.bookingclass').val();
        var service='Please check services before submit.';
        var dates='Please check date before submit.';
        var times='Please check time before submit.';
        $('#bookingError').html('');
        $(".error-v").remove();
        if(services=='')
        {
            $('#bookingError').append('<span class="error-v">Please check services before submit</span>');
          //alert('ggg');
            //return false;
        }
        if(date=='')
        {
             $('#bookingError').append('<span class="error-v">Please check date before submit.</span>');
             //$('#bookingError').html(dates +''+times );
             //return false;
        }
        if(time=='')
        {
              $('#bookingError').append('<span class="error-v">Please check time before submit.</span>');
              //$('#bookingError').html(times);
             //return false;
        }
        

        if(services!='' && date!='' && time!='')
        {     
            $('.booking_app').attr('type', 'submit');
           

           // $('form#regForm').submit();
            $('#regForm').validate({
                    rules: {
                      message: {
                        required: true,
                      }
                    },
                      submitHandler: function (form) {
                          var amount= $('#getserviceamount').val();
                            var options = {
                                key: "{{env('RAZOR_KEY')}}",
                                amount: amount*100,
                                description: 'fees',
                                handler: function (response){
                                var razorpayid=response.razorpay_payment_id;
                                //alert(razorpayid);                              
                                $('.razorpayid').val(razorpayid);
                                    demoSuccessHandler();

                                }
                            }
                       window.r = new Razorpay(options);
                        document.getElementById('paybtn').onclick = function () {
                        r.open()
                        $('.booking_app').attr('type', 'button');
                        }
                       // $('form#regForm').submit();}
                   }

                  });
        }
    });
</script>
<script>
    var amount= $('#getserviceamount').val();
    var options = {
        key: "{{env('RAZOR_KEY')}}",
        amount: amount*100,
        description: 'Appointment Fees',
        handler: function (response){
        var razorpayid=response.razorpay_payment_id;
        //alert(razorpayid);                              
        $('.razorpayid').val(razorpayid);
            demoSuccessHandler();

        }
    }
    function rozarpay()
    {
        window.r = new Razorpay(options);
        document.getElementById('paybtn').onclick = function () {
        r.open()
        }
    }

function demoSuccessHandler(transaction) {
    $.ajax({
    type: "POST",
    url: "{{route('users.booking')}}",
    data: $('#regForm').serialize(),
    beforeSend: function(){
    /* Show image container */
    $("#loader").show();
   },
    success: function(msg) {
    if(msg=='success')
        {
            toastr.success('appointment payment successfully');
            window.location.reload();
            $("#loader").hide();
            //alert(msg);
        }
    else
        {
            toastr.error('appointment payment failed');
            window.location.reload();
            $("#loader").hide();
            //alert(msg);
        }
    }      
    });        
}
</script>

@endsection
