@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
            <div class="notification-heading">
                <div class="heading-left">
                    <h4>
                        <i class="far fa-bell fa-fw"></i> {{ $module_title }}
                        (@lang(":count unread", ['count'=>$unread_notifications_count]))
                        <small class="text-muted size14">@lang(":module_name Management Dashboard", ['module_name'=>Str::title($module_name)])</small>
                    </h4>
                </div>
                <!--/.col-->
                <div class="mark-all">
                    <a href="{{ url("markAsRead") }}" class="btn btn-success" data-toggle="tooltip" title="@lang('Mark All As Read')"><i class="fas fa-check-square"></i> @lang('Mark All As Read')</a>
                    <a href="{{url("deletenote")}}" class="btn btn-danger" data-method="DELETE" data-token="{{csrf_token()}}" data-toggle="tooltip" title="@lang('Delete All Notifications')"><i class="fas fa-trash-alt"></i></a>
                </div>
            </div>

                <div class="row mt-4">
                    <div class="col">
                        <table id="datatable" class="table table-bordered table-hover table-responsive-sm">
                            <thead>
                                <tr>
                                    <th>
                                        @lang('Text')
                                    </th>
                                    <th>
                                        @lang('Module')
                                    </th>
                                    <th>
                                        @lang('Updated At')
                                    </th>
                                    <th class="text-right">
                                        @lang('Action')
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach($$module_name as $module_name_singular)
                                <?php
                                $row_class = '';
                                $span_class = '';
                                if ($module_name_singular->read_at == ''){
                                    $row_class = 'table-info';
                                    $span_class = 'font-weight-bold';
                                }
                                ?>
                                <tr class="{{$row_class}}">
                                    <td>
                                        <a href="{{ url("showNote", $module_name_singular->id) }}">
                                            <span class="{{$span_class}}">
                                                {{ $module_name_singular->data['title'] }}
                                            </span>
                                        </a>
                                    </td>
                                    <td>
                                        {{ $module_name_singular->data['module'] }}
                                    </td>
                                    <td>
                                        {{ $module_name_singular->updated_at->diffForHumans() }}
                                    </td>
                                    <td class="text-right">
                                        <a href='{!!url("showNote", $module_name_singular)!!}' class='btn btn-sm btn-success mt-1' data-toggle="tooltip" title="@lang('Show') {{ ucwords(Str::singular($module_name)) }}"><i class="fas fa-tv"></i></a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            
                <div class="row">
                    <div class="col-7">
                        <div class="float-left">
                            @lang('Total') {{ $$module_name->total() }} {{ ucwords($module_name) }}
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="float-right">
                            {!! $$module_name->render() !!}
                        </div>
                    </div>
                </div>
                </div>
        </div>


@endsection
