@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')  
<section class="page-header" style="background-image: url(img/doctor-bg.jpg);">
    <div class="container">
        <h2>Blogs</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>Blogs</span></li>
        </ul>
    </div>
</section>

<div class="blog_container">
	<div class="container">
		<div class="row">
			<div class="col-md-8 blog-section">
				<div class="blog_content">
					<div class="left_content">
						@if(!empty($blogs))
							@foreach($blogs as $blog)
								<div class="blog_card">
									<a href="#" class="figure">
										@if(!empty($blog->featured_image))
											<img src="{{asset('img/blog-image/'.$blog->featured_image)}}" alt="" loading="lazy">
											<span class="tag"> 
												<?php echo $blog->publish_datetime->format('d M');	?></span>
										 @else
										 	<img src="{{asset('img/blog-image/dummy.png')}}" alt="" loading="lazy">
											<span class="tag">
												<?php echo $blog->publish_datetime->format('d M');	?></span>
										 @endif		
									</a>
									<section>
										<a href="{{url('blog-detail/'.$blog->slug)}}" class="title">{{$blog->name}}</a>
											<p>{!! Str::limit($blog->content, 180) !!}</p>
											<div class="row">
												<div class="col-md-3"><i class="fa fa-user"></i> {{$blog->username}}</div>
												<div class="col-md-4"><i class="fa fa-clock"></i> {{$blog->created_at->diffForHumans()}} </div>
												<div class="col-md-2"><i class="fa fa-comment"></i> {{$blog->comments_count}}</div>
												<div class="col-md-2"><i class="fa fa-eye"></i> {{$blog->view_count}}</div>
											</div>	
									</section>
								</div>
							@endforeach	
							@else
			                    No Blog data found!
			            @endif
					</div>
					{!! $blogs->links('vendor.pagination.custom') !!}
				</div>
			</div>
			<div class="col-md-4">
				<div class="right_content">
					@include('frontend.pages.blog-sidebar')
				</div>
			</div>
	  </div>
	</div>
</div>
@endsection
