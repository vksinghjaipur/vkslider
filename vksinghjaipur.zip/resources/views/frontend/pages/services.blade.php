@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
<section class="page-header" style="background-image: url(img/page-header-service-1.jpg);">
    <div class="container">
        <h2>Services</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>Services</span></li>
        </ul>
    </div>
</section>

<section class="service-one service-one__service-page service-grid-box">
    <div class="container">
        <div class="block-title text-center">
            <p>01. Services</p>
            <h3>Everyone Deserves Our <br> Best Services</h3>
        </div>
        <div class="row high-gutter">
            @if(isset($get_services) && !empty($get_services))
                @foreach($get_services as $services)
                    <div class="col-lg-4 col-md-6">
                        <div class="service-one__single">
                            <div class="service-one__image service-single">
                                @if(!empty($services->service_image))
                                    <td><img src="{{asset('img/service-icon/'.$services->service_image)}}" /></td>
                                @else
                                    <td><img src="{{asset('img/service-icon/defualt-icon.png')}}"/></td>
                                @endif
                            </div>
                            <div class="service-one__content">
                                <div class="service-one__icon">
                                    <i class="oberlin-icon-stethoscope"></i>
                                </div>
                                <h3><a href="#">{{$services->service_name}}</a></h3>
                                <p>{!! $services->description !!} </p>
                                <a href="#" class="service-one__link"><i class="far fa-long-arrow-alt-right"></i></a>
                            </div>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>
</section>

<section class="cta-two">
    <img src="img/cta-1-1-shape-1.png" class="cta-two__dot-1">
    <img src="img/cta-1-1-shape-2.png" class="cta-two__dot-2">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-lg-6 d-flex justify-content-center align-items-center">
                <div class="cta-two__image">
                    <img src="img/cta-1-1.jpg">
                    <div class="cta-two__image-inner">
                        <div class="cta-two__image-content">
                            <h3><span class="counterno">78</span> %</h3>
                            <p>Success Rate</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="cta-two__content">
                    <h3>Book an <br> Appointment Today!</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                        incididunt labore dolore magna aliqua enim ad minim veniam. </p>
                    <a href="#" class="thm-btn cta-two__btn">Get Appointment</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="career-one service-collapse">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="career-one__block">
                    <div class="block-title">
                        <p class="has-line">02. FAQ</p>
                        <h3>Freequently Asked <br> Questions</h3>
                    </div>
                    <p class="text-justify">Let's talk about EHR software for hospitals today and revel answers to essential questions that might come in mind while selecting a HIS. These systems are designed to hold all hospital management tasks. Help to improve the quality of healthcare and operational efficiency for you. Work as a complete solution for hospital inventory management, patient relationship management, human resources, finance, and billing.</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="career-one__content">
                    <div class="accrodion-grp" data-grp-name="career-one__accrodion">
                        @foreach($get_faqs as $key=>$myfaqs)
                        <div class="accrodion active_{{ $key }}">
                            <div class="accrodion-title">
                                <h4>{{ $myfaqs->question }}</h4>
                            </div>
                            <div class="accrodion-content">
                                <div class="inner">
                                   <p>{!! $myfaqs->answer !!}</p>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
