<div class="columns search_column">
			<section class="search">
				<form>
					<fieldset>
						<input type="text" name="search" placeholder="Search..." maxlength="100" required="">
						<button type="submit" class="btn1"><i class="fa fa-search"></i></button>
					</fieldset>
				</form>
			</section>
		</div>
		<!-- <div class="columns books">
			<span class="title">New Books <a href="#" title="Explore More"><i class="fa fa-share"></i></a></span>
				<section>
					<div class="cards">
						<div class="card_part card_part-one" style="background-image: url(https://i.postimg.cc/2SD5y5RS/book-1.png);"></div>
						<div class="card_part card_part-two" style="background-image: url(https://i.postimg.cc/2SD5y5RS/book-1.png);"></div>
						<div class="card_part card_part-three" style="background-image: url(https://i.postimg.cc/2SD5y5RS/book-1.png);"></div>
						<div class="card_part card_part-four" style="background-image: url(https://i.postimg.cc/2SD5y5RS/book-1.png);"></div>
					</div>
				</section>
		</div> -->
		<div class="columns posts">
			<span class="title">Recent Posts <a href="#" title="Explore More"><i class="fa fa-share"></i></a></span>
				<section>
					@foreach ($popularblogs as $myblog)
						<a href="{{url('blog-detail/'.$myblog->slug)}}">
							@if(!empty($myblog->featured_image))
								<img src="{{asset('img/blog-image/'.$myblog->featured_image)}}" alt="" loading="lazy">
							 @else
							 	<img src="{{asset('img/blog-image/dummy.png')}}" alt="" loading="lazy">
							 @endif	 
							<p>{!! Str::limit($myblog->content, 40) !!}</p></a>
					@endforeach
				</section>
		</div>
		<div class="columns comments">
			<span class="title"> Recent Comments <a href="#" title="Explore More"><i class="fa fa-share"></i></a></span>
			<section>
				<marquee direction="up" scrollamount="4" onMouseOver="this.stop()" onMouseOut="this.start()" class="marquee2">
					@foreach ($popularblogs as $myblog)
						<p>{!! $myblog->name !!}</p>
					@endforeach	 
				</marquee>
			</section>
		</div>
		<div class="columns social_icons">
			<a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a>
			<a href="#" title="LinkedIn"><i class="fab fa-linkedin-in fa-fw"></i></a>
			<a href="#" title="Instagram"><i class="fab fa-instagram fa-fw"></i></a>
			<a href="#" title="Whatsapp"><i class="fab fa-whatsapp fa-fw"></i></a>
			<a href="#" title="Telegram"><i class="fab fa-telegram fa-fw"></i></a>
		</div>