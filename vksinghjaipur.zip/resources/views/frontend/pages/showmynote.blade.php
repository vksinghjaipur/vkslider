@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-8">
                        <h4 class="card-title mb-0">
                            <i class="{{ $module_icon }}"></i> {{ $module_title }}
                        </h4>
                        
                    </div>
                    <div class="col-4">
                        <div class="float-right">
                            <a href="{{ url("notifications") }}" class="btn btn-secondary mt-1 btn-sm" data-toggle="tooltip" title="{{ __(ucwords($module_name)) }} List"><i class="fas fa-list"></i> List</a>
                        </div>
                    </div>
                </div>
                <hr>

                <div class="row mt-4">
                    <div class="col">
                        <div class="table-responsive">
                            <div class="card">
                                <div class="header bg-indigo">
                                    <h2><?php $data = json_decode($$module_name_singular->data); ?></h2>
                                </div>
                                <div class="header ml-2 mt-2">
                                    <h6 class="font-weight-bold text-success">
                                        {{ $data->title }}
                                    </h6>
                                </div>
                                <div class="body ml-2 mt-2">
                                   {!! $data->text !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col">
                        <small class="float-right text-muted">
                            Updated: {{$$module_name_singular->updated_at->diffForHumans()}},
                            Created at: {{$$module_name_singular->created_at->isoFormat('LLLL')}}
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>        

@endsection
