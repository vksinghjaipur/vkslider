@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4>Subscription Plans</h4>
                <div class="row">
                    @if(isset($plan_data) && !empty($plan_data))
                        @foreach($plan_data as $showplan_data)
                            <div class="col-md-4">
                                <form method="POST" action="{{url('add-subscription-plans')}}" id="msform">   {{csrf_field()}}
                                <div class="columns">
                                    <input type="hidden" name="user_id" value="" />
                                    <input type="hidden" name="subscription_plan_id" value="{{isset($showplan_data->id)?$showplan_data->id:'' }}" />
                                    <?php  $todaydate= date('Y-m-d H:i:s');   ?>
                                    <input type="hidden" name="start_date" value="{{$todaydate}}" />
                                    <?php  
                                        $days= $showplan_data->plan_duration;
                                        //date('Y-m-d', strtotime($todaydate. ' + ' .$days .'days'));
                                        $end_date= date('Y-m-d H:i:s', strtotime($todaydate. ' + ' .$days .'days'));
                                    ?>
                                    <input type="hidden" name="end_date" value="{{$end_date}}" />
                                    <ul class="price">
                                    @if($showplan_data->plan_price > 0 )    
                                        <li class="header">{{$showplan_data->plan_title}}</li>
                                    @else
                                        <li class="header">{{$showplan_data->plan_title}}</li>
                                    @endif    
                                        <h3>INR {{$showplan_data->plan_price}} / {{$showplan_data->plan_duration}} Days</h3>

                                        <?php
                                            $stname = explode(',', $showplan_data->service_id);
                                                $servicename=array();
                                                foreach($stname as $key=>$value){
                                                    $selected = DB::table('services')
                                                    ->where('id',$value) 
                                                    ->first();
                                                    $result= isset($selected->service_name)?$selected->service_name:'';
                                                    array_push($servicename,$result);
                                                }
                                        ?>
                                        <h5>{{implode(', ', $servicename)}}</h5>
                                        <li>{!! $showplan_data->plan_description !!}</li>
                                        <li class="grey">
                                            @if($showplan_data->plan_price > 0 )
                                                <button type="submit" class="btn btn-success start-btn">Buy Plan</button>
                                            @else
                                                <button type="submit" class="btn btn-info start-btn">Free Trail</button> 
                                            @endif      
                                        </li>
                                    </ul>
                                </div>
                                </form> 
                            </div>
                        @endforeach
                    @endif  
                </div>
                 
    </div>
</div>
@endsection
