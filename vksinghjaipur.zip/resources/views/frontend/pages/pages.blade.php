@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')

<section class="page-header" style="background-image: url(../img/page-header-about-1.jpg);">
    <div class="container">
        <h2>{{$page->title}}</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>{{$page->title}}</span></li>
        </ul>
    </div>
</section>

<section class="about-one about-bg">
    <div class="container">
        <div class="row">
            <div class="my-auto">
                <div class="about-one__content">
                    <div class="block-title text-left">
                        <p class="has-line">01. {{$page->title}}</p>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active animated fadeInUp" id="approach">
                            <p>{!!$page->description!!}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
