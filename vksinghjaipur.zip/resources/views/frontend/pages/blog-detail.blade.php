@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')

<section class="page-header" style="background-image: url(img/doctor-bg.jpg);">
    <div class="container">
        <h2>Blog Detail</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>Blog Detail</span></li>
        </ul>
    </div>
</section>

<div class="blog_container">
    <div class="container">
        <div class="row">
          <div class="col-md-8">
        	<div class="blog_content">
        		<div class="left_content">
        			<div class="blog_card">
        				<a href="#" class="figure">
        					@if(!empty($blog->featured_image))
        						<img src="{{asset('img/blog-image/'.$blog->featured_image)}}" alt="" loading="lazy">
        					 @else
        					 	<img src="{{asset('img/blog-image/dummy.png')}}" alt="" loading="lazy">
        					 @endif		
        				</a>
        				<section>	
        					<a href="#" class="title">{{$blog->name}}</a>
        						<p>{!! $blog->content !!}</p>
        						<div class="row">
        							<div class="col-md-3"><i class="fa fa-user"></i> {{$blog->username}}</div>
        							<div class="col-md-4"><i class="fa fa-clock"></i> {{$blog->created_at->diffForHumans()}} </div>
        							<div class="col-md-2"><i class="fa fa-comment"></i> {{$blog->comments_count}}</div>
        							<div class="col-md-2"><i class="fa fa-eye"></i> {{$blog->view_count}}</div>
        						</div>	
        				</section>
        			</div>
        		</div>
        		<div class="card mt-4" id="comments">
                    <div class="p-15 grey lighten-4">
                        <h5 class="m-0">{{ $blog->comments_count }} Comments</h5>
                    </div>	
                    <div class="single-narebay p-15">
                    	@foreach($blog->comments as $comment)
                            @if($comment->parent_id == null)
        						<div class="comment">
                                    <div class="author-image">
                                        <span style="background-image:url({{ asset('img/avatars/'.$comment->getuser->avatar) }});"></span>
                                    </div>
                                    <div class="content">
                                        <div class="author-name">
                                            <strong>{{ $comment->getuser->name }}</strong>
                                            <span class="time">{{ $comment->created_at->diffForHumans() }}</span>

                                            @auth
                                                <span class="right replay" data-commentid="{{ $comment->id }}">Reply</span>
                                            @endauth

                                        </div>
                                        <div class="author-comment">
                                            {{ $comment->comment }}
                                        </div>
                                    </div>
                                    <div id="comment-{{$comment->id}}"></div>
                                </div>
        		            @endif    
        	                <!-- @if($comment->count() > 0)
                                @foreach($comment as $comment)
                                    <div class="comment children">
                                        <div class="author-image">
                                            <span style="background-image:url({{ asset('img/avatars/default-user.png') }});"></span>
                                        </div>
                                        <div class="content">
                                            <div class="author-name">
                                                <strong>{{ isset($comment->getuser->name)? $comment->getuser->name:''}}</strong>
                                                <span class="time">1 Month</span>
                                            </div>
                                            <div class="author-comment">
                                                {{ isset($comment->comment)? $comment->comment:'' }}
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif -->
                            @endforeach
                            @auth
                                @if(Auth()->user()->role_id ==2)
                            @else
        		                <div class="comment-box">
                                    <h6>Leave a comment</h6>
                                    <form action="{{ route('blog.comment',$blog->id) }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="parent" value="0">
                                        <div class="form-outline mb-4">
                                            <textarea class="form-control" name="comment" id="form6Example7" rows="4"></textarea>
                                        </div>    
                                        <br>
                                        <input type="submit" class="btn btn-sm btn-info" value="Comment">
                                    </form>
                                </div>
                            @endif
                            @endauth
                            @guest 
                                <div class="comment-login">
                                    <h6>Please Login to comment</h6>
                                    <a href="{{ route('login') }}" class="btn btn-sm btn-info">Login</a>
                                </div>
                            @endguest
                    </div>
                </div>
        	</div>
        </div>
        <div class="col-md-4">
        	<div class="blog_content right_content">
        		@include('frontend.pages.blog-sidebar')
        	</div>
        </div>
    </div>
   </div>
</div>
@endsection


@section('scripts')
<script>
    $(document).on('click','span.right.replay',function(e){
        e.preventDefault();
        
        var commentid = $(this).data('commentid');

        $('#comment-'+commentid).empty().append(
            `<div class="comment-box">
                <form action="{{ route('blog.comment',$blog->id) }}" method="POST">
                    @csrf
                    <input type="hidden" name="parent" value="1">
                    <input type="hidden" name="parent_id" value="`+commentid+`">
                    
                    <textarea name="comment" class="box" placeholder="Leave a comment"></textarea>
                    <input type="submit" class="btn indigo" value="Comment">
                </form>
            </div>`
        );
    });
</script>
@endsection