@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')

<section class="page-header" style="background-image: url(../img/page-header-about-1.jpg);">
    <div class="container">
        <h2>About Us</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>About Us</span></li>
        </ul>
    </div>
</section>

<section class="about-one about-bg">
    <div class="container">
        <div class="row">
            <div class="col-xl-6">
                <div class="about-one__image">
                    <img src="{{asset('img/about-1-2.png')}}">
                </div>
            </div>
            <div class="col-xl-6 d-flex">
                <div class="my-auto">
                    <div class="about-one__content">
                        <div class="block-title text-left">
                            <p class="has-line">01. About Us</p>
                            <h3>We’re Take Care of Your <br> Problems Carefully</h3>
                        </div><!-- /.block-title -->
                        <div class="nav navtabs about-one__tab-title">
                            <a href="#approach" class="nav-link active" data-toggle="tab">Approach</a>
                            <!-- /.nav-link -->
                            <a href="#mission" class="nav-link" data-toggle="tab">Mission</a>
                            <a href="#target" class="nav-link" data-toggle="tab">Target</a>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active animated fadeInUp" id="approach">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an</p>
                            </div>

                            <div class="tab-pane fade  animated fadeInUp" id="mission">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an</p>
                            </div>
                            <div class="tab-pane fade animated fadeInUp" id="target">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="team-one team-one__about-page">
    <div class="container">
        <div class="block-title text-center">
            <p>02. Experts</p>
            <h3>Our Registered Nurses and Skilled <br> Professionals</h3>
        </div>
        <div class="row high-gutter">
            <div class="col-lg-4 wow fadeInLeft" data-wow-duration="1500ms">
                <div class="team-one__single">
                    <div class="team-one__image">
                        <img src="{{asset('img/team-1-1.jpg')}}">
                    </div>
                    <div class="team-one__content">
                        <div class="team-one__content-inner">
                            <h3>Frank Keller</h3>
                            <p>Instructor</p>
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 wow fadeInUp" data-wow-duration="1500ms">
                <div class="team-one__single">
                    <div class="team-one__image">
                        <img src="{{asset('img/team-1-2.jpg')}}">
                    </div>
                    <div class="team-one__content">
                        <div class="team-one__content-inner">
                            <h3>Ralph Morrison</h3>
                            <p>Instructor</p>
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 wow fadeInRight" data-wow-duration="1500ms">
                <div class="team-one__single">
                    <div class="team-one__image">
                        <img src="{{asset('img/team-1-3.jpg')}}">
                    </div>
                    <div class="team-one__content">
                        <div class="team-one__content-inner">
                            <h3>Landon Owens</h3>
                            <p>Instructor</p>
                            <div class="team-one__social">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="appointment-one appointment-one__home-one about-info-footer">
     <img src="{{asset('img/appointment-map-1-1.png')}}" class="appointment-one__map-1">
     <img src="{{asset('img/appointment-map-1-2.png')}}" class="appointment-one__map-2">
     <img src="{{asset('img/appointment-person-1-1.png')}}" class="appointment-one__moc">
            <div class="container">
                <div class="row justify-content-end">
                    <div class="col-lg-6">
                        <div class="block-title text-left">
                            <p class="has-line">03. Appointment</p>
                            <h3>Want to Hear More About <br> Oberlin Hospice?</h3>
                        </div>
                        <form action="http://html.tonatheme.com/2021/oberlin/inc/sendemail.php" class="contact-one__form contact-form-validated">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" placeholder="Full Name" name="name">
                                </div>
                                <div class="col-md-6">
                                    <input type="text" placeholder="Email Address" name="email">
                                </div>
                                <div class="col-md-6">
                                    <input type="text" placeholder="Phone Number" name="phone">
                                </div>
                                <div class="col-md-6">
                                    <select name="discussion" class="selectpicker">
                                        <option value="">Discussion For</option>
                                        <option value="">Basic Query</option>
                                        <option value="">Patient Admission</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <textarea name="message" placeholder="Message"></textarea>
                                </div>
                                <div class="col-md-12 text-left">
                                    <button type="submit" class="thm-btn contact-one__btn">Submit Now</button>
                                </div>
                            </div>
                        </form>
                        <div class="result"></div>
                    </div>
                </div>
            </div>
        </section>
@endsection
