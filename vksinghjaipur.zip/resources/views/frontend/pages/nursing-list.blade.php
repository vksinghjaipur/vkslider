@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')  
<section class="page-header" style="background-image: url(img/bg.jpg);">
    <div class="container">
        <h2>Nursing List</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="{{url('/')}}">Home</a></li>
            <li><span>Nursing List</span></li>
        </ul>
    </div>
</section>

<section class="service-one service-one__service-page doctor-grid-box">
    <div class="container">

    <!--- filters work ---->
    <div class="subject_filter white-container candidates-search">
        <form class="form-inline" action="{{url('nursing-list')}}" method="GET">
            <div class="row">
                <div class="col-sm-4">
                    <?php
                        $allservices=App\Models\Service::where('status',1)->get();
                    ?>
                    <div class="form-group mx-sm-3 mb-2">
                        <select class="form-control" style="width: 100%;" name="service_id">
                            <option value="">All Services</option>
                            @foreach($allservices as $services)
                                <option @if(isset($_GET['service_id']) && !empty($_GET['service_id']) && $_GET['service_id']== $services->service_name) selected @endif>{{$services->service_name}} </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group mx-sm-3 mb-2">
                        <input type="text" class="form-control" name="s" placeholder="location" value="">
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group mx-sm-3 mb-2">
                        <input type="text" class="form-control" name="name" placeholder="Search by Keyword" value="">
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="form-group mx-sm-3 mb-2">
                        <button type="submit" class="btn btn-primary mb-2"><i class="fas fa-search"></i> Search</button>
                    </div>    
                </div>
            </div>
        </form>
    </div>

    <!--- End filters work ---->

        <div class="block-title text-center">
            <!-- <p>01. Nursing</p> -->
            <h4 class="staff-heading mt-4">Available Nursing Staff</h4>
        </div>
        <div class="row high-gutter">
            @if ($getDocList->count() > 0 )
            @if(isset($getDocList) && !empty($getDocList))
                @foreach($getDocList as $doc_list)
                    <div class="col-lg-3 col-md-6">
                        <div class="service-one__single">
                            <div class="service-one__image doctor-img service-book__image">
                                @if(!empty($doc_list->avatar) && file_exists(public_path('/img/avatars/'.$doc_list->avatar)))
                                    <img src="{{asset('img/avatars/'.$doc_list->avatar)}}" class="image" style="width:100%"/>
                                    <div class="heart">
                                        @if(isset(Auth::User()->id))
                                            @if(isset($favoritData) && in_array($doc_list->id, $favoritData))
                                                <a href="{!! URL::to('/remove-to-favorites'.'/'.$doc_list->id) !!}"><i class="fa fa-heart" style='color: red' aria-hidden="true"></i></a>
                                            @else
                                                <a href="{!! URL::to('/add-to-favorites'.'/'.$doc_list->id) !!}"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                             @endif
                                        @else
                                            <a href="{!! URL::to('/add-to-favorites'.'/'.$doc_list->id) !!}"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                        @endif
                                    </div> 
                                    <div class="middle">
                                        <a href="{{url('/nursing-detail/'.base64_encode($doc_list->id))}}">
                                        <div class="text-booking">Book Appointment</div></a>
                                    </div>
                                @else
                                    <img src="{{asset('img/avatars/default-user-profile.png')}}" class="image-book" style="width:100%"/>
                                    <div class="heart">
                                        @if(isset(Auth::User()->id))
                                            @if(isset($favoriteData) && in_array($doc_list->id, $favoriteData))
                                                <a href="{!! URL::to('/remove-to-favorites'.'/'.$doc_list->id) !!}"><i class="fa fa-heart" style='color: red' aria-hidden="true"></i></a>
                                            @else
                                                <a href="{!! URL::to('/add-to-favorites'.'/'.$doc_list->id) !!}"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                             @endif
                                        @else
                                            <a href="{!! URL::to('/add-to-favorites'.'/'.$doc_list->id) !!}"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                        @endif
                                    </div> 
                                    <div class="middle">
                                        <a href="{{url('/nursing-detail/'.base64_encode($doc_list->id))}}">
                                        <div class="text-booking">Book Appointment</div></a>
                                    </div>
                                @endif          
                            </div>
                            <div class="doctor-detail">
                                <div class="row">
                                    <div class="col-sm-8"><p class="designation">{{$doc_list->specializations}}</p></div> 
                                    <div class="col-sm-4">
                                        <div class="rating font-weight-bold">
                                            {{ getAvgRating($doc_list->user_id)}}
                                        </div> 
                                    </div>    
                                    
                                </div> 
                                <h3><a href="{{url('/nursing-detail/'.base64_encode($doc_list->id))}}">{!! ucfirst($doc_list->name) !!}</a></h3>
                                <div class="row">
                                    <div class="col-sm-5">
                                        <?php 
                                            $from = new DateTime($doc_list->date_of_birth);
                                            $to   = new DateTime('today');
                                            echo $from->diff($to)->y;
                                        ?>
                                     Years old
                                    </div>     
                                    <div class="col-sm-7">
                                       {{$doc_list->experience}} years of exper.
                                    </div>
                                    <!-- <div class="col-sm-12">
                                        <div class="rating font-weight-bold">{{ getAvgRating($doc_list->user_id)}}
                                        </div> 
                                    </div> -->
                                       
                                </div>   
                                <div class="avail-time"><h6 class="font-weight-bold text-info"> Next available at: {{getLatestslot($doc_list->user_id)}}</h6></div>   
                                <div class="location margin-bottom-10"><i class="fas fa-map-marked-alt"></i>  {{Str::limit ($doc_list->address, 25)}}</div>
                            </div>
                        </div>
                    </div>
                @endforeach
                @endif
                @else
                <div class="col-lg-12 text-center">
                    <div class="alert alert-warning">nothing found. search another content </div>
                </div>   
            @endif    
        </div>
        {!! $getDocList->links('vendor.pagination.custom') !!}  
    </div>
</section>
@endsection
