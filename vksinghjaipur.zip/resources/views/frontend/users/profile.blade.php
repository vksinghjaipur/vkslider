@extends('frontend.layouts.app')
@section('title') {{$$module_name_singular->name}}'s Profile @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <div class="profile-section">
            <div class="profile-detail-user">
                <div class="profile-img">
                    {{-- <img class="img-fluid" src="{{url('img/avatars/'.$$module_name_singular->avatar)}}" alt="{{$$module_name_singular->name}}"> --}}
                    @if(!empty($$module_name_singular->avatar) && file_exists(public_path('/img/avatars/'.$$module_name_singular->avatar)))
                        <img src="{{ asset('img/avatars/'.$$module_name_singular->avatar)}}" class="img-fluid" alt="User Image">
                        @else
                        <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image">
                    @endif
                    @auth
                    @if(auth()->user()->id == $$module_name_singular->id)
                        <a href="{{ route('frontend.users.profileEdit', $$module_name_singular->id) }}" class="btn"><i class="fa-regular fa-pencil"></i></a>
                    @endif
                    @endauth
                </div>
                <h2>
                    {{ucwords($$module_name_singular->name)}}
                </h2>
                <!-- <p>
                    Username: {{ucfirst($$module_name_singular->username)}}
                </p> -->
            </div>

            <?php $role = Auth::user()->roles()->get(); ?>
            <!-- Nursing Professional Edit -->     
            @if($role[0]['id'] == 2)

            <div class="mt-3 mb-3 clearfix">
                <div class="card-header">
                    <h5><i class="fa fa-user"></i> Personal Info</h5>
                </div>
                <div class="Info-list">
                    <ul>
                        <?php $fields_array = [
                                [ 'name' => 'username' ],
                                [ 'name' => 'email' ],
                                [ 'name' => 'mobile' ],
                                [ 'name' => 'gender' ],
                                [ 'name' => 'date_of_birth', 'type' => 'date'],
                            ]; 
                        ?>

                        @foreach ($fields_array as $field)
                             @php
                                $field_name = $field['name'];
                                $field_type = isset($field['type'])? $field['type'] : '';
                                @endphp
                             @if ($field_name == 'date_of_birth' && $userprofile->$field_name != '')
                                <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>
                                    @if(auth()->user()->id == $userprofile->user_id)
                                    {{ $userprofile->$field_name->isoFormat('LL') }}
                                    @else
                                    {{ $userprofile->$field_name->format('jS \\of F') }}
                                    @endif
                                    </li>
                                @else
                                    <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>{{ucfirst($userprofile->$field_name) }}</li>
                                @endif
                        @endforeach
                        
                    </ul>
                </div>
            </div>

            <div class="mt-3 mb-3 clearfix">
                <div class="card-header">
                    <h5><i class="fa-solid fa-circle-info"></i> Professional Info</h5>
                </div>
                <div class="Info-list">
                    <ul>
                        <?php $fields_array = [
                                [ 'name' => 'specializations' ],
                                [ 'name' => 'practicing' ],
                                [ 'name' => 'experience' ],
                                [ 'name' => 'license_number' ],
                            ]; 
                        ?>

                        @foreach ($fields_array as $field)
                             @php
                                $field_name = $field['name'];
                                $field_type = isset($field['type'])? $field['type'] : '';
                                @endphp
                          <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>{{ucfirst($userprofile->$field_name) }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>

            <div class="mt-3 mb-3 clearfix">
                <div class="card-header">
                    <h5><i class="fa fa-bank"></i> Bank Details</h5>
                </div>
                <div class="Info-list">
                    <ul>
                        <?php $fields_array = [
                                [ 'name' => 'bank_details' ],
                                [ 'name' => 'ifsc_code' ],
                                [ 'name' => 'country' ],
                                [ 'name' => 'state' ],
                                [ 'name' => 'city' ],
                                [ 'name' => 'address' ],
                                [ 'name' => 'pin_code' ],
                            ]; 
                        ?>

                        @foreach ($fields_array as $field)
                             @php
                                $field_name = $field['name'];
                                $field_type = isset($field['type'])? $field['type'] : '';
                                @endphp
                          <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>{{ucfirst($userprofile->$field_name) }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>

            <div class="mt-3 mb-3 clearfix">
                <div class="card-header">
                    <h5><i class="far fa-frown"></i> About Me (Bio)</h5>
                </div>
                @if(isset($userprofile->bio)?$userprofile->bio:'')
                    <h6 class="description text-justify text-dark">
                        {{$userprofile->bio}}
                    </h6>
                @endif
            </div>    
            

            @elseif( $role[0]['id'] == 3)

            <div class="mt-3 mb-3 clearfix">
                <div class="card-header">
                    <h5><i class="fa fa-user"></i> Personal Info</h5>
                </div>
                <div class="Info-list">
                    <ul>
                        <?php $fields_array = [
                                [ 'name' => 'username' ],
                                [ 'name' => 'email' ],
                                [ 'name' => 'mobile' ],
                                [ 'name' => 'gender' ],
                                [ 'name' => 'date_of_birth', 'type' => 'date'],
                            ]; 
                        ?>

                        @foreach ($fields_array as $field)
                             @php
                                $field_name = $field['name'];
                                $field_type = isset($field['type'])? $field['type'] : '';
                                @endphp
                             @if ($field_name == 'date_of_birth' && $userprofile->$field_name != '')
                                <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>
                                    @if(auth()->user()->id == $userprofile->user_id)
                                    {{ $userprofile->$field_name->isoFormat('LL') }}
                                    @else
                                    {{ $userprofile->$field_name->format('jS \\of F') }}
                                    @endif
                                    </li>
                                @else
                                    <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>{{ucfirst($userprofile->$field_name) }}</li>
                                @endif
                        @endforeach
                        
                    </ul>
                </div>
            </div>            

            <div class="mt-3 mb-3 clearfix">
                <div class="card-header">
                    <h5><i class="fa fa-map-marker"></i> Address Details</h5>
                </div>
                <div class="Info-list">
                    <ul>
                        <?php $fields_array = [
                                [ 'name' => 'country' ],
                                [ 'name' => 'state' ],
                                [ 'name' => 'city' ],
                                [ 'name' => 'address' ],
                                [ 'name' => 'pin_code' ],
                            ]; 
                        ?>

                        @foreach ($fields_array as $field)
                             @php
                                $field_name = $field['name'];
                                $field_type = isset($field['type'])? $field['type'] : '';
                                @endphp
                          <li><label>{{ __("labels.backend.users.fields.".$field_name) }}:</label>{{ucfirst($userprofile->$field_name) }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
            @endif
        </div>
        </div>
        
    </div>
</div>


      </div>
   </div>
</div>

@endsection

@push ("after-scripts")
<script src="https://cdn.jsdelivr.net/npm/sharer.js@latest/sharer.min.js"></script>
@endpush

