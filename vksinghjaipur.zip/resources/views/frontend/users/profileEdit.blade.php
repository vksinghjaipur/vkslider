@extends('frontend.layouts.app')
@section('title') {{$$module_name_singular->name}}'s Profile @endsection
@section('content')
@include('frontend.includes.sidebar')
<div class="col-md-9">
    <div class="dashboard-right-box">
        <div class="profile-section">
                    <div class="profile-detail-user">
                        <div class="profile-img">
                           @if(!empty($$module_name_singular->avatar) && file_exists(public_path('/img/avatars/'.$$module_name_singular->avatar)))
                                <img src="{{ asset('img/avatars/'.$$module_name_singular->avatar)}}" class="img-fluid" alt="User Image">
                                @else
                                <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image">
                            @endif
                            <div class="update-profile">
                                 {{ html()->modelForm($userprofile, 'PATCH', route('frontend.users.profileUpdate', $$module_name_singular->id))->class('form-horizontal')->acceptsFiles()->open() }}
                               {{--  <button class="btn change-pic">
                                    <input id="file-multiple-input" name="avatar" multiple="" type="file" class="form-control-file">
                                    <i class="fa-regular fa-camera"></i>
                                </button> --}}
                                <input type="file" name="avatar" placeholder="Choose image" id="image" class="choose-profile">
                            </div>
                        </div>
                        <h2>
                            {{ucwords($$module_name_singular->name)}}
                        </h2>
                    </div>
                <?php $role = Auth::user()->roles()->get(); ?>
                <!-- Nursing Professional Edit Profile -->     
                @if($role[0]['id'] == 2)    
                <div class="profile-information">
                    <div class="col-md-12"> 
                        {{ html()->modelForm($userprofile, 'PATCH', route('frontend.users.profileUpdate', $$module_name_singular->id))->class('form-horizontal')->acceptsFiles()->open() }}
                        <div class="form-group row">
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'first_name';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'last_name';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'email';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->email($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"])->disabled() }}
                            </div>
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'mobile';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                    <?php
                                    $field_name = 'date_of_birth';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $value = ($userprofile->$field_name != "")? $userprofile->$field_name->toDateString() : "";
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->value($value)->attributes(["$required", 'type'=>'date']) }}
                            </div>

                            <div class="col-sm-6">
                                    <?php
                                    $field_name = 'gender';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = "-- Select an option --";
                                    $required = "";
                                    $select_options = [
                                        'Female' => 'Female',
                                        'Male' => 'Male',
                                        'Other' => 'Other',
                                    ];
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->select($field_name, $select_options)->placeholder($field_placeholder)->class('form-control ')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'specializations';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'practicing';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = 'Practicing in which hospital or Self Practicing';
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>    

                        <div class="form-group row">    
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'experience';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                       
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'license_number';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = 'Medical License Number';
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>
                        
                        <div class="form-group row">        
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'bank_details';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>

                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'ifsc_code';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = 'IFSC Code';
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">        
                            {{ Form::label('service_id', trans('validation.attributes.backend.access.plans.service_id'), ['class' => 'col-md-2 from-control-label required']) }}

                           <div class="col-md-12">
                               <select class="form-control font-14 select2" id="editor6" multiple="multiple" name="service_id[]" data-placeholder="Please Select Service">
                                    <option value="">Choose Services</option>
                                    @if(!empty($myservices))
                                        @foreach($myservices as $servicevalue)
                                            <option value="{{$servicevalue->id}}" @if(isset($myselectdService) && in_array( $servicevalue->id, $myselectdService)) selected="" @endif >{{$servicevalue->service_name}}({{$servicevalue->price}}) </option>
                                        @endforeach
                                    @endif    
                                </select>
                            </div>
                        </div>
                      
                        <div class="form-group row">
                            <div class="col-12 col-sm-3">
                                <?php
                                    $field_name = 'country';
                                    $field_lable = label_case($field_name);
                                ?>

                                {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                
                                    <select  id="country-dd" class="form-control" name="country">
                                        <option value="">Select Country</option>
                                        @foreach ($countries as $data)
                                            <option value="{{$data->id}}"@if(isset($userprofile->country)&&!empty($userprofile->country)&& $userprofile->country == $data->id)selected="selected"@endif>
                                                {{$data->name}}
                                            </option>
                                        @endforeach
                                    </select>
                                      
                            </div>

                            <div class="col-12 col-sm-3">
                                <?php
                                    $field_name = 'state';
                                    $field_lable = label_case($field_name);
                                ?>
                                {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}

                                <select id="state-dd" class="form-control" name="state">
                                    <option value="{{ $userprofile->state }}" selected="">{{$userprofile->statename }}</option>
                                </select>
                            </div>
                            
                            <div class="col-12 col-sm-3">
                                <?php
                                    $field_name = 'city';
                                    $field_lable = label_case($field_name);
                                ?>
                                {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}

                                <select id="city-dd" class="form-control" name="city">
                                    <option value="{{ $userprofile->city }}" selected="">{{$userprofile->cityname }}</option>
                                </select>
                            </div>
                        
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'pin_code';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12 col-sm-6">
                                    <?php
                                    $field_name = 'address';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->textarea($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required",'rows' => 6, 'cols' => 5]) }}
                            </div>
                            <div class="col-12 col-sm-6">
                                    <?php
                                    $field_name = 'bio';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->textarea($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required",'rows' => 6, 'cols' => 5]) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_website';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_facebook';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_twitter';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_linkedin';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            {{ html()->label(__('labels.backend.users.fields.password'))->class('col-md-2 form-control-label')->for('password') }}

                            <div class="col-md-10">
                                <a href="{{ route('frontend.users.changePassword', $$module_name_singular->id) }}" class="btn btn-outline-primary btn-sm"><i class="now-ui-icons objects_key-25"></i>&nbsp;Change password</a>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="col text-center">
                                <div class="form-group">
                                    {!! Form::button("<i class='fas fa-save'></i>&nbsp;Save", ['class' => 'btn btn-success', 'type'=>'submit']) !!}
                                </div>
                            </div>
                        </div>

                    {{ html()->closeModelForm() }}
                    </div>
                </div>
                <!-- Care Seeker Edit Profile -->     
                @elseif( $role[0]['id'] == 3)
                <div class="profile-information">
                    <div class="col-md-12"> 
                        {{ html()->modelForm($userprofile, 'PATCH', route('frontend.users.profileUpdate', $$module_name_singular->id))->class('form-horizontal')->acceptsFiles()->open() }}
                        <div class="form-group row">
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'first_name';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'last_name';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'email';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->email($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"])->disabled() }}
                            </div>
                            <div class="col-md-6">
                                    <?php
                                    $field_name = 'mobile';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                    <?php
                                    $field_name = 'date_of_birth';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $value = ($userprofile->$field_name != "")? $userprofile->$field_name->toDateString() : "";
                                    $required = "required";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->value($value)->attributes(["$required", 'type'=>'date']) }}
                            </div>

                            <div class="col-sm-6">
                                    <?php
                                    $field_name = 'gender';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = "-- Select an option --";
                                    $required = "";
                                    $select_options = [
                                        'Female' => 'Female',
                                        'Male' => 'Male',
                                        'Other' => 'Other',
                                    ];
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->select($field_name, $select_options)->placeholder($field_placeholder)->class('form-control ')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12 col-sm-3">
                                <?php
                                    $field_name = 'country';
                                    $field_lable = label_case($field_name);
                                ?>

                                {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                
                                    <select  id="country-dd" class="form-control" name="country">
                                        <option value="">Select Country</option>
                                        @foreach ($countries as $data)
                                            <option value="{{$data->id}}"@if(isset($userprofile->country)&&!empty($userprofile->country)&& $userprofile->country == $data->id)selected="selected"@endif>
                                                {{$data->name}}
                                            </option>
                                        @endforeach
                                    </select>
                                      
                            </div>

                            <div class="col-12 col-sm-3">
                                <?php
                                    $field_name = 'state';
                                    $field_lable = label_case($field_name);
                                ?>
                                {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}

                                <select id="state-dd" class="form-control" name="state">
                                    <option value="{{ $userprofile->state }}" selected="">{{$userprofile->statename }}</option>
                                </select>
                            </div>
                            
                            <div class="col-12 col-sm-3">
                                <?php
                                    $field_name = 'city';
                                    $field_lable = label_case($field_name);
                                ?>
                                {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}

                                <select id="city-dd" class="form-control" name="city">
                                    <option value="{{ $userprofile->city }}" selected="">{{$userprofile->cityname }}</option>
                                </select>
                            </div>
                        
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'pin_code';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-12 col-sm-6">
                                    <?php
                                    $field_name = 'address';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->textarea($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required",'rows' => 6, 'cols' => 5]) }}
                            </div>
                            <div class="col-12 col-sm-6">
                                    <?php
                                    $field_name = 'bio';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->textarea($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required",'rows' => 6, 'cols' => 5]) }}
                            </div>
                        </div>
                        <div class="form-group row">
                            
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_facebook';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_twitter';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                            <div class="col-12 col-sm-3">
                                    <?php
                                    $field_name = 'url_linkedin';
                                    $field_lable = label_case($field_name);
                                    $field_placeholder = $field_lable;
                                    $required = "";
                                    ?>
                                    {{ html()->label($field_lable, $field_name) }} {!! fielf_required($required) !!}
                                    {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
                            </div>
                        </div>

                        <div class="form-group row">
                            {{ html()->label(__('labels.backend.users.fields.password'))->class('col-md-2 form-control-label')->for('password') }}

                            <div class="col-md-10">
                                <a href="{{ route('frontend.users.changePassword', $$module_name_singular->id) }}" class="btn btn-outline-primary btn-sm"><i class="now-ui-icons objects_key-25"></i>&nbsp;Change password</a>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="col text-center">
                                <div class="form-group">
                                    {!! Form::button("<i class='fas fa-save'></i>&nbsp;Save", ['class' => 'btn btn-success', 'type'=>'submit']) !!}
                                </div>
                            </div>
                        </div>

                    {{ html()->closeModelForm() }}
                    </div>
                </div>
                @endif
            </div>
          </div>
        </div>
      </div>
   </div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker         : true,
      timePickerIncrement: 30,
      format             : 'MM/DD/YYYY h:mm A'
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script> 

<!--get country state city-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#country-dd').on('change', function () {
                var idCountry = this.value;
                $("#state-dd").html('');
                $.ajax({
                    url: "{{url('api/fetch-states')}}",
                    type: "POST",
                    data: {
                        country_id: idCountry,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state-dd').html('<option value="">Select State</option>');
                        $.each(result.states, function (key, value) {
                            $("#state-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                        $('#city-dd').html('<option value="">Select City</option>');
                    }
                });
            });
            $('#state-dd').on('change', function () {
                var idState = this.value;
                $("#city-dd").html('');
                $.ajax({
                    url: "{{url('api/fetch-cities')}}",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (res) {
                        $('#city-dd').html('<option value="">Select City</option>');
                        $.each(res.cities, function (key, value) {
                            $("#city-dd").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                    }
                });
            });
        });
    </script>
</body>


@endsection
