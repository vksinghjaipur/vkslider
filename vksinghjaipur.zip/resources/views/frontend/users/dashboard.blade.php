@extends('frontend.layouts.app')
@section('title')  @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4>Welcome ! <span>{!! isset(Auth::user()->name) && !empty(Auth::user()->name) ? Auth::user()->name : '' !!}</span></h4>
        <div class="dash-cards">
            <div class="row">
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <a href="{{url('my-appointment')}}"><h3>My Bookings</h3>
                                <div class="progress">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p>Total Bookings:- {{ $totalbooking }}</p>
                                <p>Today Bookings:- {{ $todaybooking }}</p>
                            </a>    
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <a href="{{url('favorites')}}"><h3>My favourite</h3>
                                <div class="progress">
                                    <div class="progress-bar bg-warning" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p>Total favourites nursings:- {{ $favoriteData->count() }}</p>
                            </a>    
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <a href="{{url('feedbacks')}}"><h3>My feedbacks</h3>
                                <div class="progress">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p>feedbacks:- {{ $total_feedback->count() }}</p>
                            </a>    
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card widget-card">
                        <div class="card-body">
                            <h3>2 TB</h3>
                            <h6>Widget Title</h6>
                            <div class="progress">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p>Widget Title</p>
                        </div>
                    </div>
                </div>
            </div>    
        </div>  
    </div>
</div>

        </div>
    </div>
</div>
                        
@endsection

