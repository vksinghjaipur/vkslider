@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4><i class="fa fa-calendar"></i> My Favorites</h4>
         <div class="appointment-seaction">
            @if(!empty($favoriteData))
                @foreach($favoriteData as $kp => $vp)
                    <div class="appointment-list">
                        <div class="appointment-user">
                            @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                            <img src="{{asset('img/avatars/'.$vp->avatar)}}" class="image" style="width:100%"/>
                            @else
                            <img src="{{asset('img/avatars/default-user-profile.png')}}" class="image-book" style="width:100%"/>
                            @endif
                        </div>
                        <div class="appointment-user-detail">
                            <div class="appointment-info">
                                <h3>{{ucfirst($vp->name)}}</h3>
                                <p><span><i class="fa-regular fa-clock"></i></span> {{ucfirst($vp->specializations)}}</p>
                                <p><span><i class="fa-regular fa-location-dot"></i></span> {{$vp->address}}</p>
                                <p><span><i class="fa-regular fa-envelope"></i></span> {{$vp->email}}</p>
                                <p><span><i class="fa-regular fa-phone-flip"></i></span> + {{$vp->mobile}}</p>
                            </div>
                            <div class="appointment-action">
                                <!-- <button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Remove</button> -->
                                <a href="{!! URL::to('/remove-to-favorites'.'/'.$vp->id) !!}"><p><span><i class="far fa-times"></i></span> Remove</p></a>
                            </div>
                        </div>
                    </div>
                @endforeach
                @else
                    No favorites data found!
            @endif        
         </div>
    </div>
</div>
@endsection
