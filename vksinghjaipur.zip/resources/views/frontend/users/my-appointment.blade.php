@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4><i class="fa fa-calendar"></i> My Appointment</h4>
         <div class="appointment-seaction">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <button class="nav-link btn btn-sm form-cortrol btn-info mr-5 mb-2 font-weight-bold" data-toggle="tab" href="#information"><i class="fa fa-arrow-down"></i></i> Previous Bookings</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link active btn btn-sm form-cortrol btn-success mr-5" data-toggle="tab" href="#feedback"><i class="fa-solid fa-arrow-up"></i> Upcoming Bookings</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link form-cortrol btn btn-danger btn-sm font-weight-bold" data-toggle="tab" href="#booking"><i class="fa-regular fa-xmark"></i> Canceled Bookings</button>
                </li>
            </ul>

            <div class="tab-content">
                <?php 
                    $todaydate = date('Y-m-d');
                    //print_r($todaydate); die();
                ?>

                <!-- Previous Bookings -->
                <div class="tab-pane fade" id="information">
                    <table class="table table-striped book-table">
                        <thead>
                            <tr>
                                <th scope="col" width="80%">Booking Info</th>
                                <th scope="col" text-right>Booking Status</th>
                            </tr>
                        </thead>
                    </table>
                    @if ($booking_appoin->count() == 0)
                        <tr>
                            <td class="mr-5">No previous appointment found.</td>
                         </tr>
                    @endif

                    @if(!empty($booking_appoin))
                        @foreach($booking_appoin as $kp => $vp)
                            <?php   $mydate=strtotime($vp->booking_date); ?>
                            @if($mydate < strtotime($todaydate))
                            <div class="panel-group" id="accordion">
                                <div class="panel-heading">
                                   <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse1_{{$kp}}" class="user-info">
                                    <div class="row align-items-center" >
                                        @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                            <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                        @else
                                            <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                        @endif
                                        <h5 class="font-weight-bold mt-4">&nbsp;&nbsp;{{ucwords($vp->doctor_id)}}</h5>
                                    </div>
                                </a>
                                <div class="btn-status"> 
                                    @if($vp->status=='Pending')
                                        <button class="btn btn-warning btn-sm mr-1">Rejected</button>
                                    @elseif($vp->status=='Confirm')
                                        <button class="btn btn-info btn-sm mr-1"> Accepted</button>
                                    @elseif($vp->status=='Reject')
                                        <button class="btn btn-danger btn-sm mr-1">Rejected</button>
                                    @elseif($vp->status=='Reject Request')
                                        <button class="btn view-btn cancel-btn" data-toggle="tooltip" title='You applied for appointment rejection, it will be Confirm by admin.'><i class="fa-regular fa-xmark"></i> Reject request submitted </button>        
                                    @endif        
                                </div>
                              </h4> 
                                </div>
                                <div id="collapse1_{{$kp}}" class="panel-collapse collapse in">
                              <div class="panel-body">
                                <div class="booking-lists">
                                    <small class="d-block"><strong>Booking Date:</strong> {{$vp->booking_date}} </small>
                                    <small class="d-block"><strong>Booking Time:</strong> {{$vp->booking_time}}</small>
                                    <small class="d-block"><strong>Booking Day:</strong> 
                                        @if($vp->booking_day=='Sun')
                                            Sunday
                                        @elseif($vp->booking_day=='Mon')
                                            Monday
                                        @elseif($vp->booking_day=='Tue')
                                            Tuesday
                                        @elseif($vp->booking_day=='Wed')
                                            Wednesday
                                        @elseif($vp->booking_day=='Thu')
                                            Thrusday
                                        @elseif($vp->booking_day=='Fri')
                                            Friday
                                        @elseif($vp->booking_day=='Sat')
                                            Saturday                      
                                        @endif        
                                        
                                    </small>
                                    <small class="d-block"><strong>total amount:</strong> {{$vp->total_amount}}</small>

                                    <?php
                                        $stname = explode(',', $vp->service_id);
                                        $servicename=array();
                                        foreach($stname as $key=>$value){
                                            $selected = DB::table('services')
                                            ->where('id',$value) 
                                            ->first();
                                            $result= isset($selected->service_name)?$selected->service_name:'';
                                            array_push($servicename,$result);
                                        }
                                    ?>

                                    <small class="d-block"><strong>Services:</strong> {{implode(', ', $servicename)}}</small>
                                    <small class="d-block"><strong>Message:</strong> {{$vp->message}}</small>
                                    <small class="d-block"><strong>Payment Gateway:</strong> {{$vp->payment_method}}</small>
                                    <small class="d-block"><strong>Booking Status:</strong> 
                                        @if($vp->status=='Pending')
                                            Rejected
                                        @elseif($vp->status=='Confirm')
                                            Accepted
                                        @elseif($vp->status=='Reject')
                                            Rejected
                                        @elseif($vp->status=='Reject Request')
                                            Your request has been applied for rejection        
                                        @endif        
                                    </small>
                                </div>
                              </div>
                            </div>   
                            </div>
                            @endif    
                        @endforeach
                    @endif    
                </div>

                <!-- Upcoming Bookings -->
                <div class="tab-pane active" id="feedback">
                    <table class="table table-striped book-table">
                        <thead>
                            <tr>
                                <th scope="col" width="80%">Booking Info</th>
                                <th scope="col" text-right>Booking Status</th>
                            </tr>
                        </thead>
                    </table> 
                    @if ($booking_appoin->count() == 0)
                        <tr>
                            <td class="mr-5">No upcoming appointment found.</td>
                         </tr>
                    @endif
                    @if(!empty($booking_appoin))
                    @foreach($booking_appoin as $kp => $vp)
                    <?php   $mydate=strtotime($vp->booking_date); ?>
                    @if(!empty($todaydate) && ($mydate >= strtotime($todaydate)))                               
                    <div class="panel-group" id="accordion">
                        <div class="panel panel-default appointment-collapse">
                            <div class="panel-heading">
                              <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse2_{{$kp}}" class="user-info">
                                    <div class="row align-items-center">
                                        @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                            <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                        @else
                                            <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                        @endif
                                        <h5 class="font-weight-bold mt-4">&nbsp;&nbsp;{{ucwords($vp->doctor_id)}}</h5>
                                    </div>
                                </a>
                                <div class="btn-status"> 
                                    @if($vp->status=='Pending')
                                        <button class="btn btn-warning btn-sm mr-1">Pending</button>
                                    @elseif($vp->status=='Confirm')
                                    <button class="btn view-btn success-btn btm-sm mr-1"> Accepted</button>
                                    @elseif($vp->status=='Reject')
                                        <button class="btn btn-danger btn-sm mr-1">Rejected</button>
                                    @elseif($vp->status=='Reject Request')
                                        <button class="btn btn-danger btn-sm mr-1" data-toggle="tooltip" title='Your appointment request has been applied for rejection by nursing staff, it will be Confirm by admin.'>
                                            @if($vp->user_type==2)
                                                Nursing Staff Applied for rejection
                                            @elseif($vp->user_type==3)
                                                You Applied for rejection
                                            @endif 
                                        </button>       
                                    @endif     
                                    <span>
                                        @if($vp->status=='Pending')
                                            <!-- <a href="{!! URL::to('booking'.'/'.$vp->id.'/cancel') !!}"><button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Reject</button></a> -->
                                            <button class="btn view-btn cancel-btn" data-toggle="modal" data-target="#myModal5_{{$kp}}"title="Reject Request"><i class="fa-regular fa-xmark"></i> Reject</button>
                                        @else
                                        
                                        @endif    
                                    </span>
                                </div>
                              </h4>
                            </div>
                            <div id="collapse2_{{$kp}}" class="panel-collapse collapse in">
                              <div class="panel-body">
                                <div class="booking-lists">
                                    <small class="d-block"><strong>Booking Date:</strong> {{$vp->booking_date}} </small>
                                                    <small class="d-block"><strong>Booking Time:</strong> {{$vp->booking_time}}</small>
                                                    <small class="d-block"><strong>Booking Day:</strong> 
                                                        @if($vp->booking_day=='Sun')
                                                            Sunday
                                                        @elseif($vp->booking_day=='Mon')
                                                            Monday
                                                        @elseif($vp->booking_day=='Tue')
                                                            Tuesday
                                                        @elseif($vp->booking_day=='Wed')
                                                            Wednesday
                                                        @elseif($vp->booking_day=='Thu')
                                                            Thrusday
                                                        @elseif($vp->booking_day=='Fri')
                                                            Friday
                                                        @elseif($vp->booking_day=='Sat')
                                                            Saturday                      
                                                        @endif        
                                                        
                                                    </small>
                                                    <small class="d-block"><strong>total amount:</strong> {{$vp->total_amount}}</small>

                                                    <?php
                                                        $stname = explode(',', $vp->service_id);
                                                        $servicename=array();
                                                        foreach($stname as $key=>$value){
                                                            $selected = DB::table('services')
                                                            ->where('id',$value) 
                                                            ->first();
                                                            $result= isset($selected->service_name)?$selected->service_name:'';
                                                            array_push($servicename,$result);
                                                        }
                                                    ?>

                                                    <small class="d-block"><strong>Services:</strong> {{implode(', ', $servicename)}}</small>
                                                    <small class="d-block"><strong>Message:</strong> {{$vp->message}}</small>
                                                    <small class="d-block"><strong>Payment Gateway:</strong> {{$vp->payment_method}}</small>
                                                    <small class="d-block"><strong>Booking Status:</strong> 
                                                        @if($vp->status=='Pending')
                                                            Pending
                                                        @elseif($vp->status=='Confirm')
                                                            Accepted
                                                        @elseif($vp->status=='Reject')
                                                            Rejected
                                                        @elseif($vp->status=='Reject Request')
                                                            Your request has been applied for rejection        
                                                        @endif        
                                                    </small>
                                </div>
                              </div>
                            </div>
                        </div>
                         
                                
                    </div>
                    @endif
                    @endforeach
                        @endif
                   <!--  <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Booking Info</th>
                                    <th scope="col">Booking Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!empty($booking_appoin))
                                    @foreach($booking_appoin as $kp => $vp)
                                        <?php   $mydate=strtotime($vp->booking_date); ?>
                                        @if(!empty($todaydate) && ($mydate >= strtotime($todaydate)))
                                        <tr>
                                            <td scope="row">
                                                <div class="user-dahsboard-order-info-wrap">
                                                    <div class="row">
                                                       @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                                            <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                                        @else
                                                            <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                                        @endif
                                                        <h5 class="font-weight-bold mt-4">&nbsp;&nbsp;{{ucwords($vp->doctor_id)}}</h5>
                                                    </div>
                                                    <small class="d-block"><strong>Booking Date:</strong> {{$vp->booking_date}} </small>
                                                    <small class="d-block"><strong>Booking Time:</strong> {{$vp->booking_time}}</small>
                                                    <small class="d-block"><strong>Booking Day:</strong> 
                                                        @if($vp->booking_day=='Sun')
                                                            Sunday
                                                        @elseif($vp->booking_day=='Mon')
                                                            Monday
                                                        @elseif($vp->booking_day=='Tue')
                                                            Tuesday
                                                        @elseif($vp->booking_day=='Wed')
                                                            Wednesday
                                                        @elseif($vp->booking_day=='Thu')
                                                            Thrusday
                                                        @elseif($vp->booking_day=='Fri')
                                                            Friday
                                                        @elseif($vp->booking_day=='Sat')
                                                            Saturday                      
                                                        @endif        
                                                        
                                                    </small>
                                                    <small class="d-block"><strong>total amount:</strong> {{$vp->total_amount}}</small>

                                                    <?php
                                                        $stname = explode(',', $vp->service_id);
                                                        $servicename=array();
                                                        foreach($stname as $key=>$value){
                                                            $selected = DB::table('services')
                                                            ->where('id',$value) 
                                                            ->first();
                                                            $result= isset($selected->service_name)?$selected->service_name:'';
                                                            array_push($servicename,$result);
                                                        }
                                                    ?>

                                                    <small class="d-block"><strong>Services:</strong> {{implode(', ', $servicename)}}</small>
                                                    <small class="d-block"><strong>Message:</strong> {{$vp->message}}</small>
                                                    <small class="d-block"><strong>Payment Gateway:</strong> {{$vp->payment_method}}</small>
                                                    <small class="d-block"><strong>Booking Status:</strong> 
                                                        @if($vp->status=='Pending')
                                                            Pending
                                                        @elseif($vp->status=='Confirm')
                                                            Accepted
                                                        @elseif($vp->status=='Reject')
                                                            Rejected
                                                        @elseif($vp->status=='Reject Request')
                                                            Your request has been applied for rejection        
                                                        @endif        
                                                    </small>
                                                </div>
                                            </td>
                                            <td>
                                                @if($vp->status=='Pending')
                                                    <span class="btn btn-warning btn-sm">Pending</span>
                                                @elseif($vp->status=='Confirm')
                                                    <span class="btn btn-success btn-sm">Accepted</span>
                                                @elseif($vp->status=='Reject')
                                                    <span class="btn btn-danger btn-sm">Rejected</span>
                                                @elseif($vp->status=='Reject Request')
                                                    <span class="btn btn-danger btn-sm" data-toggle="tooltip" title='Your appointment request has been applied for rejection by nursing staff, it will be Confirm by admin.'>
                                                        @if($vp->user_type==2)
                                                            Nursing Staff Applied for rejection
                                                        @elseif($vp->user_type==3)
                                                            You Applied for rejection
                                                        @endif 
                                                    </span>       
                                                @endif     
                                                <span>
                                                    @if($vp->status=='Pending')
                                                         <a href="{!! URL::to('booking'.'/'.$vp->id.'/cancel') !!}"><button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Reject</button></a> 
                                                        <button class="btn view-btn cancel-btn" data-toggle="modal" data-target="#myModal5_{{$kp}}"title="Reject Request"><i class="fa-regular fa-xmark"></i> Reject</button>
                                                    @else
                                                    
                                                    @endif    
                                                </span>
                                            </td>
                                        </tr>
                                        @endif 
                                    @endforeach
                                    @else
                                    you no any appointment
                                @endif    
                            </tbody>
                        </table>
                    </div> -->
                </div>

                <!-- Canceled Bookings -->
                <div class="tab-pane fade" id="booking">
                    <table class="table table-striped book-table">
                        <thead>
                            <tr>
                                <th scope="col" width="80%">Booking Info</th>
                                <th scope="col" text-right>Booking Status</th>
                            </tr>
                        </thead>
                    </table>
                    @if ($booking_appoin->count() == 0)
                        <tr>
                            <td class="mr-5">No Canceled appointment found.</td>
                         </tr>
                    @endif
                   
                    @if(!empty($booking_appoin))
                        @foreach($booking_appoin as $kp => $vp)
                            @if($vp->status=='Reject')
                                <div class="panel-group" id="accordion">
                                <div class="panel-heading">
                                   <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse3_{{$kp}}" class="user-info">
                                    <div class="row align-items-center" >
                                       @if(!empty($vp->avatar) && file_exists(public_path('/img/avatars/'.$vp->avatar)))
                                            <img src="{{ asset('img/avatars/'.$vp->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                        @else
                                            <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                        @endif
                                        <h5 class="font-weight-bold mt-4">&nbsp;&nbsp;{{ucwords($vp->doctor_id)}}</h5>
                                    </div>
                                </a>
                                <div class="btn-status"> 
                                    @if($vp->status=='Pending')
                                        <buton class="btn btn-warning btn-sm mr-1">Pending</buton>
                                        @elseif($vp->status=='Confirm')
                                            <buton class="btn btn-success btn-sm mr-1">Accepted</buton>
                                        @elseif($vp->status=='Reject')
                                            <button class="btn view-btn cancel-btn mr-1"><i class="fa-regular fa-xmark"></i> Rejected</button>
                                        @elseif($vp->status=='Reject Request')
                                            <buton class="btn btn-danger btn-sm mr-1" data-toggle="tooltip" title='Your appointment request has been applied for rejection by nursing staff, it will be Confirm by admin.'>
                                                @if($vp->user_type==2)
                                                    Nursing Staff Applied for rejection
                                                @elseif($vp->user_type==3)
                                                    You Applied for rejection
                                                @endif 
                                            </buton>       
                                    @endif     
                                    <span>
                                        @if($vp->status=='Pending')
                                            <a href="{!! URL::to('booking'.'/'.$vp->id.'/cancel') !!}"><button class="btn view-btn cancel-btn"><i class="fa-regular fa-xmark"></i> Reject</button></a>
                                        @else
                                        
                                        @endif    
                                    </span>        
                                </div>
                              </h4> 
                                </div>
                                <div id="collapse3_{{$kp}}" class="panel-collapse collapse in">
                              <div class="panel-body">
                                <div class="booking-lists">
                                    <small class="d-block"><strong>Booking Date:</strong> {{$vp->booking_date}} </small>
                                    <small class="d-block"><strong>Booking Time:</strong> {{$vp->booking_time}}</small>
                                    <small class="d-block"><strong>Booking Day:</strong> 
                                        @if($vp->booking_day=='Sun')
                                            Sunday
                                        @elseif($vp->booking_day=='Mon')
                                            Monday
                                        @elseif($vp->booking_day=='Tue')
                                            Tuesday
                                        @elseif($vp->booking_day=='Wed')
                                            Wednesday
                                        @elseif($vp->booking_day=='Thu')
                                            Thrusday
                                        @elseif($vp->booking_day=='Fri')
                                            Friday
                                        @elseif($vp->booking_day=='Sat')
                                            Saturday                      
                                        @endif        
                                        
                                    </small>
                                    <small class="d-block"><strong>total amount:</strong> {{$vp->total_amount}}</small>

                                    <?php
                                        $stname = explode(',', $vp->service_id);
                                        $servicename=array();
                                        foreach($stname as $key=>$value){
                                            $selected = DB::table('services')
                                            ->where('id',$value) 
                                            ->first();
                                            $result= isset($selected->service_name)?$selected->service_name:'';
                                            array_push($servicename,$result);
                                        }
                                    ?>

                                    <small class="d-block"><strong>Services:</strong> {{implode(', ', $servicename)}}</small>
                                    <small class="d-block"><strong>Message:</strong> {{$vp->message}}</small>
                                    <small class="d-block"><strong>Payment Gateway:</strong> {{$vp->payment_method}}</small>
                                    <small class="d-block"><strong>Booking Status:</strong> 
                                        @if($vp->status=='Pending')
                                            Pending
                                        @elseif($vp->status=='Confirm')
                                            Accepted
                                        @elseif($vp->status=='Reject')
                                            Rejected
                                        @elseif($vp->status=='Reject Request')
                                            Your request has been applied for rejection        
                                        @endif        
                                    </small>
                                </div>
                              </div>
                            </div>   
                            </div>      
                            @endif 
                        @endforeach
                    @endif  
                    </div>
                </div>
            </div> 

            <!--- Reject Booking with cancel reason --->
        @if(!empty($booking_appoin))
            @foreach($booking_appoin as $kp => $vp)
                <!--- Modal for show booking details --->
                <div class="modal" id="myModal5_{{$kp}}">
                    <div class="modal-dialog">
                        <div class="modal-content" style="width:500px; margin-top: 100px;">
                            <div class="modal-header">
                                <h5 class="modal-title font-weight-bold text-info" id="exampleModalScrollableTitle">Select Cancellation Reason</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="POST" action="{{route('users.cancel',$vp->id)}}">@csrf
                                    
                                      <input type="radio" id="html" name="cancel_reason" value="Need the service immediately">
                                      <label for="html">Need the service immediately</label><br>

                                      <input type="radio" id="css" name="cancel_reason" value="No longer need the service">
                                      <label for="css">No longer need the service</label><br>

                                      <input type="radio" id="javascript" name="cancel_reason" value="Nursing professional asked to cancel">
                                      <label for="javascript">Nursing professional asked to cancel</label><br>

                                      <input type="radio" id="dbms" name="cancel_reason" value="Other" class="ml-2">
                                      <label for="dbms">Other</label><br>

                                    <div class="btn_group">
                                        <input class="btn btn-info float-right btn-sm" type="submit" value="Update">
                                        <button type="button" class="btn btn-danger float-right mr-3 btn-sm" data-dismiss="modal">Close</button>
                                    </div>     
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif

        </div>
    </div>
</div>
@endsection
