@extends('frontend.layouts.app')
@section('title') {{app_name()}} @endsection
@section('content')
@include('frontend.includes.sidebar')

<div class="col-md-9">
    <div class="dashboard-right-box">
        <h4><i class="fa fa-calendar"></i> Feedback</h4>
         <div class="appointment-seaction">
            <?php $role = Auth::user()->roles()->get(); ?>
            @if ($role[0]['id'] == 2) 
            <div class="row mt-4">
                <div class="col">

                        <!-- total Num of Feedbacks:- {{ $feedbackNursing->count() }}
                        
                        Avergae of feedback: -
                        <?php 
                            $sum = 0;
                            foreach($feedbackNursing as $value){
                                $sum += $value->ratings;
                            }
                            if(count($feedbackNursing)!=0)
                            {
                                $avg = $sum / count($feedbackNursing);
                            }
                            else
                            {
                                $avg = $sum;
                            }
                            echo  (number_format($avg,1)); 
                        ?>     -->


                <div class="dash-cards">
                    <div class="row">
                    <!-- show toatl & average of feedbacks -->
                    <div class="col-md-3">
                        <div class="card widget-card">
                            <div class="card-body">
                                <h3 class="mb-3">Total feedback</h3>
                                <h6> {{ $feedbackNursing->count() }} feedbacks</h6>
                                
                                
                            </div>
                        </div>
                    </div>

                    <!-- show Latest appointment slot -->
                    <div class="col-md-3">
                        <div class="card widget-card">
                            <div class="card-body">
                                <h3 class="mb-3">Feedback Avg</h3>
                                
                                <p class="font-weight-bold">
                                    <?php 
                                        $sum = 0;
                                        foreach($feedbackNursing as $value){
                                            $sum += $value->ratings;
                                        }
                                        if(count($feedbackNursing)!=0)
                                        {
                                            $avg = $sum / count($feedbackNursing);
                                        }
                                        else
                                        {
                                            $avg = $sum;
                                        }
                                        //echo  (number_format($avg,2)); 
                                        echo  '<i class="fa fa-star text-warning"></i>&nbsp;'.number_format($avg,1);
                                    ?>    
                                </p>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>

                        <!-- <table id="example" class="table table-striped table-bordered" style="width:100%;font-size:13px;font-family: arial";>
                             <thead>
                                <tr>
                                    <th style="width:15%";>User Name</th>
                                    <th style="width:11%";>User Image</th>
                                    <th style="width:13%";>Ratings</th>
                                    <th style="width:13%";>Service Name</th>
                                    <th>Feedback</th>
                                    <th style="width:12%";>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if($feedbackNursing->count() == 0)
                                    <tr>
                                        <td colspan="10" style="text-align:center; font-weight: bold; color:blue; font-size:18px; margin-top: 50px;">No feedback found.</td>
                                    </tr>
                                @endif
                                @if(isset($feedbackNursing) && !empty($feedbackNursing))
                                    @foreach($feedbackNursing as $feed_data)
                                        <tr>
                                            <td>{{ucwords($feed_data->user_id)}}</td>
                                            <td> 
                                                <span class="round">
                                                    @if(!empty($feed_data->avatar) && file_exists(public_path('/img/avatars/'.$feed_data->avatar)))
                                                        <img src="{{ asset('img/avatars/'.$feed_data->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                                        @else
                                                        <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                                    @endif
                                                </span>
                                            </td>
                                            <td> 
                                                @for ($i = 0; $i < $feed_data->ratings; $i++)
                                                    <span class="fa fa-star text-warning"></span>
                                                @endfor
                                            </td>
                                            <td>Self care</td>
                                            <td>{{$feed_data->feedback}}</td>
                                            <td>{{ date('d-m-Y', strtotime($feed_data->created_at)) }}</td>
                                        </tr>
                                    @endforeach
                                @endif        
                            </tbody>    
                        </table> -->
                </div>
            </div> 
            @else
            <div class="row mt-4">
                <div class="col">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%;font-size:13px;font-family: arial";>
                             <thead>
                                <tr>
                                    <th style="width:15%";>Dr. Name</th>
                                    <th style="width:12%";>Dr. Image</th>
                                    <th style="width:13%";>Ratings</th>
                                    <th style="width:13%";>Service Name</th>
                                    <th>Feedback</th>
                                    <th style="width:12%";>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if ($feedbackData->count() == 0)
                                    <tr>
                                        <td colspan="10" style="text-align:center; font-weight: bold; color:blue; font-size:18px; margin-top: 50px;">No feedback found.</td>
                                     </tr>
                                @endif
                                @if(isset($feedbackData) && !empty($feedbackData))
                                    @foreach($feedbackData as $feed_data)
                                        <tr>
                                            <td>{{ucwords($feed_data->doctor_id)}}</td>
                                            <td> 
                                                <span class="round">
                                                   @if(!empty($feed_data->avatar) && file_exists(public_path('/img/avatars/'.$feed_data->avatar)))
                                                        <img src="{{ asset('img/avatars/'.$feed_data->avatar)}}" class="img-fluid" alt="User Image" width="60"/>
                                                        @else
                                                        <img src="{{ asset('img/avatars/default-user-profile.png')}}" class="img-fluid" alt="User Image"/>
                                                    @endif
                                                </span>
                                            </td>
                                            <td> 
                                                @for ($i = 0; $i < $feed_data->ratings; $i++)
                                                    <span class="fa fa-star text-warning"></span>
                                                @endfor
                                            </td>
                                            <td>Self care Self care</td>
                                            <td>{{$feed_data->feedback}}</td>
                                            <td>{{ date('d-m-Y', strtotime($feed_data->created_at)) }}</td>
                                        </tr>
                                    @endforeach
                                @endif        
                            </tbody>    
                        </table>
                    </div>
                </div>
            </div>
            @endif 
        </div>
    </div>
</div>
@endsection
